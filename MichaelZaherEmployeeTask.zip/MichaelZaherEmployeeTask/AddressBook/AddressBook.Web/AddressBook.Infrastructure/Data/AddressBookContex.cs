﻿using AddressBook.Core.Entites;
using AddressBook.Core.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Infrastructure.Data
{
    public class AddressBookContex : IdentityDbContext<ApplicationUser>
    {
        public AddressBookContex()
        {
        }

        public AddressBookContex(DbContextOptions<AddressBookContex> options)
            : base(options)
        {

        }

        public DbSet<Departments> Departments { get; set; }
        public DbSet<Employee>  Employees { get; set; }
        public DbSet<EmployeeTask> EmployeeTasks { get; set; }
        public DbSet<Status> Statuses { get; set; }
        public DbSet<Task> Tasks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<IdentityRole>().HasData(
                new { Id = "1", Name = "Admin", NormalizedName = "ADMIN" },
                new { Id = "2", Name = "Employee", NormalizedName = "EMPLOYEE" },
                new { Id = "3", Name = "Manager", NormalizedName = "MANAGER" }
            );

            var hasher = new PasswordHasher<IdentityUser>();
            modelBuilder.Entity<ApplicationUser>().HasData(
                new IdentityUser
                {
                    Id = "2", // primary key
                    UserName = "admin@gmail.com",
                    NormalizedUserName = "ADMIN@GMAIL.COM",
                    PasswordHash = hasher.HashPassword(null, "admin123456"),
                    LockoutEnabled = true ,
                    SecurityStamp = Guid.NewGuid().ToString() , 
                    Email = "admin@gmail.com",
                    NormalizedEmail = "ADMIN@GMAIL.COM"
                }
            );

            modelBuilder.Entity<IdentityUserRole<string>>().HasData(
               new 
              {
                   
                       RoleId = "1", // for admin username
                       UserId = "2"  // for admin role
               });

            modelBuilder.Entity<Status>().HasData(
             new
             {

                 StatusID = 1, 
                 TitleAr = "Initiate"  
             },
                new
                {

                    StatusID = 2, 
                    TitleAr = "InProgress"  
                } ,
                  new
                  {

                      StatusID = 3, 
                      TitleAr = "Finished"  
                  }
             );
        }
    }
}
