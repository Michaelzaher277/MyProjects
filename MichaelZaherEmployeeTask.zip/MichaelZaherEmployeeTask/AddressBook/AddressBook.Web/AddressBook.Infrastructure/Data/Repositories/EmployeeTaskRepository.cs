﻿using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AddressBook.Infrastructure.Data.Repositories
{
    public class EmployeeTaskRepository : Repository<EmployeeTask>, ITaskEmployeeRepository
    {
        private readonly AddressBookContex _dbContext;
        public EmployeeTaskRepository(AddressBookContex dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        public List<EmployeeTask> GetAllEmployeeTaskByEmployeeID(int EmployeeID)
        {
            return _dbContext.EmployeeTasks.Where(x => x.IsDeleted != true && x.EmployeeID == EmployeeID).
               Include(y => y.Employee).Include(y => y.Status).Include(x=>x.Task).ToList();
        }

        public List<EmployeeTask> GetAllEmployeeTaskByTaskID(int TaskID)
        {
            return _dbContext.EmployeeTasks.Where(x => x.IsDeleted != true && x.TaskID == TaskID).
                Include(y=>y.Employee).Include(y=>y.Status).ToList();
        }
    }
}
