﻿using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Infrastructure.Data.Repositories
{
    public class StatusRepository : Repository<Status>, IStatusRepository
    {
        private readonly AddressBookContex _dbContext;
        public StatusRepository(AddressBookContex dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }
    }
}
