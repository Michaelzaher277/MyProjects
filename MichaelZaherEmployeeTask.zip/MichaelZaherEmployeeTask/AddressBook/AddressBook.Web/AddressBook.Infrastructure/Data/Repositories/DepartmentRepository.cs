﻿using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AddressBook.Infrastructure.Data.Repositories
{
    public class DepartmentRepository : Repository<Departments>, IDeparmentRepository
    {
        private readonly AddressBookContex _dbContext;
        public DepartmentRepository(AddressBookContex dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        public Departments GetDepartmenTotalEmployee(int DepartmentID)
        {
           Departments departments =   _dbContext.Departments.Where(x => x.IsDeleted != true && x.DepartmentsID == DepartmentID).FirstOrDefault();
            if (departments != null)
            {
                decimal totalSalary = 0;
                List<Employee> employees = _dbContext.Employees.Where(x => x.IsDeleted != true && x.DepartmentsID == departments.DepartmentsID).ToList();
                foreach (var item in employees)
                {
                    totalSalary = totalSalary + item.Salary;
                }
                departments.TotalEmployee = employees.Count;
                departments.TotalEmployeeSalary = totalSalary;
            }
            return departments;

        }
    }
}
