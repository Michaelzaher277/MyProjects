﻿using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AddressBook.Infrastructure.Data.Repositories
{
    //public class AddressBookRepository : Repository<NewEntry> , IAddressBook
    //{
    //    private readonly AddressBookContex _dbContext;
    //    public AddressBookRepository(AddressBookContex dbContext) : base(dbContext)
    //    {
    //        _dbContext = dbContext;
    //    }

    //    public NewEntry getAddressBookByID(int id)
    //    {
    //        NewEntry newEntry = _dbContext.NewEntry.Where(x => x.NewEntryID == id && x.IsDeleted != true).
    //            Include(x => x.NewEntryPhoness).Include(x => x.NewEntryAddressess).FirstOrDefault();
    //        return newEntry;
    //    }

    //    public List<NewEntry> getAllAddressBook()
    //    {
    //        List<NewEntry> newEntries = _dbContext.NewEntry.Where(x => x.IsDeleted != true).Include(x => x.jobs)
    //            .Include(x => x.Departments).Include(x => x.NewEntryPhoness).Include(x => x.NewEntryAddressess).ToList();
    //        return newEntries;
    //    }
    //}
}
