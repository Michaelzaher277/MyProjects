﻿using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AddressBook.Infrastructure.Data.Repositories
{
    public class EmployeeRepository : Repository<Employee>, IEmployeeRepository
    {
        private readonly AddressBookContex _dbContext;
        public EmployeeRepository(AddressBookContex dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        public List<Employee> getAllEmployeeManager()
        {
            return _dbContext.Employees.Where(x => x.IsDeleted != true && (x.ManagerID == null || x.ManagerID == 0)).ToList();
        }

        public List<Employee> GetAllEmployees()
        {
            List<Employee> emps =  _dbContext.Employees.Where(x => x.IsDeleted != true ).Include(y=>y.Departments).ToList();
            foreach (var item in emps)
            {
                item.FullName = item.FirstName + " " + item.LastName;
            }
            return emps;
        }

        public List<Employee> GetAllEmployeesByDepatID(int DepatID)
        {
            List<Employee> employees = _dbContext.Employees.Where(x => x.IsDeleted != true && x.DepartmentsID == DepatID).ToList();
            return employees;
        }

        public Employee getEmployeeByID(int id)
        {
            Employee employee = _dbContext.Employees.Where(x => x.EmployeeID == id && x.IsDeleted != true).FirstOrDefault();
            return employee;
        }
    }
}
