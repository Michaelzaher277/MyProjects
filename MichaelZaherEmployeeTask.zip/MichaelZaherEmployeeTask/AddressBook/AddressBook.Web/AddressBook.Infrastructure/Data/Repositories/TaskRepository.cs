﻿using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Infrastructure.Data.Repositories
{
    public class TaskRepository : Repository<Task>, ITaskRepository
    {
        private readonly AddressBookContex _dbContext;
        public TaskRepository(AddressBookContex dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }
    }
}
