﻿using AddressBook.Core.Interfaces;
using AddressBook.Core.Shared;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace AddressBook.Infrastructure.Data.Repositories
{
    public class Repository<T> : IRepository<T> where T : EntityBase
    {
        private readonly AddressBookContex _dbContext;

        public Repository(AddressBookContex dbContext)
        {
            _dbContext = dbContext;
        }

        public void Insert(T entity)
        {
            entity.CreatedDate = DateTime.UtcNow;
            _dbContext.Set<T>().Add(entity);
            entity.IsDeleted = false;
            _dbContext.SaveChanges();
        }

        public void Insert(IEnumerable<T> entity)
        {
            _dbContext.Set<T>().AddRange(entity);
            _dbContext.SaveChanges();
        }
        public void Delete(T entity)
        {
            _dbContext.Set<T>().Remove(entity);
            _dbContext.SaveChanges();
        }

        public void Update(T entity)
        {

            _dbContext.Entry(entity).State = EntityState.Modified;
            _dbContext.SaveChanges();
        }

        public void Update(IEnumerable<T> entity)
        {
            foreach (var item in entity)
            {
                _dbContext.Entry(item).State = EntityState.Modified;
            }
            _dbContext.SaveChanges();
        }

        public virtual T GetById(int? id)
        {
            return _dbContext.Set<T>().Find(id);
        }

        public virtual IEnumerable<T> List()
        {
            return _dbContext.Set<T>().Where(a => a.IsDeleted != true || a.IsDeleted == null)
                //.Include(a => a.CreatedByName)
                //.Include(a => a.ModifiedByName)                
                .AsEnumerable();
        }

        public IEnumerable<T> List(Expression<Func<T, bool>> predicate)
        {
            return _dbContext.Set<T>()
               .Where(predicate)
               .AsEnumerable();
        }

        public bool Exists(int id)
        {
            return (GetById(id) != null);
        }
    }
}
