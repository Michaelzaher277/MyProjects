﻿using AddressBook.Core.Entites;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Core.Interfaces
{
    public interface IEmployeeRepository : IRepository<Employee>
    {
        List<Employee> getAllEmployeeManager();
        Employee getEmployeeByID(int id);
        List<Employee> GetAllEmployees();
        List<Employee> GetAllEmployeesByDepatID(int DepatID);
    }
}
