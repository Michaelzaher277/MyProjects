﻿using AddressBook.Core.Entites;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Core.Interfaces
{
     public interface IDeparmentRepository : IRepository<Departments>
    {
        Departments GetDepartmenTotalEmployee(int DepartmentID);
    }
}
