﻿using AddressBook.Core.Entites;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Core.Interfaces
{
    public interface IStatusRepository : IRepository<Status>
    {
    }
}
