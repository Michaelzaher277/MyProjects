﻿using AddressBook.Core.Entites;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Core.Interfaces
{
    // public interface IAddressBook : IRepository<NewEntry>
    // {
    //    //List<NewEntry> getAllAddressBook();
    //    //  NewEntry getAddressBookByID(int id);
    //}
}
