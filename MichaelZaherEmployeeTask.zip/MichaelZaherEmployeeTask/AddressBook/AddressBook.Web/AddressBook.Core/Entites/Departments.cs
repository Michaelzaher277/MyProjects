﻿using AddressBook.Core.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace AddressBook.Core.Entites
{
    public partial class Departments : EntityBase
    {
        public Departments()
        {
            Employees = new HashSet<Employee>();
        }

        public int DepartmentsID { get; set; }
        public string TitleAr { get; set; }
        public string TitleEn { get; set; }

        [NotMapped]
        public decimal? TotalEmployeeSalary { get; set; }

        [NotMapped]
        public int? TotalEmployee { get; set; }

        public ICollection<Employee> Employees { get; set; }
    }
}
