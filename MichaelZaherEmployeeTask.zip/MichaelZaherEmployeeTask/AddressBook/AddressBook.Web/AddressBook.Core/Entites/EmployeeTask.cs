﻿using AddressBook.Core.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace AddressBook.Core.Entites
{
    public partial class EmployeeTask : EntityBase
    {
        public int EmployeeTaskID { get; set; }
        public int? EmployeeID { get; set; }
        public int? TaskID { get; set; }

        public int? StatusID { get; set; }

        [NotMapped]
        public string StatusName { get; set; }

        [NotMapped]
        public string EmployeeName { get; set; }

        public Employee Employee { get; set; }
        public Task Task { get; set; }
        public Status Status { get; set; }
    }
}
