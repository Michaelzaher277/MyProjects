﻿using AddressBook.Core.Shared;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Core.Entites
{
    public partial class Task : EntityBase
    {
        public Task()
        {
            employeeTasks = new HashSet<EmployeeTask>();
        }
        public int TaskID { get; set; }
        public string TitleAr { get; set; }
        public string TitleEn { get; set; }
        public string Description { get; set; }
        public ICollection<EmployeeTask> employeeTasks { get; set; }
    }
}
