﻿using AddressBook.Core.Identity;
using AddressBook.Core.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace AddressBook.Core.Entites
{
    public partial class Employee : EntityBase
    {
        public Employee()
        {
            employeeTasks = new HashSet<EmployeeTask>();
        }

        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal Salary { get; set; }
        public string Image { get; set; }
        public int? ManagerID { get; set; }
        public int? DepartmentsID { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string Email { get; set; }
        public int Type { get; set; }

        public int? phone { get; set; }

        [NotMapped]
        public string FullName { get; set; }
        [NotMapped]
        public bool IsSelected { get; set; }

        [NotMapped]
        public string Password { get; set; }

        public string UserID { get; set; }
        public Departments Departments { get; set; }
        public ApplicationUser User { get; set; }
        public Employee Manager { get; set; }
        public ICollection<Employee> Employees { get; set; }
        public ICollection<EmployeeTask> employeeTasks { get; set; }
    }
}
