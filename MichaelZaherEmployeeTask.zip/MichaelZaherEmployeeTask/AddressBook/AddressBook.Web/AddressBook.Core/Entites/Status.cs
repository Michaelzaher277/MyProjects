﻿using AddressBook.Core.Shared;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Core.Entites
{
    public partial class Status : EntityBase
    {
        public Status()
        {
            employeeTasks = new HashSet<EmployeeTask>();
        }
        public int StatusID { get; set; }
        public string TitleAr { get; set; }
        public string TitleEn { get; set; }
        public ICollection<EmployeeTask> employeeTasks { get; set; }
    }
}
