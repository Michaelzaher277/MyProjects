﻿angular.module('globalApp').requires.push('lfNgMdFileInput');
angular.module('globalApp')
.controller('ProfileController', function ($scope, $http, $rootScope, $cookies, $mdDialog, $element) {
 //   $scope.Users = [];
  //  $scope.User = {};
    $scope.Roles = [];
    $scope.selected = [];
    $scope.files = [];

    //$scope.User = {};

    //function getUserByID() {
    //    $http.get('/Profile/GetUserByID/').success(function (data) {
    //        $scope.User = data;

    //    });
    //};

    //getUserByID();

    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };

    //  getUsers();
    //getRoles();

    //$scope.Countries = [];
    //$scope.LoadCountries = function () {
    //    $element.find('#SearchCountry').on('keydown', function (ev) {
    //        ev.stopPropagation();
    //    });
    //    $http.get('/Login/getCountries').success(function (results) {
    //        $scope.Countries = results;
    //    }).error(function (data, status, headers, config) {
    //        $rootScope.$emit("swAlertError", {});
    //    });
    //};
 //   $scope.api01.addRemoteFile('../' + $scope.User.Path, 'Profile', 'image');

    function getRoles() {

        $http.get('/Profile/GetRoles').success(function (results) {
            $scope.Roles = results;
            for (var i = 0; i < $scope.Roles.length; i++) {
                if ($cookies.get('HMS_lang') == 'ar-EG') {
                    $scope.Roles[i].Title = $scope.Roles[i].NameAr;
                }
                else {
                    $scope.Roles[i].Title = $scope.Roles[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            swAlertErrorEn();
        });
        $scope.selected = [];
    };  

    $scope.changingPass = function (item) {
        $scope.User.Password = "";
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/ChangePassword.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.User = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
      //  $scope.User = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };

    $scope.profileFiles = [];

    $scope.UploadProfile = function () {
        //if ($scope.profileFiles.length > 0) {
            var formData = new FormData();
        //angular.forEach(value.lfFileNam, function (file) {
        //        formData.append('file', file);
        //    });
        angular.forEach($scope.files, function (value, key) {
            formData.append(value.lfFileName, value.lfFile);
        });
            $http.post('/Common/UploadFiles?Folder=UploadImageProfile', formData, {
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }).then(function (result) {

                $scope.User.Path = result.data;
                $scope.save();
                $scope.profileFiles = [];
            }, function (err) {
                $rootScope.$emit("swAlertError", {});
            });
        //}
        //else
          //  $scope.save();
    };

    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.User),
            url: '/Profile/saveUser',
            success: function () {
               // getUsers();
                $scope.cancel();
                swAlertSaveEn();
            },
            error: function () {
                swAlertErrorEn();
            }
        });
    };

  //  getUserByID();
     //       $scope.LoadCountries();
    
  

    //$scope.changePassword = function () {
    //    var obj = { id: $scope.User.UserID, pass: $scope.password}
    //    $.ajax({
    //        type: 'POST',
    //        contentType: 'application/json; charset=utf-8',
    //        data: JSON.stringify(obj),
    //        //url: '/Profile/savePassword/',
    //        url: '/Administration/Security/savePassword/',
    //        success: function () {
    //          //  getUsers();
    //            $scope.cancel();
    //            swAlertSaveEn();
    //        },
    //        error: function () {
    //            swAlertErrorEn();
    //        }
    //    });
    //};

    $scope.changePassword = function () {

        var pram = {};
        pram.UserId = $scope.User.UserID;
        pram.newpassword = $scope.User.NewPassword;


        $http.post("/Security/Security/savePassword", pram).then(function () {
            $rootScope.$emit("swAlertSave", {});
            //$scope.ConfirmedPassword = '';
            //$scope.NewPassword = '';
            //$('#ChangePassword').modal('hide');

            $mdDialog.hide();

            // GetAllUserProfileModel();
        }, function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
   
    //$scope.getcurrentUserbyID();
    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});