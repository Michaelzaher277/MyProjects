﻿angular.module('globalApp')
.controller('OperationReportsController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $element) {
 
    
    $scope.searchText = '';
    $scope.Specialities = [];
    $scope.Doctors = [];
    $scope.ReportID = null;
    $scope.reportType = 1;

        if ($cookies.get('HMS_lang') == 'ar-EG')
        {
            $('.imgIcon').css('float','right');
        }
        else
        {
            $('.imgIcon').css('float', 'left');
        }
    //run On start 
        $scope.LoadSpecialities = function () {
            $http.get('/Administration/DoctorSpecialties/getDoctorSpecialties').success(function (results) {
                $scope.Specialities = results;
                for (var i = 0; i < $scope.Specialities.length; i++) {
                    if ($cookies.get('HMS_lang') == 'ar-EG') {
                        $scope.Specialities[i].Title = $scope.Specialities[i].NameAr;
                    }
                    else {
                        $scope.Specialities[i].Title = $scope.Specialities[i].NameEn;
                    }
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };
        $scope.checkReportStatistics = function () {
            if ($cookies.get('HMS_lang') == 'ar-EG') {
                var reportParams = {
                    "Parms": { "DoctorID": $scope.Doctor.DoctorID, "SpecializeID": $scope.Speciality.DoctorSpecialtiesID },
                    "ReportName": "DoctorsStatisticsAr.trdx"
                };
                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results);
                    x.document.close();

                    //$('#reportTest').html(results);
                })
            }
            else {
                var reportParams = {
                    "Parms": { "DoctorID": $scope.Doctor.DoctorID, "SpecializeID": $scope.Speciality.DoctorSpecialtiesID },
                    "ReportName": "DoctorsStatistics.trdx"
                };
                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results);
                    x.document.close();

                    //$('#reportTest').html(results);
                })
            }
        }
        $scope.checkReportStatisticsDaily = function () {
            if ($cookies.get('HMS_lang') == 'ar-EG') {
                var reportParams = {
                    "Parms": {
                        "DoctorID": $scope.Doctor3.DoctorID, "SpecializeID": $scope.Speciality3.DoctorSpecialtiesID,
                        "dateFrom": $scope.DateFromDoctorStatus3, "DateTo": $scope.DateToDoctorStatus3
                    },
                    "ReportName": "DoctorsStatisticsDailyAr.trdx"
                };
                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results);
                    x.document.close();

                    //$('#reportTest').html(results);
                })
            }
            else {
                var reportParams = {
                    "Parms": {
                        "DoctorID": $scope.Doctor3.DoctorID, "SpecializeID": $scope.Speciality3.DoctorSpecialtiesID,
                        "DateFrom": $scope.DateFromDoctorStatus3, "DateTo": $scope.DateToDoctorStatus3
                    },
                    "ReportName": "DoctorsStatisticsDaily.trdx"
                };
                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results);
                    x.document.close();

                    //$('#reportTest').html(results);
                })
            }
        }
    $scope.checkReportDoctorAppointmentDetails = function () {
            if ($cookies.get('HMS_lang') == 'ar-EG') {
                var reportParams = {
                    "Parms": {
                        "DoctorID": $scope.Doctor1.DoctorID, "DoctorSpecializeID": $scope.Speciality1.DoctorSpecialtiesID,
                        "dateFrom": $scope.DateFromDoctorStatus, "dateto": $scope.DateToDoctorStatus
                    },
                    "ReportName": "DoctorsAppointmentDetailsAr.trdx"
                };
                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results);
                    x.document.close();

                    //$('#reportTest').html(results);
                })
            }
            else {
                var reportParams = {
                    "Parms": {
                        "DoctorID": $scope.Doctor1.DoctorID, "DoctorSpecializeID": $scope.Speciality1.DoctorSpecialtiesID,
                        "dateFrom": $scope.DateFromDoctorStatus, "dateto": $scope.DateToDoctorStatus
                    },
                    "ReportName": "DoctorsAppointmentDetails.trdx"
                };
                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results);
                    x.document.close();

                    //$('#reportTest').html(results);
                })
            }
        }
    $scope.checkReportDoctorAppointment = function () {
            if ($cookies.get('HMS_lang') == 'ar-EG') {
                var reportParams = {
                    "Parms": {
                        "DoctorID": $scope.Doctor2.DoctorID, "DoctorSpecializeID": $scope.Speciality2.DoctorSpecialtiesID,
                        "dateFrom": $scope.DateFromDoctorStatus2, "dateto": $scope.DateToDoctorStatus2
                    },
                    "ReportName": "DoctorsAppointmentAr.trdx"
                };
                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results);
                    x.document.close();

                    //$('#reportTest').html(results);
                })
            }
            else {
                var reportParams = {
                    "Parms": {
                        "DoctorID": $scope.Doctor2.DoctorID, "DoctorSpecializeID": $scope.Speciality2.DoctorSpecialtiesID,
                        "dateFrom": $scope.DateFromDoctorStatus, "dateto": $scope.DateToDoctorStatus
                    },
                    "ReportName": "DoctorsAppointment.trdx"
                };
                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results);
                    x.document.close();

                    //$('#reportTest').html(results);
                })
            }
        }
        //$scope.Doctor = {};
        //$scope.FilterDoctors = function (id) {

        //    $http.get('/Administration/DoctorSpecialties/getDoctor/' + id).success(function (results) {
        //        $scope.Doctor = results;
        //    }).error(function () {
        //        $rootScope.$emit("swAlertError", {});
        //    });
        //};
        $scope.LoadDoctorsBySpecialityID = function (idnu) {
            $http.post("/Outpatient/Appointment/GetDoctorsBySpecialityID", { id : idnu }).success(function (results) {
                $rootScope.APP_DoctorID = 0;
                $scope.Doctors = results;
                for (var i = 0; i < $scope.Doctors.length; i++) {
                    if ($cookies.get('HMS_lang') == 'ar-EG') {
                        $scope.Doctors[i].Title = $scope.Doctors[i].NameAr;
                        $scope.Doctors[i].value = $scope.Doctors[i].DoctorID;
                        $scope.Doctors[i].text = $scope.Doctors[i].Title;
                    }
                    else {
                        $scope.Doctors[i].Title = $scope.Doctors[i].NameEn;
                        $scope.Doctors[i].value = $scope.Doctors[i].DoctorID;
                        $scope.Doctors[i].text = $scope.Doctors[i].Title;
                    }
                }
                if (!fromPopup) {
                    $scope.FilterDoctors();
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };
        $scope.GetSpeciality = function () {
            $http.get('/Administration/DoctorSpecialties/getDoctorSpecialtieByID/' + $rootScope.APP_DoctorSpecialtiesID).success(function (data) {
                $scope.Speciality = data;
                if ($cookies.get('HMS_lang') == 'ar-EG') {
                    $scope.Speciality.Title = $scope.Speciality.NameAr;
                }
                else {
                    $scope.Speciality.Title = $scope.Speciality.NameEn;
                }
            });
        };
    $scope.OpenReport = function () {

        //  Pilot Hours Report
        if ($scope.ReportID == 1) {

            var reportParams = {
                "Parms": {
                    "PilotID": $scope.Pilot.PilotID,
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                    "PilotName": $scope.Pilot.FirstName + ' ' + $scope.Pilot.SecondName + ' ' + $scope.Pilot.SureName + ' - ' + $scope.Pilot.ShortName,
                    "IdOrCode": $scope.Pilot.LicenseNo,
                    "TBF": $scope.Pilot.TBF_Total_Hours + ' : ' + $scope.Pilot.TBF_Total_Mins,

                },
                "ReportName": "PilotHoursReport.trdx"
            };
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })
        }
        // Pilot DHD HoursReport
        if ($scope.ReportID == 2) {

            var reportParams = {
                "Parms": {
                    "PilotID": $scope.Pilot.PilotID,
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                    "PilotName": $scope.Pilot.FirstName + ' ' + $scope.Pilot.SecondName + ' ' + $scope.Pilot.SureName + ' - ' + $scope.Pilot.ShortName,
                    "IdOrCode": $scope.Pilot.LicenseNo,
                    "TBF": $scope.Pilot.TBF_Total_Hours + ' : ' + $scope.Pilot.TBF_Total_Mins,

                },
                "ReportName": "PilotDHDHoursReport.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })


        }
        //Pilot Night Stop
        if ($scope.ReportID == 3) {

            var reportParams = {
                "Parms": {
                    "PilotID": $scope.Pilot.PilotID,
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                    "PilotName": $scope.Pilot.FirstName + ' ' + $scope.Pilot.SecondName + ' ' + $scope.Pilot.SureName + ' - ' + $scope.Pilot.ShortName,

                },
                "ReportName": "PilotNightStop.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })


        }
        //Pilot Simulation hours
        if ($scope.ReportID == 4) {

            var reportParams = {
                "Parms": {
                    "PilotID": $scope.Pilot.PilotID,
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                    "PilotName": $scope.Pilot.FirstName + ' ' + $scope.Pilot.SecondName + ' ' + $scope.Pilot.SureName + ' - ' + $scope.Pilot.ShortName,
                    "IdOrCode": $scope.Pilot.LicenseNo,


                },
                "ReportName": "PilotSimulationhours.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })


        }
        //  Pilots Hours Summary
        if ($scope.ReportID == 5) {

            var reportParams = {
                "Parms": {
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                },
                "ReportName": "PilotsHoursSummary.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })


        }

        if ($scope.ReportID == 6) {

          
            var ACTypeID = '';
            var ACTypeName = '';
            if ($scope.AirCraftType.ACTypeID == undefined) {
                ACTypeID = 0;
                ACTypeName = 'All AC Types';
            }
            else {
                ACTypeID = $scope.AirCraftType.ACTypeID;
                ACTypeName = $scope.AirCraftType.Name;
            }
            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=PHADO&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '&ACType=' + ACTypeID + '&ACName=' + ACTypeName + '', '_blank');


        }

        if ($scope.ReportID == 7) {

            var reportParams = {
                "Parms": {
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                },
                "ReportName": "PilotLoginReport.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })


        }
        
        if ($scope.ReportID == 8) {

            var reportParams = {
                "Parms": {
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                },
                "ReportName": "PilotDocumentExpiry.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })
        }

        if ($scope.ReportID == 9) {

            var AirPlaneID='';
            var AirplaneName = ''
            if ($scope.AirPlane.AirPlaneID==undefined)
            {
                AirPlaneID = 0;
                AirplaneName = 'All';
            }
            else
            {
                AirPlaneID = $scope.AirPlane.AirPlaneID;
                AirplaneName = $scope.AirPlane.Name;
            }
            var reportParams = {
                "Parms": {
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                    "AirPlaneID": AirPlaneID,
                    "AirPlaneName": AirplaneName,
                },
                "ReportName": "PAXAndFuel.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })
        }

        if ($scope.ReportID == 10) {
            var reportParams = {
                "Parms": {
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                    "AirPlaneID":  $scope.AirPlane.AirPlaneID,
                   
                },
                "ReportName": "AirPlaneFuel.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })
        }

        if ($scope.ReportID == 11) {
            
            if ($scope.selectedItemFrom != null && $scope.selectedItemTo != null) {

                var reportParams = {

                    "Parms": {
                        "StartDate": $scope.DateFrom,
                        "EndDate": $scope.DateTo,
                        "From_AirPortID": $scope.selectedItemFrom.AirPortID,
                        "To_AirPortID": $scope.selectedItemTo.AirPortID,

                    },
                    "ReportName": "SectorFuel.trdx"
                };

                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results.data);
                    x.document.close();
                })
            }

        }

        if ($scope.ReportID == 12) {
            var ACID='';
            
            if ($scope.AirPlane.AirPlaneID == undefined)
                ACID = 0;
            else
                ACID = $scope.AirPlane.AirPlaneID;
                var reportParams = {

                    "Parms": {
                        "StartDate": $scope.DateFrom,
                        "EndDate": $scope.DateTo,
                      

                    },
                    "ReportName": "FlightScheduleBySectors.trdx"
                };

                //$("#reportTest").load('/report', JSON.stringify(reportParams));
                $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                    var x = window.open();
                    x.document.open();
                    x.document.write(results.data);
                    x.document.close();
                })
           

        }

        if ($scope.ReportID == 13) {
            var reportParams = {
                "Parms": {
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                  

                },
                "ReportName": "FlightScheduleByFlight.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })
        }

        if ($scope.ReportID == 14) {
            var PilotID = '';

            if ($scope.Pilot.PilotID == undefined)
                PilotID = 0;
            else
                PilotID = $scope.Pilot.PilotID;
            var reportParams = {

                "Parms": {
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                    "PilotID": PilotID,

                },
                "ReportName": "CrewMovementReport.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })


        }

        if ($scope.ReportID == 15) {
            var reportParams = {
                "Parms": {
                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,


                },
                "ReportName": "CrewNoOfFlights.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })
        }


        if ($scope.ReportID == 16) {
        
            // if set not selection of day to value 0 but report in no selection day case it request an empty string 
            // and set it to zero to show label 
            if ($scope.SelectedDay == "0")
                $scope.SelectedDay = '';


            var DistinationAirPortID = '';
            var DistinationAirPortName = '';
            var ClientID = '';
            var ClientName = '';
            var ACTypeID = '';
            var ACTypeName = '';
            if ($scope.selectedItemTo != null) {
                DistinationAirPortID = $scope.selectedItemTo.AirPortID;
                DistinationAirPortName = $scope.selectedItemTo.IATACode;
            }
            else {
                DistinationAirPortID = 0;
                DistinationAirPortName = 'All'
            }

            if ($scope.Operator.ClientID == undefined) {
                ClientID = 0;
                ClientName = 'All';
            }
            else {
                ClientID = $scope.Operator.ClientID;
                ClientName = $scope.Operator.Name;
            }

            if ($scope.AirCraftType.ACTypeID == undefined) {
                ACTypeID = 0;
                ACTypeName = 'All';
            }
            else {
                ACTypeID = $scope.AirCraftType.ACTypeID;
                ACTypeName = $scope.AirCraftType.Name;
            }

            var reportParams = {
                "Parms": {


                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                    "STD": $scope.STD,
                    "DayName": $scope.SelectedDay,
                    "AirportID": DistinationAirPortID,
                    "AirPortName": DistinationAirPortName,
                    "ClientID": ClientID,
                    "ClientName": ClientName,
                    "ACTypeID": ACTypeID,
                    "ACTypeName": ACTypeName,
                    "FlightNo": $scope.FlightNo,


                },
                "ReportName": "AllPilotsStatusbydestination.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })
        }

        if ($scope.ReportID == 17) {
        
            // if set not selection of day to value 0 but report in no selection day case it request an empty string 
            // and set it to zero to show label 
            if ($scope.SelectedDay == "0")
                $scope.SelectedDay = '';


            var DistinationAirPortID = '';
            var DistinationAirPortName = '';
            var ClientID = '';
            var ClientName = '';
            var ACTypeID = '';
            var ACTypeName = '';
            if ($scope.selectedItemTo != null) {
                DistinationAirPortID = $scope.selectedItemTo.AirPortID;
                DistinationAirPortName = $scope.selectedItemTo.IATACode;
            }
            else {
                DistinationAirPortID = 0;
                DistinationAirPortName = 'All'
            }

            if ($scope.Operator.ClientID == undefined) {
                ClientID = 0;
                ClientName = 'All';
            }
            else {
                ClientID = $scope.Operator.ClientID;
                ClientName = $scope.Operator.Name;
            }

            if ($scope.AirCraftType.ACTypeID == undefined) {
                ACTypeID = 0;
                ACTypeName = 'All';
            }
            else {
                ACTypeID = $scope.AirCraftType.ACTypeID;
                ACTypeName = $scope.AirCraftType.Name;
            }

            var reportParams = {
                "Parms": {


                    "StartDate": $scope.DateFrom,
                    "EndDate": $scope.DateTo,
                    "STD": $scope.STD,
                    "DayName": $scope.SelectedDay,
                    "AirportID": DistinationAirPortID,
                    "AirPortName": DistinationAirPortName,
                    "ClientID": ClientID,
                    "ClientName": ClientName,
                    "ACTypeID": ACTypeID,
                    "ACTypeName": ACTypeName,
                    "FlightNo": $scope.FlightNo,


                },
                "ReportName": "PilotsdestinationDetails.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));
            $http.post('/report', JSON.stringify(reportParams)).then(function (results) {
                var x = window.open();
                x.document.open();
                x.document.write(results.data);
                x.document.close();
            })
        }

        if ($scope.ReportID == 18) {

            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=PSS&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '', '_blank');
        }

        if ($scope.ReportID == 19) {

            var PilotID = '';

            if ($scope.Pilot.PilotID == undefined)
                PilotID = 0;
            else
                PilotID = $scope.Pilot.PilotID;

            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=TDH&From=' + $scope.DateFrom + '&To=' + $scope.To + '&PID='+PilotID+'', '_blank');
        }

        if ($scope.ReportID == 20) {

            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=PHWR&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '', '_blank');
        }

        if ($scope.ReportID == 21) {

            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=ALLPS&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '', '_blank');
        }

        if ($scope.ReportID == 22) {

            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=ALLPCM&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '', '_blank');
        }


        if ($scope.ReportID == 23) {
            var ACTypeID = '';
            var ACTypeName = '';
            if ($scope.AirCraftType.ACTypeID == undefined) {
                ACTypeID = 0;
                ACTypeName = 'All AC Types';
            }
            else {
                ACTypeID = $scope.AirCraftType.ACTypeID;
                ACTypeName = $scope.AirCraftType.Name;
            }
            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=PAH&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '&ACType=' + ACTypeID + '&ACName=' + ACTypeName + '', '_blank');
        }

        if ($scope.ReportID == 24) {
            var ACTypeID = '';
            var ACTypeName = '';
            if ($scope.AirCraftType.ACTypeID == undefined) {
                ACTypeID = 0;
                ACTypeName = 'All AC Types';
            }
            else {
                ACTypeID = $scope.AirCraftType.ACTypeID;
                ACTypeName = $scope.AirCraftType.Name;
            }
            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=PAHMC&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '&ACType=' + ACTypeID + '&ACName=' + ACTypeName + '', '_blank');
        }

        if ($scope.ReportID == 25) {
            var ACTypeID = '';
            
            if ($scope.AirCraftType.ACTypeID == undefined) {
                ACTypeID = 0;
                
            }
            else {
                ACTypeID = $scope.AirCraftType.ACTypeID;
                
            }
            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=ALLPHADS&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '&ACTypeID=' + ACTypeID +  '', '_blank');
        }

        if($scope.ReportID == 26)
        {
            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=LDFA&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '', '_blank');
        }

        if ($scope.ReportID == 27) {
            var ACID = '';
            var ACName = '';
            if ($scope.AirPlane.AirPlaneID == undefined) {
                ACID = 0;
                ACName = 'All AC ';
            }
            else {
                ACID = $scope.AirPlane.AirPlaneID;
                ACName = $scope.AirPlane.Name;
            }
            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=FS&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '&ACID=' + ACID + '&ACName=' + ACName + '', '_blank');
        }

        if ($scope.ReportID == 28) {
            var fromairport = 0;
            var toairport = 0;
            if ($scope.selectedItemFrom != null) {

                fromairport = $scope.selectedItemFrom.AirPortID;

            }
            if ($scope.selectedItemTo != null) {

                toairport = $scope.selectedItemTo.AirPortID;
            }

            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=MSC&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '&FromAirport=' + fromairport
                + '&ToAirport=' + toairport + '', '_blank');
        }

        if ($scope.ReportID == 29) {

            window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=PF&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '&PilotsType=' + $scope.PilotsType + '', '_blank');
        }
        if ($scope.ReportID == 30) {

           

            if ($scope.Pilot.PilotID == undefined)
            {
                swCustomErrorEn("Please select pilot to view report");
            }
            else
                window.open('../../Areas/FixedWing/OperationReportPage.aspx?RT=PFD&From=' + $scope.DateFrom + '&To=' + $scope.DateTo + '&PID=' + $scope.Pilot.PilotID + '', '_blank');
        }

    }

   
});