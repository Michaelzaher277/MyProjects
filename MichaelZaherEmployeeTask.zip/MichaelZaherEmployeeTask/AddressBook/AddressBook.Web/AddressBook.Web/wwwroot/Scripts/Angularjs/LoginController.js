﻿angular.module('globalApp')
.controller('LoginController', function ($scope, $http, $rootScope ,  $timeout ) {
    $scope.users = [];
    $scope.user = {};

    $scope.checkLogin = function () {
        console.log($scope.user)
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.user),
            url: '/Login/Login',
            success: function (data) {
                if (parseInt(data) > 0) {
                    window.location.href = "/home";
                }
                else {
                    swErrorLoginEn();
                    //$rootScope.$emit("swErrorLogin", {});
                }
            },
            error: function () {
                swAlertErrorEn();
                //$rootScope.$emit("swAlertError", {});
            }
        });
    };
});
