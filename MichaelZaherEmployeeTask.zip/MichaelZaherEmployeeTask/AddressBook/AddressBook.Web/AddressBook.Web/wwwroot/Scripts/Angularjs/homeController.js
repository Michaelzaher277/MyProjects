﻿angular.module('globalApp')
    .controller('homeController', function ($scope, $http, $mdDialog, $cookies, $rootScope) {
        if ($cookies.get('HMS_lang') == 'ar-EG') {
            $rootScope.Background.img = "../../img/internal-bg-Arabic.jpg";
        }
        else
            $rootScope.Background.img = "../../img/internal-bg-English.jpg";


        
        document.body.style.backgroundImage = "url(" + $rootScope.Background.img + ")";
    //$scope.SubMenu = 0;
    $scope.Toggle = function (id) {
        $('#Div' + id).toggle(200)
    }
    $scope.redirectToPage = function (item) {

        window.location.href = '/' + item.AreaName + '/' + item.ControllerName ;
    }
    $scope.SubmenuList = [];
    $scope.MenusListFillOnStart = [];
        // show submenu popup 
    $scope.showSubMenu = function (AreaName) {
        //$scope.SubMenu = SubMenu;
        $scope.SubmenuList = GetSubmenuesByAreaName(AreaName)
        ///check if array >0 show dialog
        if ($scope.SubmenuList.length > 0) {
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../templates/Submenu.tmpl.html',
                onRemoving: function () {
                    $scope.cancel();
                },
                clickOutsideToClose: true,
                openFrom: '.addMedicineButton',
                closeTo: '.addMedicineButton'
            })
        }
    };
    // get sub menu
    function GetSubmenuesByAreaName(AreaName) {
        var TempList = [];
        for (var i = 0; i < $scope.MenusListFillOnStart.length; i++) {
            if ($scope.MenusListFillOnStart[i].AreaName == AreaName) {
                TempList.push($scope.MenusListFillOnStart[i]);
            }
        }
        return TempList;
    }
    GetAllSubMenuAtStart();
    function GetAllSubMenuAtStart() {
        //call server

        $http.get('/home/GetSubmenuesByAreaName').success(function (results) {
            $scope.MenusListFillOnStart = results;
            for (var i = 0; i < $scope.MenusListFillOnStart.length; i++) {
                if ($cookies.get('HMS_lang') == 'ar-EG') {
                    $scope.MenusListFillOnStart[i].Title = $scope.MenusListFillOnStart[i].NameAr;
                }
                else {
                    $scope.MenusListFillOnStart[i].Title = $scope.MenusListFillOnStart[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });

    }




});