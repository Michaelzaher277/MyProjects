﻿angular.module('globalApp')
.controller('LabCashierController', function ($scope, $http, $cookies, $rootScope, $element , $mdDialog) {
    // Scope Variables
    $scope.Appointments = [];
    $scope.Appointment = {};
    $scope.Labs = [];
    $scope.Lab = {};
    $scope.Rads = [];
    $scope.Rad = {};
    $scope.Clinic = {};
    $scope.Clinics = [];
    $scope.AvalibleAppointmentPatientInsuranceCards = [];
    $scope.AvalibleAppointmentPatientInsuranceCard = {};
    // Search fields Scope Variables
    $scope.DoctorSpecialties = [];
    $scope.DoctorSpeciality = 0;
    $scope.AvailableAppointmentsSearch = "";
    $scope.AvailableAppointmentsDate = new Date();
    $scope.ServiceStatus = [];
    $scope.ServiceStatu = {};
    $scope.ServiceStatutsLabID = {};
    $scope.ServiceStatutsLabID.StatusLabID = 0;
    $scope.ServiceStatusID = 0;
    $scope.AppointmentDate = new Date();
    $scope.AppointmentDateRad = new Date();

    // MD DataTable Variables
    $scope.selectedLab = [];
    $scope.queryLab = {
        orderLab: 'name',
        limitLab: 5,
        pageLab: 1
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.optionsLab = {
        pageSelectLab: true
    };

    $scope.selectedClinic = [];
    $scope.queryClinic = {
        orderClinic: 'name',
        limitClinic: 5,
        pageClinic: 1
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.optionsClinic = {
        pageSelectClinic: true
    };

    $scope.selectedRad = [];
    $scope.queryRad = {
        orderRad: 'name',
        limitRad: 5,
        pageRad: 1
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.optionsRad = {
        pageSelectRad: true
    };

    $scope.selected = [];
    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    //$scope.IsInsured = {};
    $rootScope.IsInsured = 1;

    $scope.removeFilterLab = function () {
        $scope.filterLab.show = false;
        $scope.queryLab.filterLab = '';

        if ($scope.filterLab.form.$dirty) {
            $scope.filterLab.form.$setPristine();
        }
    };

    $scope.removeFilterClinic = function () {
        $scope.filterClinic.show = false;
        $scope.queryClinic.filterClinic = '';

        if ($scope.filterClinic.form.$dirty) {
            $scope.filterClinic.form.$setPristine();
        }
    };

    $scope.removeFilterRad = function () {
        $scope.filterRad.show = false;
        $scope.queryRad.filterRad = '';

        if ($scope.filterRad.form.$dirty) {
            $scope.filterRad.form.$setPristine();
        }
    };
    // Activating Search Dropdowns
    $element.find('input#searchSpeciality').on('keydown', function (ev) {
        ev.stopPropagation();
    });

    // Run at startup
    getDoctorSpecialties();
    getAllServiceStatus();
 
    // Functions
    function getDoctorSpecialties() {
        $http.get('/Administration/DoctorSpecialties/getDoctorSpecialties').success(function (results) {
            $scope.DoctorSpecialties = results;
            for (var i = 0; i < $scope.DoctorSpecialties.length; i++) {
                if ($cookies.get('HMS_lang') == 'ar-EG') {
                    $scope.DoctorSpecialties[i].Name = $scope.DoctorSpecialties[i].NameAr;
                }
                else {
                    $scope.DoctorSpecialties[i].Name = $scope.DoctorSpecialties[i].NameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    if ($.signalR != undefined)
        InitiateSignalR();
       
      function InitiateSignalR() {
        if ($.signalR != undefined) {
            // Reference the auto-generated proxy for the hub.  
            var obj = $.connection.subscriptionHub;
            // Create a function that the hub can call back to display messages.
            obj.client.GetNewNotification = function (obj) {
                // Add the message to the page. 
                // get new notifications only then toast 
                $scope.getAvailableLabs();
                $scope.showSimpleToast(obj.Description);
                // $scope.getDoctorSplashs();                
                //$scope.AllNewNotifications.counter++;
                $scope.$apply();
            };

            // Start the connection.
            $.connection.hub.start().done(function () {

            });
        }
    };




    function clearFields() {
        $scope.Appointment = {};
        $scope.Lab = {};
        $scope.LabWalkin = {};
    }
     $scope.LabReportWalkin = function (model) {
        var reportParams = {
            "Parms": { "LabServiceForWalkInID": model.LabServiceForWalkInID, "Grouped": model.Grouped },
            "ReportName": "Report_GetLabsWalkin.trdx"
        };
        //$("#reportTest").load('/report', JSON.stringify(reportParams));
        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }
    function loadMedicalAssessmentByAppointmentID(AppointmentID) {
        $http.get("MedicalAssessment/loadMedicalAssessmentByAppointmentID/" + AppointmentID).success(function (result) {
            if (result == "null") {
                $scope.AppointmentAssesment = {};
            }
            else {
                $scope.AppointmentAssesment = result;
            }
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        })
    }
    function generateReciept (SalesInvoiceID) {
        var reportParams = {
            "Parms": { "SalesInvoiceID": SalesInvoiceID },
            "ReportName": "Sales_Receipt.trdx"
        };

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }
    $scope.Setting = {};
    getSetting();
    function getSetting() {
        $.ajax({
            type: 'Get',
            contentType: 'application/json; charset=utf-8',
            url: '/Administration/AdminSetting/GetAdminSetting',
            success: function (data) {
                $scope.Setting = data
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });

    }
    function generateLabReciept(AppointmentID) {
        var reportParams = {
            "Parms": { "AppointmentID": AppointmentID },
            "ReportName": "Report_GetLabsReceipt.trdx"
        };

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }
    function generateClinicReciept(AppointmentID) {
        var reportParams = {
            "Parms": { "AppointmentID": AppointmentID },
            "ReportName": "Report_GetClinicsReceipt.trdx"
        };

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }
    function generateRadReciept(AppointmentID) {
         var reportParams = {
             "Parms": { "AppointmentID": AppointmentID },
             "ReportName": "Report_GetRadsReceipt.trdx"
         };

         $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
             var x = window.open();
             x.document.open();
             x.document.write(results);
             x.document.close();
         })
     }
    function getAllServiceStatus() {
        $http.get('/AppointmentPayment/getAllServiceStatus/').success(function (results) {
            $scope.ServiceStatus = results;
            for (var i = 0; i < $scope.ServiceStatus.length; i++) {
                if ($cookies.get('HMS_lang') == 'ar-EG') {
                    $scope.ServiceStatus[i].ServiceStatusName = $scope.ServiceStatus[i].NameAR;

                }
                else {
                    $scope.ServiceStatus[i].ServiceStatusName = $scope.ServiceStatus[i].NameEN;

                }
            }
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    }
    // Scope Functions
    $scope.GenerateInvoice = function (model) {
        var reportParams = {
            "Parms": { "InvoiceID": model.Sales_InvoiceID },
            "ReportName": "Sales_InvoiceReport.trdx"
        };
        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }
   
    $scope.getAvailableLabs = function () {
        $http.post('/LabCashier/getAvailableLabs', { id1: $scope.AppointmentDate, id2: $scope.ServiceStatutsLabID.StatusLabID }).success(function (results) {
            $scope.Labs = results;
            for (var i = 0; i < $scope.Labs.length; i++) {
                if ($cookies.get('HMS_lang') == 'ar-EG') {
                    $scope.Labs[i].Name = $scope.Labs[i].PatientNameAr;
                    $scope.Labs[i].StatusName = $scope.Labs[i].ServiceStatusNameAR;
                }
                else
                {
                    $scope.Labs[i].Name = $scope.Labs[i].PatientName;
                    $scope.Labs[i].StatusName = $scope.Labs[i].ServiceStatusName;

                }
                //$scope.Labs[i].LabSeviceNameDecoded = $scope.decodeHtml($scope.Labs[i].LabSeviceName);
            }
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.MarkLabAsConfirmed = function (model) {
        $rootScope.$emit("swConfirmSave", {
            function() {
        $scope.Lab = model;
                $http.post("/LabCashier/MarkLabAsConfirmed", { model: $scope.Lab, Fees: $scope.Lab.fees, IsLabRecep: $scope.Setting.IsSkipLabReceptionist, IsLabTec: $scope.Setting.IsSkipLabTech }).success(function (SalesInvoiceID) {
            generateLabReciept(model.AppointmentID);
            $scope.getAvailableLabs();
            clearFields();
            $rootScope.$emit("swAlertSave", {});
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        })
       }
   })
 }
    $scope.LabWalkin = {};
    $scope.MarkLabAsConfirmedLabWalkin = function (model) {
        $rootScope.$emit("swConfirmSave", {
            function() {
        $scope.LabWalkin = model;
                $http.post("/LabCashier/MarkLabAsConfirmedWalkin", { model: $scope.LabWalkin, Fees: $scope.LabWalkin.fees, IsLabRecep: $scope.Setting.IsSkipLabReceptionist, IsLabTec: $scope.Setting.IsSkipLabTech }).success(function (SalesInvoiceID) {
            generateLabForWalkInReciept(model.Grouped);
            $scope.getAvailableLabs();
            clearFields();
            $rootScope.$emit("swAlertSave", {});
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        })
      }
    })
   }
    function generateLabForWalkInReciept(Grouped) {
        var reportParams = {
            "Parms": {"Grouped": Grouped },
            "ReportName": "Report_GetLabsReceiptWalkIn.trdx"
        };

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {
            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }
    $scope.decodeHtml = function (html) {
        var txt = document.createElement("textarea");
        txt.innerHTML = html;
        return txt.value;
    }
    $scope.GetAvailableAppointmentPatientInsuranceCard = function () {
        $http.post('/AppointmentPayment/GetAvailableAppointmentPatientInsuranceCard', { id1: $scope.Appointment.PatientID, id2: $scope.Appointment.DoctorSpecialtiesID }).success(function (results) {
           // $scope.Appointment = model;
            $scope.AvalibleAppointmentPatientInsuranceCards = results;
           
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.LabReport = function (model) {
        var reportParams = {
            "Parms": { "AppointmentID": model.AppointmentID },
            "ReportName": "Report_GetLabs.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }
    $scope.clearInsurance = function () {
        $scope.Appointment.CalculatedFees = $scope.Appointment.AppointmentFees;
        //$scope.AvalibleAppointmentPatientInsuranceCards = [];
    }

    // dialogs 
    $scope.showInsurance = function (ev) {
        $scope.Appointment = ev;
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/AppointmentPaymentInsurance.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '#InsuranceButton',
            closeTo: '#InsuranceButton'
        })

    };
    $scope.showInsuranceLab = function (ev) {
        $scope.Labs = ev;
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/LabPaymentInsurance.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '#InsuranceButton1',
            closeTo: '#InsuranceButton1'
        })

    };
    $scope.hide = function () {
        $mdDialog.hide();
        $scope.AllergyType = {};
    };

    $scope.cancel = function () {
       // $scope.Appointment.PatientInsuranceID = {};
        $mdDialog.cancel();
        //$scope.AllergyType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };
    $scope.getAvailableLabs();
    $scope.savediag = function () {
        $scope.save();
    };
    $scope.InsuranceType = 1;
    $scope.AddInsurance = function (model) {
        //$scope.IsInsured = $rootScope.IsInsured;
        //$scope.Appointment.PatientInsuranceID = model.PatientInsuranceID;
        //$scope.Appointment.AppointmentID
        if ($rootScope.IsInsured == 1 || $rootScope.IsInsured == 2) {
            $scope.clearInsurance();
        }
        else if ($rootScope.IsInsured == 3)
        {
            $scope.Appointment.CalculatedFees = ($scope.Appointment.AppointmentFees * (100 - $scope.Appointment.PatientInsuranceID.CoveragePercentage)) / 100;
            $scope.Appointment.PatientInsuranceID = $scope.Appointment.PatientInsuranceID.PatientInsuranceID;
        }
        $http.post("AppointmentPayment/AddInsuranceType", { "AppointmentID": $scope.Appointment.AppointmentID, "InsuranceType": $rootScope.IsInsured }).success(function (SalesInvoiceID) {
            $scope.InsuranceType = $rootScope.IsInsured;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        })
        $mdDialog.hide();
    };
});