﻿var app = angular.module('globalApp', ['ngCookies', 'ngSanitize', 'ngLocalize',
                                        'angular-loading-bar', 'ngAnimate',
                                        'ngMessages', 'ngMaterial', 'md.data.table', 'angular.filter', 'lfNgMdFileInput']);




app.filter('trusted', ['$sce', function ($sce) {
    var div = document.createElement('div');
    return function (text) {
        div.innerHTML = text;
        return $sce.trustAsHtml(div.textContent);
    };
}]);
//////select menu////////////////////

$(function () {
    $(document).ready(function () {

        var url = window.location.href;

        var urlnew = url.split('?')[0];

        var urlnew2 = url.split('#')[0];

        // passes on every "a" tag
        //alert(url + "  " + (this.href));
        $("#menu  a").each(function () {

            // checks if its the same on the address bar
            // alert(url + "  " + (this.href));
            if (url.toLowerCase() == (this.href).toLowerCase() || urlnew.toLowerCase() == (this.href).toLowerCase() || urlnew2.toLowerCase() == (this.href).toLowerCase()) {

                $(this).closest("li").addClass("mm-selected");

                $(this).closest("li").parent("ul").parent("div").addClass("mm-selected");

                $(this).closest("li").parent("ul").parent("div").find("a span.arrow").addClass("mm-highest mm-current mm-opened");

            }
        });

    });
});

//////////////////////////////////

app.config(function ($mdThemingProvider) {

    $mdThemingProvider.theme('default')
      .primaryPalette('blue-grey', { 'default': '800' })
      .accentPalette('pink', { 'default': '900' });

});

app.config(function ($mdDateLocaleProvider) {
    $mdDateLocaleProvider.formatDate = function (date) {
        if (date != undefined) {
            var day = date.getDate();
            var monthIndex = date.getMonth();
            var year = date.getFullYear();
            return day + '/' + (monthIndex + 1) + '/' + year;
        }
        return null;
    };
});

app.config(function ($mdAriaProvider) {
    // Globally disables all ARIA warnings.
    $mdAriaProvider.disableWarnings();
});


function swAlertSaveAr() {
    swal({
        title: 'تم الحفظ بنجاح!',
        type: 'success',
        timer: 2000,
        confirmButtonText: ' موافق !',
        confirmButtonColor: '#3598DC',
    })
}

function swAlertSaveEn() {
    swal({
        title: 'Saved Done Successfully !',
        type: 'success',
        timer: 2000,
        confirmButtonText: ' Ok !',
        confirmButtonColor: '#3598DC',
    })
}


function swAlertErrorAr() {
    swal({
        title: 'حدث خطأ غير متوقع',
        type: 'error',
        timer: 2000,
        confirmButtonText: ' موافق !',
        confirmButtonColor: '#3598DC',
    })
}

function swAlertErrorEn() {
    swal({
        title: 'Unexpected Error Has Occurred',
        type: 'error',
        timer: 2000,
        confirmButtonText: ' Ok !',
        confirmButtonColor: '#3598DC',
    })
}

function ErrorCountAr() {
    swal({
        title: 'يجب حذف الموظفين أولا',
        type: 'error',
        timer: 4000,
        confirmButtonText: ' موافق !',
        confirmButtonColor: '#3598DC',
    })
}

function swConfirmDeleteAr(rAction) {
    swal({
        title: 'تأكيد المسح',
        text: "هذه العملية غير قابلة للرجوع",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#E35B5A',
        cancelButtonColor: '#BFBFBF',
        confirmButtonText: '<i class="fa fa-check"></i> احذف',
        cancelButtonText: 'الغاء <i class="fa fa-chevron-right"></i>'
    }).then(
    function () { rAction.function() })
}

function swConfirmDeleteEn(rAction) {
    swal({
        title: 'Delete Confirming',
        text: "This process is irreversible",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#E35B5A',
        cancelButtonColor: '#BFBFBF',
        confirmButtonText: '<i class="fa fa-check"></i> Delete',
        cancelButtonText: 'Cancel <i class="fa fa-chevron-right"></i>'
    }).then(
    function () { rAction.function() })
}




function swErrorLoginAr() {
    swal({
        title: 'خطأ في الدخول',
        text: "اسم المستخدم أو كلمة المرور غير صحيحة !",
        type: 'error',
        timer: 2000,
        confirmButtonText: 'موافق !',
        confirmButtonColor: '#3598DC',
    })
}
function swErrorLoginEn() {
    swal({
        title: 'Error Login',
        text: "Incorrect Username or Password !",
        type: 'error',
        timer: 2000,
        confirmButtonText: 'OK',
        confirmButtonColor: '#3598DC',
    })
}

function swErrorValidationEn() {
    swal({
        title: 'Validation Error',
        text: "Please check the invalid fields before proceeding",
        type: 'error',
        timer: 2000,
        confirmButtonText: 'OK',
        confirmButtonColor: '#3598DC',
    })
}

function swErrorValidationAr() {
    swal({
        title: 'خطأ فى الحقول',
        text: "تأكد من الحقول الغير صحيحة قبل المواصلة",
        type: 'error',
        timer: 2000,
        confirmButtonText: 'OK',
        confirmButtonColor: '#3598DC',
    })
}

function swConfirmActionAr(rAction) {
    swal({
        title: 'تأكيد العملية',
        text: 'لايمكن العوده بعد هذه العمليه',
        type: 'question',
        showCancelButton: true,
        confirmButtonColor: '#1E9765',
        cancelButtonColor: '#BFBFBF',
        confirmButtonText: '<i class="fa fa-check"></i> اتمام العملية',
        cancelButtonText: 'الغاء <i class="fa fa-chevron-right"></i>'
    }).then(
    function () { rAction.function() })
}

function swConfirmActionEn(rAction) {
    swal({
        title: 'Operation Confirmation',
        text: 'This Operation can not retry It ',
        type: 'question',
        showCancelButton: true,
        confirmButtonColor: '#1E9765',
        cancelButtonColor: '#BFBFBF',
        confirmButtonText: '<i class="fa fa-check"></i> Proceed',
        cancelButtonText: 'Cancel <i class="fa fa-chevron-right"></i>'
    }).then(
    function () { rAction.function(); })
}



function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function HideMasterShowDetails(panelToHide, panelToShow) {
    $(panelToHide).fadeOut(300, function () {
        $(panelToShow).fadeIn(300);
    });
}

function getArrayItemIndex(array, prop, val) {
    for (var i = 0, len = array.length; i < len; i++) {
        if (array[i].hasOwnProperty(prop) && array[i][prop] === val) {
            return i;
        }
    } return null;
}

function initMenuRTL() {
    var $menu = $("nav#menu").mmenu({
        "searchfield": {
            "placeholder": 'بحث..',
            "noResults": 'لا يوجد بيانات'
        },
        extensions: ['effect-slide-menu', 'shadow-page', 'shadow-panels', "effect-menu-zoom",
      "effect-panels-zoom", "pagedim-black", "theme-dark"],
        counters: true,
        navbar: {
            title: 'القائمة الرئيسية'
        },
        navbars: [
            {
                position: 'top',
                content: ['searchfield']
            }, {
                position: 'top',
                content: [
                    'prev',
                    'title',
                    'close'
                ]
            }
        ],
        "offCanvas": {
            "position": "right"
        },
        rtl: {
            use: true
        }
    });

   var $icon = $("#my-icon");
    var API = $menu.data("mmenu");

    $icon.on("click", function () {
        API.open();
    });

    API.bind("opened", function () {
        setTimeout(function () {
            $icon.addClass("is-active");
        }, 100);
    });
    API.bind("closed", function () {
        setTimeout(function () {
            $icon.removeClass("is-active");
        }, 100);
    });
    $('#menu').css("display", "");
}


app.controller('commonController', function ($scope, $http, $cookies, $timeout, $rootScope, $mdSidenav, $mdToast, $window, $mdDialog ) {
    $scope.rolePermission = {};
    $scope.MenuItems = [];
    $scope.user = {};
    $scope.AllNotifications = [];
    $scope.NotificationLoading = false;
    $scope.arabicValidationPattern = "^[\u0621-\u064A]+$";
    $scope.englishValidationPattern = "^[a-zA-Z]+$";
    $scope.User = {};
    

    $rootScope.Background = {};
    $scope.HMS_lang = $cookies.get('HMS_lang');    
    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };


    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1,
        filterJobOrdered: '',
        filterPurchaseDemanded: '',
        filterTransferOrdered: '',
        filterSupplyOrdered: '',
        filterProducted: '',
        filterExceptionalWarrantyed: '',
        filterClaimed: ''
    };

    $scope.RegisterPage = function ()
    {
        location.href = "/Register/index";
    }
    $scope.RedirectToLogin = function ()
    {
        location.href = "/Login/index";
    }
    LoadMenuItems();
    function LoadMenuItems() {
                $timeout(function () { initMenuRTL() }, 500);
           
        //$http.get('/api/ServiceCategory/Getmenue').success(function (results) {
        //    $scope.menuitems = results;
        //        $timeout(function () { initmenurtl() }, 500);
        //}).error(function () {
        //    $rootScope.$emit("swAlertError", {});
        //});
    }
    var t = $window.localStorage.getItem("user");

    if (t != null) {
        $scope.CurrentUser = JSON.parse(t);
       
    }

    $scope.checkLogin = function () {
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.user),
            url: '/api/Auth/WebLogin',
            success: function (data) {
                if (data != null) {
                    $scope.CurrentUser = data;
                    $window.localStorage.setItem("user", JSON.stringify(data));
                    window.location.href = "/home";
                }
                else {
                    swErrorLoginEn();
                    window.location.href = "/Login/index";
                }
            },
            error: function () {
                swAlertErrorAr();
            }
        });
    }
    $scope.Register = {};
    $scope.checkRegister = function () {
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Register),
            url: '/api/Auth/register',
            success: function (data) {
                if (data != null) {
                    $scope.CurrentUser = data;
                    $window.localStorage.setItem("user", JSON.stringify(data));
                    window.location.href = "/home";
                }
                else {
                    swAlertError();
                    window.location.href = "/Register/index";
                }
            },
            error: function () {
                swAlertErrorAr();
            }
        });
    }
    $scope.LogoutWeb = function () {
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.user),
            url: '/api/Auth/LogoutWeb',
            success: function (data) {
                if (parseInt(data) > 0) {
                    window.location.href = "/Login/index";
                }
                else {
                    swErrorLoginEn();
                }
            },
            error: function () {
                swAlertErrorEn();
            }
        });
    }

    $scope.LogoutCurrentUser = function () {
        window.location = "../../../../Login/LogOff";
    }

    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }

    $scope.formatDate = function (date) {
        if (date != undefined) {
            var dateOut = new Date(date);
            return dateOut;
        }
        return null;
    };

    $rootScope.$on("swConfirmSave", function (event,rAction) {
        if ($cookies.get('HMS_lang') == 'ar-EG') {
            swConfirmActionAr(rAction);
        } else {
            swConfirmActionEn(rAction);
        }
    });
    $rootScope.$on("swAlertSave", function () {
      
            swAlertSaveAr();
       
    });

    $rootScope.$on("swAlertError", function () {
       
            swAlertErrorAr();
      
    });

    $rootScope.$on("ErrorCount", function () {

        ErrorCountAr();

    });
    
    $rootScope.$on("swConfirmDelete", function (event, rAction) {
        
            swConfirmDeleteAr(rAction);
       
    });

   
    $scope.AllNewNotifications = { counter: 0 };
   
    InitiateSignalR();

    function InitiateSignalR() {
        if (typeof signalR !== "undefined") {
            // Reference the auto-generated proxy for the hub.  
            const connection = new signalR.HubConnectionBuilder()
                .withUrl("/SignalrHubs")
                .configureLogging(signalR.LogLevel.Information)
                .build();
            connection.on("ReceiveMessage", function (obj) {
                $scope.AllNewNotifications.counter++;
                $scope.$apply();
            });
            //connection.invoke("GetNewNotification", user, message);
            connection.start().then(function () {
                console.log("connected");
                
            });
        
        }
    };
    

    $scope.toggleRight = buildToggler('right');
    $scope.isOpenRight = function () {
        return $mdSidenav('right').isOpen();
    };



    $scope.redirectURL = function (model) {
        if (model.Url !== null) {
            $window.open(model.Url, '_blank');
        }

        $scope.MarkIsReadNotification(model);
    };
    

    $scope.UserProfile = function ()
    {
        window.location.href = '/Profile/index';

    }
    

    function buildToggler(navID) {
        return function () {
            // Component lookup should always be available since we are not using `ng-if`

            $mdSidenav(navID)
                .toggle()
                .then(function () {
                    // $log.debug("toggle " + navID + " is done");
                });
        };

    }

    var last = {
        bottom: true,
        top: false,
        left: false,
        right: true
    };

    $scope.toastPosition = angular.extend({}, last);

    $scope.getToastPosition = function () {
        sanitizePosition();

        return Object.keys($scope.toastPosition)
            .filter(function (pos) { return $scope.toastPosition[pos]; })
            .join(' ');
    };

    function sanitizePosition() {
        var current = $scope.toastPosition;

        if (current.bottom && last.top) current.top = false;
        if (current.top && last.bottom) current.bottom = false;
        if (current.right && last.left) current.left = false;
        if (current.left && last.right) current.right = false;

        last = angular.extend({}, current);
    }

    $scope.showSimpleToast = function (desc) {
        var pinTo = $scope.getToastPosition();

        $mdToast.show(
            $mdToast.simple()
                .textContent(desc)
                .position(pinTo)
                .hideDelay(30000)
        );
    };


});

function translateElement(text, callback) {
    Microsoft.Translator.translate(text,
                                                      'ar',
                                                      'en', '', '',
                                                      function (translation) {
                                                          callback(translation);
                                                      });
}
app.controller('RightCtrl', function ($scope, $timeout, $mdSidenav, $log) {
    $scope.close = function () {
        // Component lookup should always be available since we are not using `ng-if`
        $mdSidenav('right').close()
            .then(function () {
                $scope.NotificationLoading = true;
                //$log.debug("close RIGHT is done");
            });
    };
});

