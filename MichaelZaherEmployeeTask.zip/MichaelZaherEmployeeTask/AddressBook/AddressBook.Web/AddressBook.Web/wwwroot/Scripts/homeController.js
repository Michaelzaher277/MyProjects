﻿angular.module('globalApp')
    .controller('homeController', function ($scope, $http, $mdDialog, $cookies, $rootScope) {
       

});