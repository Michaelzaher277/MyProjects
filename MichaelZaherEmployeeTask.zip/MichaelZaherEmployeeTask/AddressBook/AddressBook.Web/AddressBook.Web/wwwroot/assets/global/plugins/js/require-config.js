requirejs.config({
    baseUrl: '../scripts'
});