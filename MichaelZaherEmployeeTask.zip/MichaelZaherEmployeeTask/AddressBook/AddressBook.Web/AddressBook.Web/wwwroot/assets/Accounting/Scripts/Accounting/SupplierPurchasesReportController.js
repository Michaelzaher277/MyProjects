﻿angular.module('globalApp')
.controller('SupplierPurchasesReportController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter, $element) {
    
    $scope.model = {};

    $scope.Suppliers = [];

    $scope.SupplierSearchTerm = '';

    $scope.clearSearchTerm = function () {
        $scope.SupplierSearchTerm = '';
    };

    $element.find('input#searchSuppliers').on('keydown', function (ev) {
        ev.stopPropagation();
    });

    $scope.loadSuppliers = function (viewValue) {
        $http.get('/Administration/Supplier/GetSuppliers').success(function (results) {
            $scope.Suppliers = results;

            for (var i = 0; i < $scope.Suppliers.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Suppliers[i].Title = $scope.Suppliers[i].NameAr;
                }
                else {
                    $scope.Suppliers[i].Title = $scope.Suppliers[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.checkReport = function (model) {

        if (model.Supplier != undefined) {

            model.SupplierName = model.Supplier.NameAr;
            model.SupplierID =model.Supplier.SupplierID;

        }
        else {
            model.SupplierName = '';
            model.SupplierID = 0;
        }

        var 
            reportParams = {
                "Parms": { "DateFrom": $filter('date')(model.DateFrom, "yyyy-MM-dd"), "DateTo": $filter('date')(model.DateTo, "yyyy-MM-dd")
                                ,"SupplierName":model.SupplierName,"SupplierID":model.SupplierID},
                "ReportName": "PurchaseReport/SupplierPurchasesReport.trdx"
        };

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }

    $scope.clearFields = function () {
        $scope.model = {};        
    }

});