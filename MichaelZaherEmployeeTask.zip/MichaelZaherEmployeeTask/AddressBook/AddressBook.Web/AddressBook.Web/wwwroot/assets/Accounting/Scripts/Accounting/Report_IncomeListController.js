﻿angular.module('globalApp')
.controller('Report_IncomeListController', function ($scope, $mdDialog, $http, $rootScope) {


    $scope.model = {};

    if ($scope.model.DateFrom == undefined) {
        //$scope.model.DateFrom = new Date('01/01/1999');
        $scope.model.DateFrom = new Date();
    };

    if ($scope.model.DateTo == undefined) {
        //$scope.model.DateTo = new Date('01/01/2020');
        $scope.model.DateTo = new Date();
    };


    $scope.clearFields = function () {
        $scope.model = {};
    };


    $scope.checkReport = function (model) {
        var reportParams = {
            "Parms": { "DateFrom": model.DateFrom, "DateTo": model.DateTo },
            "ReportName": "ReportIncomeList.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }

});