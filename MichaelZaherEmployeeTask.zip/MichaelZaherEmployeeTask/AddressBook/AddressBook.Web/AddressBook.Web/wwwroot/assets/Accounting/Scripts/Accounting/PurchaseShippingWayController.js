﻿
angular.module('globalApp')
.controller('PurchaseShippingWayController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.PurchaseShippingWays = [];
    $scope.PurchaseShippingWay = {};

    $scope.selected = [];

    getPurchaseShippingWays();
  

    function getPurchaseShippingWays() {
        $http.get('/PurchaseShippingWay/getPurchasesShippingWays').success(function (results) {
            $scope.PurchaseShippingWays = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/PurchaseShippingWay.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom : '.addButton',
            closeTo: '.addButton'
        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/PurchaseShippingWay.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.PurchaseShippingWay = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.PurchaseShippingWay = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.PurchaseShippingWay),
            url: '/PurchaseShippingWay/savePurchasesShippingWay',
            success: function () {
                getPurchaseShippingWays();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.delete = function () {
        
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/PurchaseShippingWay/deletePurchaseShippingWay', JSON.stringify($scope.selected)).success(function () {
                       getPurchaseShippingWays();
                       $scope.selected = [];
                   });
               }
           });
    }

    $scope.edit = function (ShippingWayID) {
        $http.get('/PurchaseShippingWay/getPurchaseShippingWayByID/' + ShippingWayID).success(function (data) {
            $scope.PurchaseShippingWay = data;
            $scope.showAdvancedEdit();
        });
    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});