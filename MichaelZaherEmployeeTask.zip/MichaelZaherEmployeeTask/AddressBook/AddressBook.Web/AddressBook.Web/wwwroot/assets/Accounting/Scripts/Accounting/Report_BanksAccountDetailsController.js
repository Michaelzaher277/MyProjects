﻿angular.module('globalApp')
    .controller('Report_BanksAccountDetailsController', function ($scope, $mdDialog, $http, $rootScope, $filter, $cookies) {

        $scope.Banks = [];
        $scope.BankBranches = [];
        $scope.BankBranchAccounts = [];

        $scope.model = {};

        if ($scope.model.DateFrom == undefined) {
            //$scope.model.DateFrom = new Date('01/01/1999');
            $scope.model.DateFrom = new Date();
        };

        if ($scope.model.DateTo == undefined) {
            //$scope.model.DateTo = new Date('01/01/2020');
            $scope.model.DateTo = new Date();
        };

        $scope.clearFields = function () {
            $scope.model = {};
        };

        // Bank Branches Functions
        $scope.getBanks = function () {
            $http.get('/Accounting/Banks/getBanks').success(function (results) {
                $scope.Banks = results;
                for (var i = 0; i < $scope.Banks.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Banks[i].Title = $scope.Banks[i].NameAr;
                    }
                    else {
                        $scope.Banks[i].Title = $scope.Banks[i].NameEn;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };


        $scope.getBankBranches = function (id) {
            if (id != undefined) {
                $http.get('/Accounting/BankBranches/getBankBranchesByBankID/' + id).success(function (results) {
                    $scope.BankBranches = results;
                    for (var i = 0; i < $scope.BankBranches.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.BankBranches[i].Title = $scope.BankBranches[i].NameAr;
                        }
                        else {
                            $scope.BankBranches[i].Title = $scope.BankBranches[i].NameEn;
                        }
                    }
                    $scope.BranchID = null;
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        };

        $scope.getBankBranchAccounts = function (id) {
            if (id != undefined) {
                $http.get('/Accounting/BankBranchAccounts/getBankBranchAccountsByBankBranchID/' + id).success(function (results) {
                    $scope.BankBranchAccounts = results;
                    for (var i = 0; i < $scope.BankBranchAccounts.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameAr;
                        }
                        else {
                            $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameEn;
                        }
                    }
                    $scope.BranchID = null;
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        };

        $scope.checkReport = function (model) {

            if ($scope.model.DateFrom == undefined) {
                $scope.model.DateFrom = null;
            }

            if ($scope.model.DateTo == undefined) {
                $scope.model.DateTo = null;
            }

            if ($scope.model.Bank == undefined || $scope.model.Bank == 'None') {
                $scope.model.BankID = 0;
                $scope.model.BankName = "كل البنوك";
            }
            else {

                if ($scope.model.Bank.BankID == 'None') {
                    $scope.model.BankID = 0;
                }
                else {
                    $scope.model.BankID = $scope.model.Bank.BankID;
                    $scope.model.BankName = $scope.model.Bank.NameAr;
                }
            }


            if ($scope.model.BankBranch == undefined || $scope.model.BankBranch == 'None') {
                $scope.model.BankBranchID = 0;
                $scope.model.BankBranchName = "كل الفروع";
            }
            else {

                if ($scope.model.BankBranch.BankBranchID == 'None') {
                    $scope.model.BankBranchID = 0;
                }
                else {
                    $scope.model.BankBranchID = $scope.model.BankBranch.BankBranchID;
                    $scope.model.BankBranchName = $scope.model.BankBranch.NameAr;
                }
            }

            if ($scope.model.BankBranchAccount == undefined || $scope.model.BankBranchAccount == 'None') {
                $scope.model.BankBranchAccountID = 0;
                $scope.model.BankBranchAccountName = "كل الحسابات";
            }
            else {

                if ($scope.model.BankBranchAccount.BankBranchAccountID == 'None') {
                    $scope.model.BankBranchAccountID = 0;
                }
                else {
                    $scope.model.BankBranchAccountID = $scope.model.BankBranchAccount.BankBranchAccountID;
                    $scope.model.BankBranchAccountName = $scope.model.BankBranchAccount.NameAr;
                }
            }

            var reportParams = {
                "Parms": { "DateFrom": $filter('date')(model.DateFrom, "yyyy-MM-dd"), "DateTo": $filter('date')(model.DateTo, "yyyy-MM-dd"), "BankID": model.BankID, "BankName": $scope.model.BankName, "BankBranchID": model.BankBranchID, "BankBranchName": $scope.model.BankBranchName, "BankBranchAccountID": model.BankBranchAccountID, "BankBranchAccountName": $scope.model.BankBranchAccountName },
                "ReportName": "BanksAccountDetailsRepeort.trdx"
            };

            //$("#reportTest").load('/report', JSON.stringify(reportParams));

            $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

                var x = window.open();
                x.document.open();
                x.document.write(results);
                x.document.close();

                //$('#reportTest').html(results);
            })
        }
    });