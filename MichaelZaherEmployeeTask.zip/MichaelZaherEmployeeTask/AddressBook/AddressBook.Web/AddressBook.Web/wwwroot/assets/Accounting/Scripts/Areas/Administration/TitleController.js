﻿
angular.module('globalApp')
.controller('TitleController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.Titles = [];
    $scope.Title = {};

    $scope.selected = [];


    $scope.query = {
        order: 'name',
        limit: 2,
        page: 0
    };

    getTitle();



    function getTitle() {
        $http.get('/Title/getTitles').success(function (results) {
            $scope.Titles = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/Title.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        })
    };



    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/Title.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Title = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Title = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Title),
            url: '/Title/saveTitle',
            success: function () {
                getTitle();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {
        swConfirmDeleteEn(function () {
            $http.post('/Title/deleteTitle', JSON.stringify($scope.selected)).success(function () {
                getTitle();
                $scope.selected = [];
            });
        });
    }
    $scope.edit = function (TitleID) {
        $http.get('/Title/getTitleByID/' + TitleID).success(function (data) {
            $scope.Title = data;
            $scope.showAdvancedEdit();
        });
    };
    $scope.deleteRowCallback = function (rows) {
        swConfirmDeleteWithActions(function () {
            for (var i = 0; i < rows.length; i++) {
                $scope.selected.push({ TitleID: rows[i], IsDeleted: false });
            }
            //= rows;
            $http.post('/Administration/Title/deleteTitle', JSON.stringify($scope.selected)).success(function () {

                getTitle();
                $scope.selected = [];
            });
        }, function () {
            $http.get('/Administration/Title/getTitles').success(function (results) {
                $scope.Titles = results;
            }).error(function () {
                swAlertErrorAr();
            });
        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

});