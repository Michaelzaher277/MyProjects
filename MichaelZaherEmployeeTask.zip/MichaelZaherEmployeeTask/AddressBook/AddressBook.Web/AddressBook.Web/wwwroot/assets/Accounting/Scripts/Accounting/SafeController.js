﻿angular.module('globalApp')
.controller('SafeController', function ($scope, $mdToast, $mdDialog, $http, $cookies, $rootScope) {
    //$scope.ChartOfAccounts = [];

    //$scope.ChartOfAccount = { IsGroup: true };
    //$scope.ChartOfAccountsFilter = "";
    $scope.Safe = {};
    $scope.Safes = [];
    $scope.selected = [];

    $scope.Branches = [];

    $scope.AutoTransactionSettings = [];
    $scope.AutoTransactionSetting = {};

    $scope.Currencies = [];

    // Account Setting
    //$scope.ChartOfAccounts = [];

    //$scope.ChartOfAccount = { IsGroup: true };
    //$scope.ChartOfAccountsFilter = "";

    //// Account Setting Detail
    //$scope.ChartOfAccountsDetails = [];

    //$scope.ChartOfAccountDetail = { IsGroup: true };
    //$scope.ChartOfAccountsFilterDetail = "";
    //getChartOfAccountTree();
    //getChartOfAccountTreeDetail();

    getSafes();
    getBranches();
    loadCurrencies();
   
    function loadCurrencies() {
        if ($scope.Currencies.length <= 0) {
            $http.get('/Accounting/Currency/GetCurrencies').success(function (results) {
                $scope.Currencies = results;
                for (var i = 0; i < $scope.Currencies.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                    }
                    else {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                    }
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    }

    $scope.ChangeChecked = function () {
        if (!$scope.ChooseAccount) {
            $scope.Safe.ChartOfAccountID = null;
            $scope.Safe.AccountCode = null;
            $scope.Safe.ChartOfAccount_CashNameAr = ''

        }
    }

    $scope.ChartOfAccounts = [];
    $scope.AddNewAutoTransactionSetting = function () {
        if ($scope.ChartOfAccounts.length <= 0) {
            $scope.getChartOfAccountTree();
        }
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        });
    }

    function getChartOfAccountTreeDetail() {
        $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
            $scope.ChartOfAccountsDetails = results.treeObj;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.selectNode = function (node) {
        $scope.ChartOfAccount = node.$modelValue;
    }

    $scope.findNodes = function (item) {
        $scope.ChartOfAccountsFilter = item.ChartOfAccountsFilter;
    };

    $scope.chooseChartOfAccount = function () {
        $scope.Safe.ChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.Safe.ChartOfAccount_CashNameAr = ($cookies.get('ERP_lang') == 'ar-EG') ? $scope.ChartOfAccount.AccountArabicName : $scope.ChartOfAccount.AccountEnglishName;
        $scope.Safe.AccountCode = $scope.ChartOfAccount.AccountCode;
        $scope.cancelChartOfAccountsDialog();
    };

    $scope.FilterChartOfAccounts = function (item) {
        return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
    };

    $scope.cancelChartOfAccountsDialog = function () {
        $mdDialog.cancel();
        //$scope.ChartOfAccount = { IsGroup: true };
        $scope.ChartOfAccountsFilter = "";
    };



    function getBranches() {
        $http.get('/HR/Branch/GetBarnches').success(function (results) {
            $scope.Branches = results;


        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function getSafes() {
        $http.get('/Accounting/Safe/getSafes').success(function (results) {
            $scope.Safes = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Safe),
            url: '/Accounting/Safe/saveSafe',
            success: function () {
                $rootScope.$emit("swAlertSave", {});
               
                getSafes();
                $scope.clearFields();
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };



    $scope.edit = function (SafeID) {
        $http.get('/Accounting/Safe/getSafeByID/' + SafeID).success(function (data) {
            $scope.Safe = data;
            //$scope.showAdvancedEdit();
        });
    };

    

    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Accounting/Safe/deleteSafe', JSON.stringify($scope.selected)).success(function () {
                       getSafes();
                       $scope.selected = [];
                   });
               }
           });
    }

    $scope.clearFields = function () {
        HideMasterShowDetails('#divDetails', '#divMain');
        $scope.Safe = {};
        $scope.selected = [];
        $scope.edit.show = false;
    };


    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
  
});