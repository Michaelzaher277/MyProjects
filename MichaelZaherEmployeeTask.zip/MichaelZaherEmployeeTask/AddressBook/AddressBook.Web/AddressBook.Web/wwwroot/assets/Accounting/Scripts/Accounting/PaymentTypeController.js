﻿
angular.module('globalApp')
.controller('PaymentTypeController', function ($scope, $mdDialog, $http, $rootScope,$cookies) {

    $scope.PaymentTypes = [];
    $scope.PaymentType = {};

    $scope.selected = [];

    getPaymentTypes();


    function getPaymentTypes() {
        $http.get('/Accounting/PaymentType/GetPaymentTypes').success(function (results) {
            $scope.PaymentTypes = results;

            for (var i = 0; i < $scope.PaymentTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameAr;
                }
                else {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameEng;
                }
            }
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/Accounting/templates/PaymentType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom : '.addButton',
            closeTo: '.addButton'
        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/Accounting/templates/PaymentType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.PaymentType = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.PaymentType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };

    $scope.save = function () {
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.PaymentType),
            url: '/Accounting/PaymentType/save',
            success: function () {
                getPaymentTypes();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function (PaymentTypeID) {
        
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.get('/Accounting/PaymentType/delete/' + PaymentTypeID).success(function (data) {
                       if (parseInt(data) == -1) {
                           swSorryMessageAr();
                       }
                       getPaymentTypes();
                       $scope.selected = [];
                   });
               }
           });
    }
    $scope.edit = function (PaymentTypeID) {
        $http.get('/Accounting/PaymentType/GetByID/' + PaymentTypeID).success(function (data) {
            $scope.PaymentType = data;
            $scope.showAdvancedEdit();
        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});