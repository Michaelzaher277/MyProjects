﻿angular.module('globalApp')
    .controller('OpeningBalanceController', function ($scope, $mdDialog, $http, $rootScope, $cookies) {
        //Chart Of Accounts Variables
        $scope.ChartOfAccounts = [];
        //$scope.ChartOfAccount = {};
        $scope.ChartOfAccountScope = {};
        $scope.ChartOfAccountList = [];

        $scope.OpeningBalance = {};

        $scope.getCurrency = function (CurrencyID) {
            $http.get('/Currency/getCurrencyByID?id=' + CurrencyID).success(function (data) {
                $scope.OpeningBalance.Currency_Convert = data.ConvertValue;
            });
        };

        // run at start
        $scope.getChartOfAccountTree();

        // Tree Functions
        $("#ChartOfAccount").on('click', function (e) {
            if ($scope.ChartOfAccount.ChartOfAccountID != null) {
                if ($scope.OpeningBalanceForm.$dirty) {
                    $rootScope.$emit("swConfirmDirty",
                        {
                            function() {
                                $scope.OpeningBalance = {};
                                //$scope.ChartOfAccount = node.$modelValue;
                                //$scope.ChartOfAccountScope = node;
                                $scope.getCurrencies();
                                loadAccountOpeningBalanceByAccountID();
                                $scope.OpeningBalanceForm.$setPristine();
                                $scope.OpeningBalanceForm.$setUntouched();
                            }
                        });
                }
                else {
                    $scope.OpeningBalance = {};
                    //$scope.ChartOfAccount = node.$modelValue;
                    //$scope.ChartOfAccountScope = node;
                    $scope.getCurrencies();
                    loadAccountOpeningBalanceByAccountID();                    
                    $scope.OpeningBalanceForm.$setPristine();
                    $scope.OpeningBalanceForm.$setUntouched();
                }
            }
        });

        $scope.toggle = function (scope) {
            scope.toggle();
        };

        function loadAccountOpeningBalanceByAccountID() {
            if ($scope.ChartOfAccount.IsGroup == false) {
                $http.get('/Accounting/OpeningBalance/loadAccountOpeningBalanceByAccountID/' + $scope.ChartOfAccount.ChartOfAccountID).success(function (results) {
                    if (results.AccountingSubPeriodID != undefined) {
                        $scope.OpeningBalance = results;
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        }

        // ---------------------------------- this function transfer to app.js -----------------------------------------
        //function getChartOfAccountTree() {
        //    $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
        //        $scope.ChartOfAccounts = results.treeObj;
        //        $scope.ChartOfAccountList = results.treeList;
        //    }).error(function () {
        //        $rootScope.$emit("swAlertError", {});
        //    });
        //};

        $scope.save = function () {

            if ($scope.OpeningBalance.CharOfAccountsOpeningBalanceID == undefined) {
                $scope.OpeningBalance.ChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
            }

            $scope.OpeningBalance.AccountingSubPeriodID = CurrentAccountingSubPeriodID;

            $http.post('/Accounting/OpeningBalance/saveOpeningBalance', $scope.OpeningBalance).success(function (results) {
                $rootScope.$emit("swAlertSave", {});
                $scope.OpeningBalance = {};
                // $scope.ChartOfAccount = {};
                $scope.ChartOfAccountScope = {};
                $scope.getCurrencies();
                loadAccountOpeningBalanceByAccountID();                
                $scope.OpeningBalanceForm.$setPristine();
                $scope.OpeningBalanceForm.$setUntouched();
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });

        }

        $scope.cancel = function () {
            $scope.OpeningBalance = {};
            $scope.ChartOfAccount = {};
            $scope.ChartOfAccountScope = {};
            $scope.OpeningBalanceForm.$setPristine();
            $scope.OpeningBalanceForm.$setUntouched();
        }

        $scope.getCurrencies = function () {
            $http.get('/Currency/GetCurrencies').success(function (results) {
                $scope.Currencies = results;

                for (var i = 0; i < $scope.Currencies.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                    }
                    else {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                    }
                }
            }).error(function (data, status, headers, config) {
                $rootScope.$emit("swAlertError", {});
            });
        };

    });