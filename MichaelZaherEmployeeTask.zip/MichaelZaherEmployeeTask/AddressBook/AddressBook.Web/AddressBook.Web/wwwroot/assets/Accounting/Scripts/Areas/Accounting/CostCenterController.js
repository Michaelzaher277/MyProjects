﻿angular.module('globalApp')
    .controller('CostCenterController', function ($scope, $mdDialog, $http, $rootScope, $cookies) {
        var CostCenterTree,nextId = 0;
        $scope.CostCenters = [];
        $scope.CostCenter = {};
        $scope.CostCenterScope = {};
        $scope.CostCenterList = [];

        $scope.TreeIsValidate = true;

        // Tree Functions
        getCostCenterTree();
        $scope.selectNode = function (node) {
            $scope.CostCenter = node.$modelValue;
            $scope.CostCenterScope = node;
            $scope.accountForm.$setPristine();
            $scope.accountForm.$setUntouched();
            validateTree();
        }
        $scope.toggle = function (scope) {
            scope.toggle();
        };

        function openNode(id, select) {
            for (var i = 0; i < CostCenterTree.length; i++)
                if (CostCenterTree[i].id == id) {
                    CostCenterTree[i].state = { "opened": true, "selected": select };
                    if (CostCenterTree[i].parent != null)
                        openNode(CostCenterTree[i].parent, false);
                    break;
                }
        }

        function loadCostCenter(data) {
            $scope.CostCenter = data;  
            $scope.$apply();
            $scope.accountForm.$setPristine();
            $scope.accountForm.$setUntouched();
        }

        $scope.createSubParentAccount = function () {
            nextId++;
            CostCenterTree.push({
                id: nextId,
                text: ($cookies.get('ERP_lang') == 'ar-EG') ? 'حساب رئيسى جديد' : 'New Parent-Account',
                parent: $scope.CostCenter.CostCenterID,
                type: 'parent'
            });
            $scope.CostCenter = {
                CostCenterID: nextId,
                CostCenterEnglishName: 'حساب رئيسى جديد',
                CostCenterArabicName: 'New Parent-Account',
                CostCenterCode: "",
                IsGroup: true,
                ParentID: $scope.CostCenter.CostCenterID,
                Credit_OpeningBalance: 0,
                Debit_OpeningBalance: 0
            };
            $scope.CostCenterList.push($scope.CostCenter);
            openNode($scope.CostCenter.CostCenterID, true);
            loadJsTree();
            loadCostCenter($scope.CostCenter);
            //$scope.CostCenter.Children.push({
            //    Name: 'New Parent-Account',
            //    ParentID: $scope.CostCenter.CostCenterID,
            //    Children: [],
            //    IsGroup: true
            //});
            //validateTree();
        }
        $scope.createSubAccount = function () {
            nextId++;
            CostCenterTree.push({
                id: nextId,
                text: ($cookies.get('ERP_lang') == 'ar-EG') ? 'حساب فرعي جديد' : 'New Sub-Account',
                parent: $scope.CostCenter.CostCenterID,
                type: 'parent'
            });
            $scope.CostCenter = {
                CostCenterID: nextId,
                CostCenterEnglishName: 'حساب فرعي جديد',
                CostCenterArabicName: 'New sub-Account',
                CostCenterCode: "",
                IsGroup: false,
                ParentID: $scope.CostCenter.CostCenterID,
                Credit_OpeningBalance: 0,
                Debit_OpeningBalance: 0
            };
            $scope.CostCenterList.push($scope.CostCenter);
            openNode($scope.CostCenter.CostCenterID, true);
            loadJsTree();
            loadCostCenter($scope.CostCenter);
            //$scope.CostCenter.Children.push({
            //    Name: 'New Sub-Account',
            //    ParentID: $scope.CostCenter.CostCenterID,
            //    Children: [],
            //    IsGroup: false
            //});
            //validateTree();
        }
        //$scope.createMainSubParentAccount = function () {
        //    $scope.CostCenters.push({
        //        Name: 'New Parent-Account',
        //        Children: [],
        //        IsGroup: true
        //    });
        //    validateTree();
        //}
        //$scope.createMainSubAccount = function () {
        //    $scope.CostCenters.push({
        //        Name: 'New Sub-Account',
        //        Children: [],
        //        IsGroup: false
        //    });
        //    validateTree();
        //}
        $scope.deleteSelectedNode = function (account) {            
            $rootScope.$emit("swConfirmDelete",
                {
                    function() {
                        if (account.CostCenterID != undefined) {
                            $http.get('/Accounting/CostCenter/deleteCostCenterByAccountID/' + account.CostCenterID).success(function () {
                                getCostCenterTree();
                                $scope.CostCenter = {};
                                $scope.CostCenterScope = {};
                            }).error(function () {
                                $rootScope.$emit("swAlertError", {});
                            });
                        } else {
                            $scope.CostCenterScope.remove();
                            $scope.CostCenterScope = {};
                        }
                    }
                });
        }
        $scope.saveTree = function () {
            $scope.accountForm.$setSubmitted();
            validateTree();
            if ($scope.TreeIsValidate) {
                $http.post('/Accounting/CostCenter/updateTree', $scope.CostCenterList).success(function () {
                    $rootScope.$emit("swAlertSave", {});
                    getCostCenterTree();
                    $scope.CostCenter = {};
                    $scope.accountForm.$setPristine();
                    $scope.accountForm.$setUntouched();
                    validateTree();
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            } else {
                $rootScope.$emit("swErrorValidation", {});
            }
        }

        function loadJsTree() {
            $("#CostCenter").jstree('destroy');
            $("#CostCenter").on('changed.jstree', function (e, data) {
                if (data.selected.length > 0) {
                    for (var i = 0; i < $scope.CostCenterList.length; i++)
                        if ($scope.CostCenterList[i].CostCenterID == data.selected[data.selected.length - 1])
                            loadCostCenter($scope.CostCenterList[i]);
                }
            }).jstree({
                'core': {
                    'data': CostCenterTree,
                    "multiple": false,
                },
                "checkbox": {
                    "keep_selected_style": false,
                    "three_state": false,
                },
                "plugins": ["checkbox"]
            });
        }

        function getCostCenterTree() {
            $http.get('/Accounting/CostCenter/getCostCenterTre').success(function (results) {
                CostCenterList = results;
                $('#CostCenterChoose').prop('disabled', true);
                $scope.CostCenter = { IsGroup: true };
                CostCenterTree = new Array();
                for (var i = 0; i < results.length; i++) {
                    var temp = { "id": results[i].CostCenterID };
                    ($cookies.get('ERP_lang') == 'ar-EG') ? temp.text = results[i].CostCenterArabicName : results[i].CostCenterEnglishName
                    temp.parent = (results[i].ParentID == null) ? "#" : results[i].ParentID;
                    temp.state = (results[i].ParentID == null) ? { "opened": true } : null;
                    var check = false;
                    for (var m = 0; m < results.length; m++)
                        if (results[m].ParentID == temp.id)
                            check = true;
                    temp.icon = (check) ? null : "/Areas/Accounting/assets/images/file.png";
                    CostCenterTree.push(temp);
                }
                nextId = results[results.length - 1].CostCenterID;
                loadJsTree();
                $scope.CostCenterList = results;
                //$scope.CostCenters = results.treeObj;
                //$scope.CostCenterList = results.treeList;
                //validateTree();
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };
        function validateTree() {
            $scope.TreeIsValidate = true;
            $.each($scope.CostCenters, function (i, item) {
                if (!item.ParentID) {
                    if (item.CostCenterArabicName && item.CostCenterEnglishName && item.CostCenterArabicDisplayPath && item.CostCenterEnglishDisplayPath && item.CostCenterCode) {
                        item.isValidate = true;
                        item.AccountCodeIsNotValidate = false;
                        $.each($scope.CostCenterList, function (i, accItem) {
                            if (accItem.CostCenterCode == item.CostCenterCode && accItem.CostCenterID != item.CostCenterID) {
                                $scope.TreeIsValidate = false;
                                item.AccountCodeIsNotValidate = true;
                                item.isValidate = false;
                            }
                        });
                    }
                    else {
                        item.isValidate = false;
                        $scope.TreeIsValidate = false;
                    }
                    if (item.Children != null) {
                        validateTreeChildren(item.Children);
                    }
                }
            });
        }
        function validateTreeChildren(account) {
            $.each(account, function (i, item) {
                if (item.CostCenterArabicName && item.CostCenterEnglishName && item.CostCenterArabicDisplayPath && item.CostCenterEnglishDisplayPath && item.CostCenterCode) {
                    item.isValidate = true;
                    item.AccountCodeIsNotValidate = false;
                    $.each($scope.CostCenterList, function (i, accItem) {
                        if (accItem.CostCenterCode == item.CostCenterCode && accItem.CostCenterID != item.CostCenterID) {
                            $scope.TreeIsValidate = false;
                            item.AccountCodeIsNotValidate = true;
                            item.isValidate = false;
                        }
                    });
                }
                else {
                    item.isValidate = false;
                    $scope.TreeIsValidate = false;
                }
                if (item.Children != null) {
                    validateTreeChildren(item.Children);
                }
            });
        }

        // Drop Down List Functions
        $scope.checkAccountCode = function () {
            validateTree();
        }
    });