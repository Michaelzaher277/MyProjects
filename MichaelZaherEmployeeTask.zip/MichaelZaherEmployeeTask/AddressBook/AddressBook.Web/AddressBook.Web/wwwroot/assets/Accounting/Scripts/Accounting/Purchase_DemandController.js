﻿
angular.module('globalApp')
.controller('Purchase_DemandController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter) {

    $scope.Purchase_Demands = [];
    $scope.Purchase_Demand = {};
    $scope.filterJobOrdered = '';

    $scope.selected = [];
    $scope.selectedProduct = [];
    $scope.selectedDetails = [];
    $scope.selectedClaim = [];
    $scope.selectedSupplyOrder = [];
    $scope.selectedTransferOrder = [];
    $scope.selectedExceptionalWarranty = [];
    $scope.selectedJobOrder = [];

    $scope.JOWorkDone = {};
    $scope.JobOrderDetails = [];
    $scope.ExceptionalWarrantyDetails = [];
    $scope.Warranties = [];
    $scope.Transfers = [];
    $scope.Claims = [];

    $scope.SupplyOrders = [];
    $scope.AddNew = false;

    getPurchase_Demands();
    getJobOrderToDoWorks();

    $scope.Purchase_DemandDetail = {};
    $scope.Purchase_DemandDetails = [];

    //$scope.Products = [];

    $scope.Product = {};
    $scope.MeasureUnits = [];

    $scope.Total = 0;

    $scope.JobOrderToDoWorks = [];

    function getJobOrderToDoWorks() {
        $http.get('/JobOrder/JobOrderToDoWork/getAllJobOrderNotLinkedPurchaseDemand').success(function (results) {
            $scope.JobOrderToDoWorks = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    //function success(desserts) {
    //    $scope.desserts = ['christian', 'Non-christian'];
    //}

    //$scope.getDesserts = function () {
    //  $scope.promise = $nutrition.desserts.get($scope.query, success).$promise;
    //};


    function getLastCodeDemands() {
        $http.get('/Purchase_Demand/GetLastCodeDemands').success(function (results) {
            $scope.Purchase_Demand.DemandCode = results;
            //var today = $filter('date')(new Date(), 'yyyy-MM-dd');
            $scope.Purchase_Demand.DemandDate = new Date();;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    function getPurchase_Demands() {
        $http.get('/Purchase_Demand/GetALLDemands').success(function (results) {
            $scope.Purchase_Demands = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        //  $("DivShow)

        //$scope.AddNew = true;

        HideMasterShowDetails('#DivShow', '#DivSave');
        getLastCodeDemands();

        $scope.Total = 0;

        //$mdDialog.show({
        //    scope: $scope.$new(),
        //    templateUrl: '../../Areas/accounting/templates/Purchase_Demand.tmpl.html',
        //    onRemoving: function () {
        //        $scope.cancel();
        //    },
        //    clickOutsideToClose: true,
        //    openFrom : '.addButton',
        //    closeTo: '.addButton'
        //})

    };

    function getMeasureUnit(productID) {
        $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
            $scope.MeasureUnits = results;
            for (var i = 0; i < $scope.MeasureUnits.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
                }
                else {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };


    $scope.getProductModal = function (modal) {

        for (i = 0; i < modal.length; i++) {
            if (modal[i].ProductID != null) {
                var item = {};
                item.ProductID = modal[i].ProductID;
                item.ProductName = modal[i].NameAr;
                item.ProductCode = modal[i].Code;
                item.MeasureUnits = modal[i].MeasureUnits;

                for (var j = 0; j < item.MeasureUnits.length; j++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                    }
                    else {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                    }
                }

                var foundItem = $filter('filter')($scope.Purchase_DemandDetails, { ProductCode: modal[i].Code }, true)[0];

                if (foundItem == undefined) {
                    $scope.Purchase_DemandDetails.push(item);
                }

                //$scope.Purchase_DemandDetails.push(item);

            }
        }

        $scope.selectedProduct = [];
        $scope.selectedClaim = [];
        $scope.selectedSupplyOrder = [];
        $scope.selectedTransferOrder = [];
        $scope.selectedExceptionalWarranty = [];
        $scope.selectedJobOrder = [];

        //$scope.cancelProduct();

        // $('#DivParts').modal('toggle');

    };

    $scope.getAllProductsModal = function () {
        $http.get('/Inventory/ProductDetails/GetProducts').success(function (results) {
            $scope.Products = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    $scope.showProductsAdd = function (ev) {
        //  $("DivShow)
        //   $scope.Purchase_OrderDetails.push({});
        //$scope.getAllProductsModal();

        $scope.GetTopProducts("");   ///app.js
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadProducts.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addProduct',
            closeTo: '.addProduct'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Purchase_Demand = {};
    };

    $scope.cancelDialog = function () {
        $mdDialog.cancel();
        $scope.Total = 0;
    };

    $scope.cancelProduct = function () {
        //$scope.AddNew = true;

        $mdDialog.cancel();
        $scope.selectedProduct = [];
        $scope.selectedClaim = [];
        $scope.selectedSupplyOrder = [];
        $scope.selectedTransferOrder = [];
        $scope.selectedExceptionalWarranty = [];
        $scope.selectedJobOrder = [];

        //   $scope.Purchase_Demand = {};
    };

    $scope.cancelPurchase_Demand = function () {
        //   $mdDialog.cancel();

        //$scope.AddNew = false;

        HideMasterShowDetails('#DivSave', '#DivShow');

        $scope.selected = [];
        $scope.selectedProduct = [];
        $scope.selectedDetails = [];
        $scope.selectedClaim = [];
        $scope.selectedSupplyOrder = [];
        $scope.selectedTransferOrder = [];
        $scope.selectedExceptionalWarranty = [];
        $scope.selectedJobOrder = [];

        $scope.Purchase_Demand = {};
        $scope.Purchase_DemandDetails = [];

    };


    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {
        $scope.Purchase_Demand.Purchase_DemandDetail = $scope.Purchase_DemandDetails;
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Purchase_Demand),
            url: '/Purchase_Demand/save',
            success: function () {
                getPurchase_Demands();
                getJobOrderToDoWorks();

                $scope.cancelPurchase_Demand();

                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Purchase_Demand/deletePurchaseDemand', JSON.stringify($scope.selected)).success(function () {
                       getPurchase_Demands();
                       $scope.selected = [];
                   });
               }
           });
    }

    function getDetails(DemandID) {
        $http.get('/Purchase_Demand/GetDetailsByDemandID?id=' + DemandID).success(function (results) {
            $scope.Purchase_DemandDetails = results;

            for (var i = 0; i < $scope.Purchase_DemandDetails.length; i++) {
                $scope.getMeasureUnits($scope.Purchase_DemandDetails[i].ProductID);
                $scope.Purchase_DemandDetails[i].MeasureUnits = $scope.MeasureUnits;
            }

            $scope.Total = 0;
            $.each($scope.Purchase_DemandDetails, function (i, item) {
                if (!isNaN(parseFloat(item.Quantity))) {
                    $scope.Total += parseFloat(item.Quantity);
                }
            });

        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.getTotalQuantity = function () {
        $scope.Total = 0;
        $.each($scope.Purchase_DemandDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Quantity))) {
                $scope.Total += parseFloat(item.Quantity);
            }
        });
    }

    $scope.getMeasureUnits = function (productID) {
        $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
            $scope.MeasureUnits = results;

            for (var i = 0; i < $scope.MeasureUnits.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
                }
                else {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEn;
                }
            }

            for (var i = 0; i < $scope.Purchase_DemandDetails.length; i++) {
                if ($scope.Purchase_DemandDetails[i].ProductID == productID)
                    $scope.Purchase_DemandDetails[i].MeasureUnits = $scope.MeasureUnits;
            }

        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.edit = function (Purchase_DemandID) {
        $http.get('/Purchase_Demand/GetDemandByID/' + Purchase_DemandID).success(function (data) {
            $scope.Purchase_Demand = data;
            getDetails(Purchase_DemandID);
            // $scope.showAdvancedEdit();

            //$scope.AddNew = true;
            HideMasterShowDetails('#DivShow', '#DivSave');

        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.removeFilterDetails = function () {
        $scope.filterDetail.show = false;
        $scope.query.filterDetails = '';

        if ($scope.filterDetail.form.$dirty) {
            $scope.filterDetail.form.$setPristine();
        }
    };

    $scope.removeFilterProduct = function () {
        $scope.filtered.show = false;
        $scope.query.filtered = '';

        if ($scope.filtered.form.$dirty) {
            $scope.filtered.form.$setPristine();
        }
    };

    $scope.LoadJobOrder = function (ev) {
        //  $("DivShow)
        //   $scope.Purchase_DemandDetails.push({});
        $scope.getJobOrders();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadJobOrder.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        })

    };

    $scope.LoadExceptionalWarranty = function (ev) {
        //  $("DivShow)
        //   $scope.Purchase_DemandDetails.push({});
        $scope.getExecptionalWarranty();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadExceptionalWarranty.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        })

    };

    $scope.LoadSupplyOrders = function (ev) {

        getSupplyOrders();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadSupplyOrder.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        })

    };

    $scope.LoadClaim = function (ev) {

        $scope.getClaims();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadClaim.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        })

    };


    $scope.LoadTransferOrder = function (ev) {

        $scope.getTransfers();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadTransferOrder.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        })

    };

    //load supply order

    function getSupplyOrders() {
        $http.get('/Sales_SupplyOrders/getAllSupplyOrdersPurchaseDemand').success(function (results) {
            $scope.SupplyOrders = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.getSupplyOrder = function (OrderID) {
        $scope.EditProduct = 'true';
        $http.get('/Sales_SupplyOrders/GetNotAvailableDetailsBySupplyOrderID?id=' + OrderID).success(function (results) {
            $scope.Purchase_DemandDetails = results;
            $scope.Purchase_Demand.SupplyOrderID = OrderID;
            $scope.cancelProduct();

        }).error(function () {
            swAlertErrorAr();
        });
    };
    //load job order
    $scope.getJobOrders = function () {
        $http.get('/JobOrder/JobOrder/GetALLJobOrder').success(function (results) {
            $scope.JobOrderDetails = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.loadDetailsFrom = function (JobOrderID) {
        $scope.Purchase_Demand.JobOrderID = JobOrderID;
        //$http.get('/WorkDone/getWorksDone/' + JobOrderID).success(function (results) {
        $http.get('/JobOrder/JobOrderToDoWork/GetNotAvailableDetailsByJobOrderID/' + JobOrderID).success(function (results) {
            $scope.JOWorkDone = results;
            addDetailsWorkDoneInInvoice();
            $scope.cancelProduct();

        }).error(function () {
            swAlertErrorAr();
        });
    }

    function addDetailsWorkDoneInInvoice() {
        for (i = 0; i < $scope.JOWorkDone.length; i++) {

            if ($scope.JOWorkDone[i].ProductID != null) {

                var item = {};
                item.ProductID = $scope.JOWorkDone[i].ProductID;
                item.ProductName = $scope.JOWorkDone[i].ProductName;
                item.ProductCode = $scope.JOWorkDone[i].ProductCode;
                item.Quantity = $scope.JOWorkDone[i].Quantity;

                var foundItem = $filter('filter')($scope.Purchase_DemandDetails, { ProductCode: $scope.JOWorkDone.ProductCode }, true)[0];

                if (foundItem == undefined) {
                    $scope.Purchase_DemandDetails.push(item);
                }

            }

            //if ($scope.JOWorkDone[i].PartID != null) {
            //    $scope.Purchase_DemandDetails.push({
            //        Quantity: $scope.JOWorkDone[i].Quantity,
            //        ProductID: $scope.JOWorkDone[i].PartID,
            //        ProductName: $scope.JOWorkDone[i].WorkDoneText,
            //    });
            //}

        };
    }
    //load claim

    $scope.getClaims = function () {
        $http.get('/Claim/GetALLClaims').success(function (results) {
            $scope.Claims = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    $scope.getClaimDetails = function (ClaimID) {
        $http.get('/Claim/GetDetailsByClaimID/' + ClaimID).success(function (results) {
            $scope.Purchase_DemandDetails = results;
            $scope.cancelProduct();

        }).error(function () {
            swAlertErrorAr();
        });
    };

    // load transfer demand 
    $scope.getTransferDetails = function (invoiceID) {
        $http.get('/Inventory/TransferDemand/GetDetailsByInvoiceID/' + invoiceID).success(function (results) {
            $scope.Purchase_DemandDetails = results;
            $scope.cancelProduct();

        }).error(function () {
            swAlertErrorAr();
        });
    };
    $scope.getTransfers = function () {
        $http.get('/Inventory/TransferDemand/GetALLTransferFromBranches').success(function (results) {

            $scope.Transfers = results;

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    ///load exceptional warranty
    $scope.getExecptionalWarranty = function () {
        $http.get('/ExceptionalWarranty/getExceptionalWarranties').success(function (results) {
            $scope.Warranties = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };
    $scope.getExceptionalWarrantyDetails = function (ExceptionalWarrantyID) {
        $http.get('/ExceptionalWarranty/getExceptionalWarrantyDetails/' + ExceptionalWarrantyID).success(function (results) {
            $scope.ExceptionalWarrantyDetails = results;
            addDetailsWarrantyInInvoice();
            $scope.cancelProduct();

        }).error(function () {
            swAlertErrorAr();
        });

    };

    function addDetailsWarrantyInInvoice() {
        for (i = 0; i < $scope.ExceptionalWarrantyDetails.length; i++) {
            if ($scope.ExceptionalWarrantyDetails[i].PartID != null) {
                $scope.Purchase_DemandDetails.push({
                    Quantity: $scope.ExceptionalWarrantyDetails[i].Quantity,
                    ProductID: $scope.ExceptionalWarrantyDetails[i].PartID,
                    ProductName: $scope.ExceptionalWarrantyDetails[i].PartName,
                    MeasureUnitName: $scope.ExceptionalWarrantyDetails[i].MeasureUnitName,
                    ProductCode: $scope.ExceptionalWarrantyDetails[i].ProductCode,
                    Title: $scope.ExceptionalWarrantyDetails[i].MeasureUnitName,
                    MeasureID: $scope.ExceptionalWarrantyDetails[i].MeasureID,
                });


            }
        };
    }

    //load demand items
    $scope.LoadDemandLimit = function () {
        $http.get('/Purchase_Demand/LoadDemandItems').success(function (results) {
            $scope.Purchase_DemandDetails = results;

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    $scope.query = {
        Invoice: 'name',
        filter: '',
        filterDetails: '',
        filterPayment: '',
        filterExpense: '',
        filterAttachment: '',

        limit: 5,
        page: 1
    };

    $scope.deleteDetails = function (model) {
        swConfirmDeleteAr(
            {
                function () {

                    if (model.DemandDetailID == undefined) {
                        $scope.Purchase_DemandDetails.splice($.inArray(model, $scope.Purchase_DemandDetails), 1);
                        $scope.$apply();
                        $scope.selectedDetails = [];
                    }

                }
            }
        );
    }

    $scope.checkReport = function (InvoiceID) {
        var reportParams = {
            "Parms": { "InvoiceID": InvoiceID },
            "ReportName": "PurchaseReport/PurchaseDemandReport.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }


});