﻿angular.module('globalApp')
.controller('ProductSalesWithCustomerReportController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter, $element) {
    
    $scope.model = {};

    $scope.Customers = [];

    $scope.CustomerSearchTerm = '';

    $scope.clearSearchTerm = function () {
        $scope.CustomerSearchTerm = '';
    };

    $element.find('input#searchCustomers').on('keydown', function (ev) {
        ev.stopPropagation();
    });


    $scope.loadCustomers = function () {
        if ($scope.Customers.length <= 0) {
            $http.get('/Administration/Customer/GetCustomers').success(function (results) {
                $scope.Customers = results;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.checkReport = function (model) {

        if (model.Customer != undefined) {

            model.CustomerName = model.Customer.NameAr;
            model.CustID = model.Customer.CustID;

        }
        else {
            model.CustomerName = '';
            model.CustID = 0;
        }

        var 
            reportParams = {
                "Parms": { "DateFrom": $filter('date')(model.DateFrom, "yyyy-MM-dd"), "DateTo": $filter('date')(model.DateTo, "yyyy-MM-dd")
                    ,"CustomerName": model.CustomerName, "CustomerID": model.CustID},
                "ReportName": "SalesReport/ProductSalesWithCustomerReport.trdx"
        };

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }

    $scope.clearFields = function () {
        $scope.model = {};        
    }

});