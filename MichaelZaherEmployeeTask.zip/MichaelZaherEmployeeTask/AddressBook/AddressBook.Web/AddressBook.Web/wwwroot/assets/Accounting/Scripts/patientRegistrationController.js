﻿angular.module('globalApp')
.controller('patientRegistrationController', function ($scope, sharedProperties, locale, $http) {
    locale.ready('common').then(function () {
        sharedProperties.setPageTitle(locale.getString('common.patientRegistration'));
    });
    
});