﻿
angular.module('globalApp')
.controller('TelephoneTypeController', function ($scope, $mdDialog, $http, $locale, $rootScope) {

    $scope.TelephoneTypes = [];
    $scope.TelephoneType = {};
    $scope.selected = [];

    getTelephoneTypes();

    function getTelephoneTypes() {
        $http.get('/TelephoneType/getTelephoneTypes').success(function (results) {
            $scope.TelephoneTypes = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/TelephoneType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        })
    };



    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/TelephoneType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.TelephoneType = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.TelephoneType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };

    $scope.save = function () {
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.TelephoneType),
            url: '/TelephoneType/saveTelephoneType',
            success: function () {
                getTelephoneTypes();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

   
    $scope.edit = function (TelephoneTypeID) {
        $http.get('/TelephoneType/getTelephoneTypeByID/' + TelephoneTypeID).success(function (data) {
            $scope.TelephoneType = data;
            $scope.showAdvancedEdit();
        });
    };

     $scope.delete = function () {
        swConfirmDeleteEn(function () {
            $http.post('/TelephoneType/deleteTelephoneType', JSON.stringify($scope.selected)).success(function () {
                getTelephoneTypes();
                $scope.selected = [];
            });
        });
    }

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

});