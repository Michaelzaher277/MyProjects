﻿
angular.module('globalApp')
.controller('UserController', function ($scope, $mdDialog, $http, $cookies) {

    $scope.Users = [];
    $scope.User = {};
    $scope.Roles = [];

    $scope.selected = [];


    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };

    getUsers();
    getRoles();


    function getRoles() {
        $http.get('/Administration/Security/GetRoles').success(function (results) {
            $scope.Roles = results;
            for (var i = 0; i < $scope.Roles.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Roles[i].Title = $scope.Roles[i].NameAr;
                }
                else {
                    $scope.Roles[i].Title = $scope.Roles[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
        $scope.selected = {};
    };




    function getUsers() {
        $http.get('/Administration/Security/GetUsers').success(function (results) {
            $scope.Users = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/User.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };

    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/UserEdit.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.changingPass = function (item) {
        $scope.User = item;
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/ChangePassword.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true   
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.User = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.User = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.User),
            url: '/Administration/Security/saveUser',
            success: function () {
                getUsers();
                $scope.cancel();
                swAlertSaveAr();
            },
            error: function () {
                swAlertErrorAr();
            }
        });
    };
    $scope.delete = function () {
        swConfirmDeleteAr(function () {
            $http.post('/Administration/Security/deleteUser', JSON.stringify($scope.selected)).success(function () {
                getUsers();
                $scope.selected = [];
            });
        });
    }
    $scope.edit = function (UserID) {
        $http.get('/Administration/Security/getUserByID/' + UserID).success(function (data) {
            $scope.User = data;
            $scope.showAdvancedEdit();
        });
    };

    $scope.changePassword = function () {
        var obj = { id: $scope.User.UserID, pass: $scope.User.Password }
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(obj),
            url: '/Administration/Security/savePassword/',
            success: function () {
                getUsers();
                $scope.cancel();
                swAlertSaveAr();
            },
            error: function () {
                swAlertErrorAr();
            }
        });
    };
    
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});