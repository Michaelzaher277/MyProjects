﻿
angular.module('globalApp')
.controller('GenderController', function ($scope, $mdToast, $mdDialog, $http, $rootScope) {

    $scope.Genders = [];
    $scope.Gender = {};

    $scope.selected = [];


    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };

    getGenders();

    

    function getGenders() {
        $http.get('/Administration/Gender/getGenders').success(function (results) {
            $scope.Genders = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/Gender.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/Gender.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Gender = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Gender = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Gender),
            url: '/Administration/Gender/saveGender',
            success: function () {
                getGenders();
                $scope.cancel();
                //swAlertSave();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
   
    

    $scope.edit = function (GenderID) {
        $http.get('/Administration/Gender/getGenderByID/' + GenderID).success(function (data) {
            $scope.Gender = data;
            $scope.showAdvancedEdit();
        });
    };

    //New md Table

   

    $scope.delete = function () {
        $rootScope.$emit("swConfirmDelete", 
            {
                function () {
                    $http.post('/Gender/deleteGender', JSON.stringify($scope.selected)).success(function () {
                        getGenders();
                        $scope.selected = [];
                    });

                }
            });
        //swConfirmDeleteEn(function () {
        //    $http.post('/Gender/deleteGender', JSON.stringify($scope.selected)).success(function () {
        //        getGenders();
        //        $scope.selected = [];
        //    });
        //});
    }
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});