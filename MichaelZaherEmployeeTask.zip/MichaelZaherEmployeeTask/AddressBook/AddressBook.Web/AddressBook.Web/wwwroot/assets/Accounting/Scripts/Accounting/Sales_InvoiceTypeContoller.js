﻿
angular.module('globalApp')
.controller('Sales_InvoiceTypeController', function ($scope, $mdToast, $mdDialog, $http, $rootScope) {

    $scope.Sales_InvoiceTypes = [];
    $scope.Sales_InvoiceType = {};
    

    $scope.selected = [];


    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };

  getSales_InvoiceTypes();



  function getSales_InvoiceTypes() {
      $http.get('/Sales_InvoiceType/getSales_InvoiceTypes').success(function (results) {
          $scope.Sales_InvoiceTypes = results;
      }).error(function () {
          swAlertErrorAr();
      });
  };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Sales_InvoiceType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Sales_InvoiceType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Sales_InvoiceType = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Sales_InvoiceType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Sales_InvoiceType),
            url: '/Accounting/Sales_InvoiceType/saveSales_InvoiceType',
            success: function () {
                getSales_InvoiceTypes();
                $scope.cancel();
                //swAlertSave();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };



    $scope.edit = function (Sales_InvoiceTypeID) {
        $http.get('/Accounting/Sales_InvoiceType/getSales_InvoiceTypeByID/' + Sales_InvoiceTypeID).success(function (data) {
            $scope.Sales_InvoiceType = data;
            $scope.showAdvancedEdit();
        });
    };

  
    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Accounting/Sales_InvoiceType/deleteSales_InvoiceType', JSON.stringify($scope.selected)).success(function () {
                       getSales_InvoiceTypes();
                       $scope.selected = [];
                   });
               }
           });
    }



    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
});