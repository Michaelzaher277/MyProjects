﻿
angular.module('globalApp')
.controller('TransactionTypeController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.TransactionTypes = [];
    $scope.TransactionType = {};

    $scope.selected = [];

    getTransactionTypes();

    //function success(desserts) {
    //    $scope.desserts = ['christian', 'Non-christian'];
    //}

    //$scope.getDesserts = function () {
    //  $scope.promise = $nutrition.desserts.get($scope.query, success).$promise;
    //};

    function getTransactionTypes() {
        $http.get('/TransactionType/getTransactionTypes').success(function (results) {
            $scope.TransactionTypes = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/TransactionType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom : '.addButton',
            closeTo: '.addButton'
        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/TransactionType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.TransactionType = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.TransactionType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.TransactionType),
            url: '/TransactionType/saveTransactionType',
            success: function () {
                getTransactionTypes();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {
        
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/TransactionType/deleteTransactionType', JSON.stringify($scope.selected)).success(function () {
                       getTransactionTypes();
                       $scope.selected = [];
                   });
               }
           });
    }
    $scope.edit = function (TransactionTypeID) {
        $http.get('/TransactionType/getTransactionTypeByID/' + TransactionTypeID).success(function (data) {
            $scope.TransactionType = data;
            $scope.showAdvancedEdit();
        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});