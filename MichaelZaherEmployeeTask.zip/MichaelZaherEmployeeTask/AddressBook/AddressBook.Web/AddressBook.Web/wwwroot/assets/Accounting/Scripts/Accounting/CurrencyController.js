﻿
angular.module('globalApp')
.controller('CurrencyController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.Currencies = [];
    $scope.Currency = {};

    $scope.selected = [];

    getCurrencies();


    function getCurrencies() {
        $http.get('/Currency/getCurrencies').success(function (results) {
            $scope.Currencies = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Currency.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom : '.addButton',
            closeTo: '.addButton'
        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Currency.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Currency = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Currency = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Currency),
            url: '/Currency/saveCurrency',
            success: function () {
                getCurrencies();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {
        
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Currency/deleteCurrency', JSON.stringify($scope.selected)).success(function () {
                       getCurrencies();
                       $scope.selected = [];
                   });
               }
           });
    }
    $scope.edit = function (CurrencyID) {
        $http.get('/Currency/getCurrencyByID/' + CurrencyID).success(function (data) {
            $scope.Currency = data;
            $scope.showAdvancedEdit();
        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});