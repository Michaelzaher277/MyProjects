﻿angular.module('globalApp')
    .controller('DailyTransactionController', function ($scope, $mdDialog, $http, $rootScope, $cookies) {
        var ChartOfAccountTree, ChartOfAccountList, CostCenterTree, CostCenterList;
        // Daily Transaction Variables
        $scope.DailyTransactions = [];
        $scope.DailyTransaction = {};
        $scope.DailyTransactionDetails = [];
        $scope.DailyTransactionDetail = {};
        $scope.DailyTransactionDetailCostCenters = [];
        $scope.DailyTransactionDetailCostCenter = {};
        $scope.TotalDepit = 0;
        $scope.TotalCredit = 0;
        $scope.DailyTransactionSearch = "";

        // MD Table selection variables

        $scope.selected = [];
        $scope.DetailSelected = [];
        $scope.DetailLimitOptions = [5, 10, 15];
        $scope.DetailOptions = {
            pageSelect: true
        };

        $scope.DetailQuery = {
            order: 'name',
            filter: '',
            limit: 5,
            page: 1,
        };

        $scope.DetailCostCenterSelected = [];
        $scope.DetailCostCenterLimitOptions = [5, 10, 15];
        $scope.DetailCostCenterOptions = {
            pageSelect: true
        };
        $scope.DetailCostCenterQuery = {
            order: 'name',
            filter: '',
            limit: 5,
            page: 1,
        };

        // ddl variables
        $scope.Currencies = [];
        $scope.ChartOfAccounts = [];
        $scope.TransactionTypes = [];       
        $scope.ChartOfAccountsFilter = "";
        $scope.CostCenters = [];       
        $scope.CostCentersFilter = "";

        // run at startup
        loadCurrencies();


        $scope.getCurrency = function (CurrencyID) {
            $http.get('/Currency/getCurrencyByID?id=' + CurrencyID).success(function (data) {
                $scope.DailyTransaction.Currency_Convert = data.ConvertValue;
            });
        };

        // Chart Of Account Dialog Functions
      
        $scope.deleteDailyTransaction = function (DailyTransactionID) {
            $rootScope.$emit("swConfirmDelete",
                {
                    function() {
                        if (DailyTransactionID > 0) {
                            $http.get('/Accounting/DailyTransaction/deleteDailyTransactionByID/' + DailyTransactionID).success(function () {
                                $scope.SearchDailyTransactions($scope.DailyTransactionSearch);
                                $scope.back();
                            }).error(function () {
                                $rootScope.$emit("swAlertError", {});
                            });
                        }
                    }
                });
        }

        $scope.AddNewDailyTransactionDetail = function () {
            $scope.getChartOfAccountTree();
            //if ($scope.ChartOfAccounts.length <= 0) {
            //    getChartOfAccountTree();
            //}
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
                onRemoving: function () {
                    $scope.cancelChartOfAccountsDialog();
                },
                clickOutsideToClose: true,
                openFrom: '.addButton',
                closeTo: '.addButton'
            });
        }
        $scope.selectNode = function (node) {
            $scope.ChartOfAccount = node.$modelValue;
        }       

        $scope.chooseChartOfAccount = function () {
            if ($scope.DailyTransactionDetail.DailyTransactionDetailID == undefined) {
                $scope.DailyTransactionDetails.push({
                    ChartOfAccountName: ($cookies.get('ERP_lang') == 'ar-EG') ? $scope.ChartOfAccount.AccountArabicName : $scope.ChartOfAccount.AccountEnglishName  ,
                    CurrencyID: $scope.ChartOfAccount.DefaultCurrencyID,
                    ChartOfAccountID: $scope.ChartOfAccount.ChartOfAccountID,
                    ChartOfAccountCode: $scope.ChartOfAccount.AccountCode,
                    DailyTransactionDetailID: 0
                });
            }
            else {
                $scope.DailyTransactionDetail.ChartOfAccountName = ($cookies.get('ERP_lang') == 'ar-EG')? $scope.ChartOfAccount.AccountArabicName : $scope.ChartOfAccount.AccountEnglishName;
                $scope.DailyTransactionDetail.ChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
                $scope.DailyTransactionDetail.ChartOfAccountCode = $scope.ChartOfAccount.AccountCode;
            }
            $scope.DailyTransactionDetail = {};
            $scope.cancelChartOfAccountsDialog();
        };

        $scope.FilterChartOfAccounts = function (item) {
            return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
        };
        $scope.cancelChartOfAccountsDialog = function () {
            $mdDialog.cancel();            
            $scope.ChartOfAccountsFilter = "";
        };

        // Cost Centers Dialog Functions
      
        $scope.AddNewDailyTransactionDetailCostCenter = function () {
            $scope.getCostCentersTree();
            //if ($scope.CostCenters.length <= 0) {
            //    getCostCentersTree();
            //}
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/DailyTransactionCostCenters.tmpl.html',
                onRemoving: function () {
                    $scope.cancelChartOfAccountsDialog();
                },
                clickOutsideToClose: true,
                openFrom: '.addButtonCostCenter',
                closeTo: '.addButtonCostCenter'
            });
        }
        $scope.selectNodeCostCenter = function (node) {
            $scope.CostCenter = node.$modelValue;
        }
        $scope.findNodesCostCenter = function (item) {
            $scope.CostCentersFilter = item.CostCentersFilter;
        };
        $scope.chooseCostCenter = function () {
            if ($scope.DetailSelected[0].DailyTransactionDetailsCostCenters == undefined) {
                $scope.DetailSelected[0].DailyTransactionDetailsCostCenters = [];
            }
            if ($scope.DailyTransactionDetailCostCenter.DailyTransactionDetailsCostCenterID == undefined) {
                $scope.DetailSelected[0].DailyTransactionDetailsCostCenters.push({
                    CostCenterName: ($cookies.get('ERP_lang') == 'ar-EG') ? $scope.CostCenter.CostCenterArabicName : $scope.ChartOfAccount.CostCenterEnglishName ,
                    CostCenterID: $scope.CostCenter.CostCenterID,
                    CostCenterCode: $scope.CostCenter.CostCenterCode,
                    DailyTransactionDetailsCostCenterID: 0
                });
            }
            else {
                $scope.DailyTransactionDetailCostCenter.CostCenterName = ($cookies.get('ERP_lang') == 'ar-EG') ? $scope.CostCenter.CostCenterArabicName : $scope.ChartOfAccount.CostCenterEnglishName;
                $scope.DailyTransactionDetailCostCenter.CostCenterID = $scope.CostCenter.CostCenterID;
                $scope.DailyTransactionDetailCostCenter.CostCenterCode = $scope.CostCenter.CostCenterCode;
            }
            $scope.DailyTransactionDetailCostCenter = {};
            $scope.cancelCostCentersDialog();
        };
        $scope.FilterCostCenters = function (item) {
            return (item.Name.indexOf($scope.CostCentersFilter) != -1 || item.AccountCode.indexOf($scope.CostCentersFilter) != -1);
        };
        $scope.cancelCostCentersDialog = function () {
            $mdDialog.cancel();           
            $scope.CostCentersFilter = "";
        };

        // Daily Transaction Functions
        $scope.SearchDailyTransactions = function (searchTerm) {
            $http.get("/Accounting/DailyTransaction/SearchDailyTransaction/" + searchTerm)
                .success(function (result) {
                    $scope.DailyTransactions = result;
                    for (var i = 0; i < $scope.DailyTransactions.length; i++) {

                        if ($scope.DailyTransactions[i].DepitTotal === undefined || $scope.DailyTransactions[i].DepitTotal === null) {
                            $scope.DailyTransactions[i].DepitTotal = 0; 
                        }

                        if ($scope.DailyTransactions[i].DepitCurrencyConvert === undefined || $scope.DailyTransactions[i].DepitCurrencyConvert === null) {
                            $scope.DailyTransactions[i].DepitCurrencyConvert = 1;
                        }

                        if ($scope.DailyTransactions[i].CreditTotal === undefined || $scope.DailyTransactions[i].CreditTotal === null) {
                            $scope.DailyTransactions[i].CreditTotal = 0;
                        }

                        if ($scope.DailyTransactions[i].CreditCurrencyConvert === undefined || $scope.DailyTransactions[i].CreditCurrencyConvert === null) {
                            $scope.DailyTransactions[i].CreditCurrencyConvert = 1;
                        }

                        $scope.DailyTransactions[i].DepitTotal = $scope.DailyTransactions[i].DepitTotal * $scope.DailyTransactions[i].DepitCurrencyConvert;
                        $scope.DailyTransactions[i].CreditTotal = $scope.DailyTransactions[i].CreditTotal * $scope.DailyTransactions[i].CreditCurrencyConvert;

                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.DailyTransactions[i].TransactionTypeName = $scope.DailyTransactions[i].TransactionTypeNameAR;
                        }
                        else {
                            $scope.DailyTransactions[i].TransactionTypeName = $scope.DailyTransactions[i].TransactionTypeNameEN;
                        }
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                })
        };

        function getLastCode() {
            $http.get('/Accounting/DailyTransaction/GetLastCode').success(function (results) {
                $scope.DailyTransaction.Code = results;
                $scope.DailyTransaction.TransactionDate = new Date();;
            }).error(function (data, status, headers, config) {
                swAlertErrorAr();
            });
        };

        $scope.showAdvancedAdd = function (ev) {
            HideMasterShowDetails('#divTransactionSearch', '#divTransactionData');
            getLastCode();
        };

        $scope.edit = function (item) {
            $scope.loadTransactionTypes();
            $scope.DailyTransaction = item;
            HideMasterShowDetails('#divTransactionSearch', '#divTransactionData');
            getTransactionDetails(item.DailyTransactionID);
        }

        function getDailyTransaction(id) {
            $http.get("/Accounting/DailyTransaction/getDailyTransaction/" + id)
                .success(function (results) {
                    $scope.DailyTransaction = results;
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
        }

        function getTransactionDetails(id) {
            $http.get("/Accounting/DailyTransaction/getTransactionDetails/" + id)
                .success(function (results) {
                    $scope.DailyTransactionDetails = results;
                    for (var i = 0; i < $scope.DailyTransactionDetails.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.DailyTransactionDetails[i].ChartOfAccountName = $scope.DailyTransactionDetails[i].ChartOfAccountNameAR;
                        }
                        else {
                            $scope.DailyTransactionDetails[i].ChartOfAccountName = $scope.DailyTransactionDetails[i].ChartOfAccountNameEN;
                        }
                        if ($scope.DailyTransactionDetails[i].DailyTransactionDetailsCostCenters.length > 0) {
                            for (var j = 0; j < $scope.DailyTransactionDetails[i].DailyTransactionDetailsCostCenters.length; j++) {
                                if ($cookies.get('ERP_lang') == 'ar-EG') {
                                    $scope.DailyTransactionDetails[i].DailyTransactionDetailsCostCenters[j].CostCenterName = $scope.DailyTransactionDetails[i].DailyTransactionDetailsCostCenters[j].CostCenterNameAR;
                                }
                                else {
                                    $scope.DailyTransactionDetails[i].DailyTransactionDetailsCostCenters[j].CostCenterName = $scope.DailyTransactionDetails[i].DailyTransactionDetailsCostCenters[j].CostCenterNameEN;
                                }
                            }
                        }
                    }
                    $scope.calculateTotalDepitCredit();
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
        }

        $scope.back = function () {
            HideMasterShowDetails('#divTransactionData', '#divTransactionSearch');
            $scope.DailyTransactionDetailCostCenters = [];
            $scope.DailyTransactionDetailCostCenter = {};
            $scope.DetailCostCenterSelected = [];
            $scope.DailyTransactionDetails = [];
            $scope.DailyTransactionDetail = {};
            $scope.DailyTransaction = {};
            $scope.DetailSelected = [];
            $scope.TotalCredit = 0;
            $scope.TotalDepit = 0;
            $scope.selected = [];
        }

        $scope.save = function () {

            //var addToArray = true;
            //for (var i = 1; i < $scope.DailyTransactionDetails.length; i++) {
            //    if ($scope.DailyTransactionDetails[i].CurrencyID != $scope.DailyTransactionDetails[i - 1].CurrencyID || $scope.DailyTransactionDetails[i].Currency_Convert != $scope.DailyTransactionDetails[i - 1].Currency_Convert) {
            //        addToArray = false;
            //    }
            //}

            //if (addToArray == true) {
            $scope.DailyTransaction.DailyTransactionDetails = $scope.DailyTransactionDetails;

            if ($scope.DailyTransaction.DailyTransactionDetails.length > 0) {
                for (var i = 0; i < $scope.DailyTransaction.DailyTransactionDetails.length; i++) {
                    $scope.DailyTransaction.DailyTransactionDetails[i].CurrencyID = $scope.DailyTransaction.CurrencyID;
                    $scope.DailyTransaction.DailyTransactionDetails[i].Currency_Convert = $scope.DailyTransaction.Currency_Convert;
                }
            }

            $http.post("/Accounting/DailyTransaction/saveTransaction", $scope.DailyTransaction).success(function () {
                $rootScope.$emit("swAlertSave", {});
                $scope.back();
                $scope.SearchDailyTransactions($scope.DailyTransactionSearch);
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            })
            //}
            //else {
            //    $rootScope.$emit("AlertNotEqualUnitPrice", {});
            //}
        };

        $scope.CancelTransfer = function () {
            $scope.DailyTransaction.DailyTransactionDetails = $scope.DailyTransactionDetails;
            $http.post("/Accounting/DailyTransaction/CancelTransfer", $scope.DailyTransaction).success(function () {
                $rootScope.$emit("swAlertSave", {});
                $scope.back();
                $scope.SearchDailyTransactions($scope.DailyTransactionSearch);
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            })
        };

        $scope.deleteDailyTransactionDetail = function () {

        }
        $scope.editDailyTransCode = function (item) {
            $scope.DailyTransactionDetail = item;
            if ($scope.ChartOfAccounts.length <= 0) {
                $scope.getChartOfAccountTree();
            }
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
                onRemoving: function () {
                    $scope.cancelChartOfAccountsDialog();
                },
                clickOutsideToClose: true,
                openFrom: '#btnEditCode',
                closeTo: '#btnEditCode'
            });
        }
        $scope.editDailyTransName = function (item) {
            $scope.DailyTransactionDetail = item;
            if ($scope.ChartOfAccounts.length <= 0) {
                $scope.getChartOfAccountTree();
            }
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
                onRemoving: function () {
                    $scope.cancelChartOfAccountsDialog();
                },
                clickOutsideToClose: true,
                openFrom: '#btnEditName',
                closeTo: '#btnEditName'
            });
        }
        $scope.calculateTotalDepitCredit = function () {
            var TotalDepit = 0;
            var TotalCredit = 0;
            $.each($scope.DailyTransactionDetails, function (i, item) {
                if (item.DepitAmount != undefined) {
                    TotalDepit += parseInt(item.DepitAmount);
                }
                if (item.CreditAmount != undefined) {
                    TotalCredit += parseInt(item.CreditAmount);
                }
                $scope.TotalDepit = TotalDepit.toString();
                $scope.TotalCredit = TotalCredit.toString();
            });
        }

        // Daily Transaction Cost Centers Functions
        $scope.deleteDailyTransactionCostCenterDetail = function () {

        }
        $scope.editDailyTransCostCenterCode = function (item) {
            $scope.DailyTransactionDetailCostCenter = item;
            if ($scope.CostCenters.length <= 0) {
                $scope.getCostCentersTree();
            }
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/DailyTransactionCostCenters.tmpl.tmpl.html',
                onRemoving: function () {
                    $scope.cancelCostCentersDialog();
                },
                clickOutsideToClose: true,
                openFrom: '#btnEditCostCenterCode',
                closeTo: '#btnEditCostCenterCode'
            });
        }

        $scope.editDailyTransCostCenterName = function (item) {

            $scope.DailyTransactionDetailCostCenter = item;

            if ($scope.CostCenters.length <= 0) {
                $scope.getCostCentersTree();
            }

            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/DailyTransactionCostCenters.tmpl.html',
                onRemoving: function () {
                    $scope.cancelCostCentersDialog();
                },
                clickOutsideToClose: true,
                openFrom: '#btnEditCostCenterName',
                closeTo: '#btnEditCostCenterName'
            });

        }

        // ddl Functions
        function loadCurrencies() {
            if ($scope.Currencies.length <= 0) {
                $http.get('/Accounting/Currency/GetCurrencies').success(function (results) {
                    $scope.Currencies = results;
                    for (var i = 0; i < $scope.Currencies.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                        }
                        else {
                            $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                        }
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        }
        $scope.loadTransactionTypes = function () {
            if ($scope.TransactionTypes.length <= 0) {
                $http.get('/Accounting/TransactionType/getTransactionTypes').success(function (results) {
                    $scope.TransactionTypes = results;
                    for (var i = 0; i < $scope.TransactionTypes.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.TransactionTypes[i].Title = $scope.TransactionTypes[i].NameAr;
                        }
                        else {
                            $scope.TransactionTypes[i].Title = $scope.TransactionTypes[i].NameEn;
                        }
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        }


        ////////////////////////////DAily Transaction Transfer/////////////////////


        $scope.SearchNotTransferDailyTransactions = function (searchTerm) {
            $http.get("/Accounting/DailyTransaction/SearchNotTransferDailyTransactions/" + searchTerm)
                .success(function (result) {
                    $scope.DailyTransactions = result;
                    for (var i = 0; i < $scope.DailyTransactions.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.DailyTransactions[i].TransactionTypeName = $scope.DailyTransactions[i].TransactionTypeNameAR;
                        }
                        else {
                            $scope.DailyTransactions[i].TransactionTypeName = $scope.DailyTransactions[i].TransactionTypeNameEN;
                        }
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                })
        }
        $scope.TransferDailyTransaction = function () {

            $rootScope.$emit("swConfirmTransferTransaction",
                {
                    function() {
                        $http.post('/DailyTransaction/TransferDailyTransaction', JSON.stringify($scope.selected)).success(function () {

                            $scope.SearchNotTransferDailyTransactions($scope.DailyTransactionSearch);
                            $scope.selected = [];
                        });
                    }
                });
        }

        if (getParameterByName('id') !== null) {
            $scope.loadTransactionTypes();
            getDailyTransaction(getParameterByName('id'));
            getTransactionDetails(getParameterByName('id'));
            HideMasterShowDetails('#divTransactionSearch', '#divTransactionData');
        }

    });