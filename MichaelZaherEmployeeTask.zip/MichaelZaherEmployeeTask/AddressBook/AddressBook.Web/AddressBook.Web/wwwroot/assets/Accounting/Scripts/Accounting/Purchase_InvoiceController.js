﻿
angular.module('globalApp')
.controller('Purchase_InvoiceController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter) {

    $scope.Purchase_Invoices = [];
    $scope.Purchase_Invoice = {};
    $scope.Purchase_InvoiceDetail = {};
    $scope.Purchase_InvoiceDetails = [];
    $scope.Purchase_InvoicePayments = [];
    $scope.Purchase_InvoicePayment = {};
    $scope.Purchase_InvoiceExpenses = [];
    $scope.Attachments = [];
    $scope.Purchase_Orders = [];
    $scope.Income_Orders = [];
    $scope.Income_Order = {};
    $scope.InvoiceAttachmentSelected = [];
    $scope.Currencies = [];
    //$scope.SelectedCurrency = {};
    $scope.Suppliers = [];

    $scope.InvoiceTypes = [];
    $scope.selected = [];
    $scope.selectedProduct = [];
    $scope.selectedPurchaseOrder = [];
    $scope.selectedDetails = [];
    //  $scope.AddNew = false;
    //    $scope.Products = [];
    $scope.Product = {};
    $scope.PaymentTypes = [];
    $scope.ExpenseTypes = [];
    $scope.selectedIncomeOrder = [];
    $scope.InvoicePaymentSelected = [];
    $scope.InvoiceExpenseSelected = [];
    $scope.Sum = {};

    $scope.Sum.TotalQuantity = 0;
    $scope.Sum.Amount = 0;
    $scope.Sum.Discount = 0;
    $scope.Sum.TotalPrice = 0;
    $scope.Sum.Taxes = 0;
    $scope.Sum.TaxesDiscount = 0;
    $scope.Sum.TotalCost = 0;
    $scope.Sum.TotalInvoice = 0;
    $scope.Sum.NetTotalPrice = 0;
    $scope.PaymentTotalPrice = 0;
    $scope.ExpenseTotalPrice = 0;



    $scope.Setting = {};

    getPurchase_Invoices();

    getInvoicePayments();
    HideMasterShowDetails("#DivSave", "#DivShow");


    ////drop down /////

    $scope.getCurrencies = function (viewValue) {
        $http.get('/Currency/GetCurrencies').success(function (results) {
            $scope.Currencies = results;

            for (var i = 0; i < $scope.Currencies.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                }
                else {
                    $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });

    };

    $scope.getSuppliers = function (viewValue) {
        $http.get('/Administration/Supplier/GetSuppliers').success(function (results) {
            $scope.Suppliers = results;

            for (var i = 0; i < $scope.Suppliers.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Suppliers[i].Title = $scope.Suppliers[i].NameAr;
                }
                else {
                    $scope.Suppliers[i].Title = $scope.Suppliers[i].NameEng;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.getCurrencies();
    $scope.getSuppliers();

    $scope.getCurrency = function (CurrencyID) {
        $http.get('/Currency/getCurrencyByID?id=' + CurrencyID).success(function (data) {
            $scope.Purchase_Invoice.Currency_Convert = data.ConvertValue;
        });
    };

    $scope.getSetting = function () {
        $http.get('/AccountingSettings/getAccountingSettings').success(function (results) {
            $scope.Setting = results;
        })
    };

    $scope.getSetting();

    ///////////////////////////////

    $scope.files = [];
    $scope.onSubmit = function (name) {
        var formData = new FormData();

        angular.forEach($scope.files, function (value, key) {
            formData.append(value.lfFileName, value.lfFile);
        });
        //angular.forEach($scope.files, function (obj) {
        //    formData.append('files[]', obj.lfFile);
        //});
        $http.post('/Common/UploadFiles?Folder=Purchase_Invoice', formData, {
            transformRequest: angular.identity,
            headers: { 'Content-Type': undefined }
        }).then(function (result) {
            // do sometingh 
            $scope.addDetailAttachment(name, result.data);
            $scope.lfApi.removeAll();

        }, function (err) {
            // do sometingh
        });
    };
    $scope.onFileClick = function (obj, idx) {
        alert(obj.lfFileName);
    };

    $scope.GetLastCodeInvoices= function (id) {
        if (id == 1) {
            $http.get('/Purchase_Invoice/GetLastCodeInvoicesCash').success(function (results) {
                $scope.Purchase_Invoice.InvoiceCode = results;
                //var today = $filter('date')(new Date(), 'yyyy-MM-dd');
                $scope.Purchase_Invoice.InvoiceDate = new Date();;
            }).error(function (data, status, headers, config) {
                swAlertErrorAr();
            });
        }
        else {

            $http.get('/Purchase_Invoice/GetLastCodeInvoicesNotCash').success(function (results) {
                $scope.Purchase_Invoice.InvoiceCode = results;
                //var today = $filter('date')(new Date(), 'yyyy-MM-dd');
                $scope.Purchase_Invoice.InvoiceDate = new Date();;
            }).error(function (data, status, headers, config) {
                swAlertErrorAr();
            });
        }
    };

    function getPurchase_Invoices() {
        $http.get('/Purchase_Invoice/GetALLInvoices').success(function (results) {
            $scope.Purchase_Invoices = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };


    $scope.showAdvancedAdd = function (ev) {
        //  $("DivShow)
        HideMasterShowDetails("#DivShow", "#DivSave");
        $scope.getInvoiceTypes();
       // getLastCodeInvoices();
        // $scope.getShipping_Ways();
        //$scope.getAllProductsModal();

    };

    $scope.getMeasureUnit = function (productID) {
        $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
            $scope.MeasureUnits = results;
            for (var i = 0; i < $scope.MeasureUnits.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
                }
                else {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEng;
                }
            }


            for (var i = 0; i < $scope.Purchase_InvoiceDetails.length; i++) {
                if ($scope.Purchase_InvoiceDetails[i].PartID == productID)
                    $scope.Purchase_InvoiceDetails[i].MeasureUnits = $scope.MeasureUnits;
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.getProductModal = function (modal) {

        for (i = 0; i < modal.length; i++) {
            if (modal[i].ProductID != null) {
                var item = {};
                item.PartID = modal[i].ProductID;
                item.ProductName = modal[i].NameAr;
                item.ProductCode = modal[i].Code;
                item.MeasureUnits = modal[i].MeasureUnits;

                //$scope.getSetting();
                for (var j = 0; j < item.MeasureUnits.length; j++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                    }
                    else {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                    }
                }

                if ($scope.Setting != undefined) {
                    item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                    item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                }
                else {
                    $scope.getSetting();
                    if ($scope.Setting != undefined) {
                        item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                        item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                    }
                }

                var foundItem = $filter('filter')($scope.Purchase_InvoiceDetails, { ProductCode: modal[i].Code }, true)[0];

                if (foundItem == undefined) {
                    $scope.Purchase_InvoiceDetails.push(item);
                }
                ///  $scope.Purchase_InvoiceDetails.push(item);
            }
        }
        //$scope.cancelProduct();

        // $('#DivParts').modal('toggle');
    };

    $scope.getAllProductsModal = function () {
        $http.get('/Inventory/ProductDetails/GetProducts').success(function (results) {
            $scope.Products = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    $scope.showProductsAdd = function (ev) {
        //  $("DivShow)
        //   $scope.Purchase_InvoiceDetails.push({});
        //  $scope.getAllProductsModal();
        $scope.GetTopProducts("");

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadProducts.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addProduct',
            closeTo: '.addProduct'
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Purchase_Invoice = {};
    };


    $scope.cancelDialog = function () {

        $mdDialog.cancel();
    };

    $scope.cancelProduct = function () {
        //$scope.AddNew = true;

        $mdDialog.cancel();
        $scope.selectedProduct = [];
        $scope.selectedPurchaseDemand = [];
        $scope.Purchase_InvoicePayment = {};
    };

    $scope.cancelExpense = function () {
        //$scope.AddNew = true;

        $mdDialog.cancel();
        $scope.Purchase_InvoiceExpense = {};
        $scope.InvoiceExpenseSelected = [];
    };
    $scope.cancelPayment = function () {
        //$scope.AddNew = true;

        $mdDialog.cancel();
        $scope.Purchase_InvoicePayment = {};
        $scope.InvoicePaymentSelected = [];
    };
    $scope.cancelPurchase_Invoice = function () {
        //   $mdDialog.cancel();
        HideMasterShowDetails("#DivSave", "#DivShow");
        $scope.Purchase_Invoice = {};
        $scope.Purchase_InvoiceDetails = [];

    };


    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {
        $scope.Purchase_Invoice.Purchase_InvoiceDetail = $scope.Purchase_InvoiceDetails;
        $scope.Purchase_Invoice.Purchase_InvoiceExpense = $scope.Purchase_InvoiceExpenses;
        $scope.Purchase_Invoice.Purchase_InvoiceAttachment = $scope.Attachments;

        //if ($scope.Purchase_Invoice.SelectedCurrency != undefined) {
        //    $scope.Purchase_Invoice.CurrencyID = $scope.Purchase_Invoice.SelectedCurrency.CurrencyID;
        //    $scope.Purchase_Invoice.Currency_Convert = $scope.Purchase_Invoice.SelectedCurrency.ConvertValue;
        //}

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Purchase_Invoice),
            url: '/Purchase_Invoice/saveInvoice',
            success: function (result) {
                $scope.saveAutoTransaction(result);

                if ($scope.Purchase_Invoice.InvoiceTypeID == 1) {
                    $scope.savePaymentCash(result);
                }
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.saveAutoTransaction = function (PurchaseInvoiceID) {
        var totalAmount;
        var Note;

        $http.get("/accounting/Purchase_Invoice/getInvoiceTotalAmountByInvoiceID/" + PurchaseInvoiceID).success(function (result) {
            totalAmount = result;
            getNote(PurchaseInvoiceID);
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });

        function getNote(PurchaseInvoiceID) {
            $http.get("/accounting/Purchase_Invoice/getCurrentNoteByPurchaseInvoiceID/" + PurchaseInvoiceID).success(function (result) {
                Note = result;
                recordAutoTransaction();
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }

        function recordAutoTransaction() {
            // get Customer Chart Of Account [not implemented yet]
            var data = {
                Amount: totalAmount,
                AutoTransactionOperationID: 4,
                CurrencyID: $scope.Purchase_Invoice.CurrencyID,
                //FromID: $scope.Sales_Invoice.CurrencyID.CustomerID,
                Purchase_InvoiceTypeID: $scope.Purchase_Invoice.InvoiceTypeID,
                currentDate: $scope.Purchase_Invoice.InvoiceDate,
                Note: Note
            };

            $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction", data).success(function () {
                getPurchase_Invoices();
                $scope.cancelPurchase_Invoice();
                $rootScope.$emit("swAlertSave", {});
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });

        }
    }


    //$scope.delete = function () {$rootScope.$emit("swConfirmDelete",
    //       {
    //           function () {
    //               $http.post('/Purchase_Invoice/deletePurchaseInvoice', JSON.stringify($scope.selected)).success(function () {
    //                   getPurchase_Invoices();
    //                   $scope.selected = [];
    //               });
    //           }
    //       });
    //};

    function getDetails(InvoiceID) {
        $http.get('/Purchase_Invoice/getInvoiceDetailsByInvoiceID?id=' + InvoiceID).success(function (results) {
            $scope.Purchase_InvoiceDetails = results;
            for (var i = 0; i < $scope.Purchase_InvoiceDetails.length; i++) {
                $scope.getMeasureUnit($scope.Purchase_InvoiceDetails[i].PartID);
                $scope.Purchase_InvoiceDetails[i].MeasureUnits = $scope.MeasureUnits;
                $scope.getRowPrices($scope.Purchase_InvoiceDetails[i]);

            }
            $scope.getInvoiceTypes();
            $scope.getTotalQuantity();
            $scope.getPrice();
            $scope.getTaxes();
            $scope.getDiscount();
            $scope.getTaxesDiscount();
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.edit = function (Purchase_InvoiceID) {
        $http.get('/Purchase_Invoice/getInvoiceByID?InvoiceID=' + Purchase_InvoiceID).success(function (data) {

            $scope.Purchase_Invoice = data;

            $scope.getCurrencies();

            //if ($scope.Purchase_Invoice.CurrencyID != undefined) {

            //    getCurrency($scope.Purchase_Invoice.CurrencyID);
            //}

            HideMasterShowDetails("#DivShow", "#DivSave");

            getDetails(Purchase_InvoiceID);
            getInvoicePaymentsByInvoiceID(Purchase_InvoiceID);
            getInvoiceExpensesByInvoiceID(Purchase_InvoiceID);
            getAttachments(Purchase_InvoiceID);
            // $scope.showAdvancedEdit();



        });
    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.removeFilterProduct = function () {
        $scope.filtered.show = false;
        $scope.query.filtered = '';

        if ($scope.filtered.form.$dirty) {
            $scope.filtered.form.$setPristine();
        }
    };

    $scope.removeFilterDetails = function () {
        $scope.filterDetail.show = false;
        $scope.query.filterDetails = '';

        if ($scope.filterDetail.form.$dirty) {
            $scope.filterDetail.form.$setPristine();
        }
    }
    $scope.removeFilterPayment = function () {
        $scope.filterPayment.show = false;
        $scope.query.filterPayments = '';

        if ($scope.filterPayment.form.$dirty) {
            $scope.filterPayment.form.$setPristine();
        }
    }
    $scope.removeFilterExpense = function () {
        $scope.filterExpense.show = false;
        $scope.query.filterExpenses = '';

        if ($scope.filterExpense.form.$dirty) {
            $scope.filterExpense.form.$setPristine();
        }
    }


    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        Invoice: 'name',
        filter: '',
        filterPayment: '',
        filterExpense: '',
        filterAttachment: '',

        limit: 5,
        page: 1
    };



    // load orders
    $scope.LoadPurchaseOrder = function (ev) {

        $scope.getOrders();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Confirmation_LoadPurchaseOrder.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.LoadPurchaseOrder',
            closeTo: '.LoadPurchaseOrder'
        })

    };


    $scope.getOrders = function () {
        $http.get('/Confirmation_Order/GetALLOrders').success(function (results) {
            $scope.Purchase_Orders = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };
    $scope.getOrder = function (OrderID) {
        $http.get('/Confirmation_Order/GetDetailsByOrderID?id=' + OrderID).success(function (results) {
            $scope.OrderDetails = results;

            for (var i = 0; i < $scope.OrderDetails.length; i++) {
                $scope.Purchase_InvoiceDetails = [];
                var item = {};
                item.PartID = $scope.OrderDetails[i].ProductID;
                item.ProductName = $scope.OrderDetails[i].ProductName;
                item.MeasureUnitName = $scope.OrderDetails[i].MeasureUnitName;

                item.MeasureID = $scope.OrderDetails[i].MeasureID;
                item.Quantity = $scope.OrderDetails[i].Quantity;

                if ($scope.Setting != undefined) {
                    item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                    item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                }
                else {
                    $scope.getSetting();
                    if ($scope.Setting != undefined) {
                        item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                        item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                    }
                }

                $scope.Purchase_InvoiceDetails.push(item);

            }
            $scope.cancelProduct();
        }).error(function () {
            swAlertErrorAr();
        });
    };
    //load income order

    $scope.LoadIncomeOrder = function (ev) {

        $scope.getInvoices();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/LoadIncomeOrder.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.LoadIncomeOrder',
            closeTo: '.LoadIncomeOrder'
        })

    };
    $scope.getInvoice = function (id) {
        $http.get('/Inventory/InvoiceBuy/GetInvoiceByID/' + id).success(function (results) {
            $scope.invoice = results;
            $scope.Purchase_Invoice = {};
            $scope.Purchase_Invoice.Notes = " فاتورة شراء من اذن اضافة رقم " + $scope.Income_Order.BarCode;
            $scope.Purchase_Invoice.Invoice_BuyID = results.InvoiceID;
            $scope.Purchase_Invoice.SupplierName = $scope.Income_Order.SupplierName;

            $scope.Purchase_Invoice.SupplierID = $scope.Income_Order.SupplierID;
            getInvoiceBuyDetails(id);

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    $scope.getInvoices = function () {
        $http.get('/Inventory/InvoiceBuy/GetALLInvoices').success(function (results) {
            $scope.Income_Orders = results;

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    function getInvoiceBuyDetails(invoiceID) {
        $http.get('/Inventory/InvoiceBuy/getInvoiceDetailsByInvoiceID/' + invoiceID).success(function (results) {
            $scope.invoiceDetails = results;

            for (var i = 0; i < $scope.invoiceDetails.length; i++) {
                $scope.Purchase_InvoiceDetails = [];
                var item = {};
                item.PartID = $scope.invoiceDetails[i].ProductID;
                item.ProductName = $scope.invoiceDetails[i].ProductName;
                item.MeasureUnitName = $scope.invoiceDetails[i].MeasureUnitName;
                item.InvoiceDetailCode = $scope.invoiceDetails[i].ProductCode;
                item.ProductCode = $scope.invoiceDetails[i].ProductCode;
                item.MeasureID = $scope.invoiceDetails[i].MeasureID;
                item.Quantity = $scope.invoiceDetails[i].Quantity;

                if ($scope.Setting != undefined) {
                    item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                    item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                }
                else {
                    $scope.getSetting();
                    if ($scope.Setting != undefined) {
                        item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                        item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                    }
                }

                $scope.Purchase_InvoiceDetails.push(item);
            }
        }).error(function () {
            swAlertErrorAr();
        });
    };

    // Begin  drop down lists //
    $scope.getInvoiceTypes = function () {
        $http.get('/Purchase_InvoiceType/getPurchases_InvoiceTypes').success(function (results) {
            $scope.InvoiceTypes = results;

            for (var i = 0; i < $scope.InvoiceTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameAr;
                }
                else {
                    $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.deletePayment = function (model) {
        swConfirmDeleteAr(function () {
            $scope.Purchase_InvoicePayments.splice($.inArray(model, $scope.Purchase_InvoicePayments), 1);
            $scope.$apply();
            $scope.getPaymentTotalPrice();
        });
    }

    $scope.AddInvoicePayment = function () {
        $scope.Purchase_InvoicePayments.push({});

    }
    $scope.AddPayment = function (Purchase_InvoicePayment) {
        $scope.Purchase_InvoicePayments.push(Purchase_InvoicePayment);
        $scope.getPaymentTotalPrice();

        $scope.Purchase_InvoicePayment = {};
    }

    function getInvoicePayments() {
        $http.get('/Sales_Invoice/getPaymentTypes').success(function (results) {
            $scope.PaymentTypes = results;
            for (var i = 0; i < $scope.PaymentTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameAr;
                }
                else {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };


    $scope.showPaymentDialog = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Purchase_Invoice_Payment.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addPayment',
            closeTo: '.addPayment',
        })

    };

    //$scope.AddInvoiceExpense = function () {
    //    $scope.Purchase_InvoiceExpenses.push({});

    //}

    $scope.AddExpense = function (Purchase_InvoiceExpense) {
        Purchase_InvoiceExpense.ExpenseName = Purchase_InvoiceExpense.Title;
        $scope.Purchase_InvoiceExpenses.push(Purchase_InvoiceExpense);
        $scope.getExpenseTotalPrice();
        $scope.getTotalCost();
        $scope.getTotalInvoice();
        $scope.Purchase_InvoiceExpense = {};
    }



    function getInvoiceExpenses() {
        $http.get('/ExpenseType/getExpenseTypes').success(function (results) {
            $scope.ExpenseTypes = results;
            for (var i = 0; i < $scope.ExpenseTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.ExpenseTypes[i].Title = $scope.ExpenseTypes[i].NameAr;
                }
                else {
                    $scope.ExpenseTypes[i].Title = $scope.ExpenseTypes[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };




    $scope.showExpenseDialog = function (ev) {
        getInvoiceExpenses();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Purchase_Invoice_Expense.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addExpense',
            closeTo: '.addExpense'
        })

    };

    // End Select2 drop down lists //


    function getPurchase_Invoices() {
        $http.get('/Purchase_Invoice/getInvoices').success(function (results) {
            $scope.Purchase_Invoices = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };


    function getInvoicePaymentsByInvoiceID(InvoiceID) {
        $http.get('/Purchase_Invoice/getInvoicePaymentsByInvoiceID/' + InvoiceID).success(function (results) {
            $scope.Purchase_InvoicePayments = results;
            $scope.getPaymentTotalPrice();
        }).error(function () {
            swAlertErrorAr();
        });
    }
    function getInvoiceExpensesByInvoiceID(InvoiceID) {
        $http.get('/Purchase_Invoice/getInvoiceExpensesByInvoiceID/' + InvoiceID).success(function (results) {
            $scope.Purchase_InvoiceExpenses = results;
            $scope.getExpenseTotalPrice();
            $scope.getTotalCost();
            $scope.getTotalInvoice();
        }).error(function () {
            swAlertErrorAr();
        });
    }




    $scope.getTotalQuantity = function () {
        $scope.Sum.TotalQuantity = 0;
        $.each($scope.Purchase_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Quantity))) {
                $scope.Sum.TotalQuantity += parseFloat(item.Quantity);
            }
        });

    }

    $scope.getPrice = function () {
        $scope.Sum.Amount = 0;

        $.each($scope.Purchase_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Amount))) {
                $scope.Sum.Amount += parseFloat(item.Amount);
            }
        });
    }

    $scope.getDiscount = function () {
        $scope.Sum.Discount = 0;

        $.each($scope.Purchase_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Discount))) {
                $scope.Sum.Discount += parseFloat(item.Discount);
            }
        });
    }


    $scope.getTaxes = function () {
        $scope.Sum.Taxes = 0;

        $.each($scope.Purchase_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Taxes))) {
                $scope.Sum.Taxes += parseFloat(item.Taxes);
            }
        });
    }

    $scope.getTaxesDiscount = function () {
        $scope.Sum.TaxesDiscount = 0;
        $.each($scope.Purchase_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.TaxesDiscount))) {
                $scope.Sum.TaxesDiscount += parseFloat(item.TaxesDiscount);
            }
        });
    }

    $scope.getPaymentTotalPrice = function () {
        $scope.PaymentTotalPrice = 0;
        $.each($scope.Purchase_InvoicePayments, function (i, item) {
            if (!isNaN(parseFloat(item.Amount))) {
                $scope.PaymentTotalPrice += parseFloat(item.Amount);
            }
        });
    }
    $scope.getExpenseTotalPrice = function () {
        $scope.ExpenseTotalPrice = 0;
        $.each($scope.Purchase_InvoiceExpenses, function (i, item) {
            if (!isNaN(parseFloat(item.Amount))) {
                $scope.ExpenseTotalPrice += parseFloat(item.Amount);
            }
        });
    }

    $scope.getNetTotalPrice = function () {
        $scope.Sum.NetTotalPrice = 0;
        $.each($scope.Purchase_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.TotalPrice))) {
                $scope.Sum.NetTotalPrice += parseFloat(item.TotalPrice);
            }
        });

    }
    
    $scope.getTotalCost = function () {
        $scope.Sum.TotalCost = $scope.Sum.NetTotalPrice;
        $.each($scope.Purchase_InvoiceExpenses, function (i, item) {
            if (!isNaN(parseFloat(item.Amount)) && item.IsAddCost) {
                $scope.Sum.TotalCost += parseFloat(item.Amount);
            }
        });

    }

    $scope.getTotalInvoice = function () {
        $scope.Sum.TotalInvoice = $scope.Sum.NetTotalPrice;;
        $.each($scope.Purchase_InvoiceExpenses, function (i, item) {
            if (!isNaN(parseFloat(item.Amount)) && item.IsInvoice_Expense) {
                $scope.Sum.TotalInvoice += parseFloat(item.Amount);
            }
        });
        if (!isNaN(parseFloat($scope.Sum.TotalInvoice)) && !isNaN(parseFloat($scope.Sum.TotalCost)))
        $scope.Purchase_Invoice.Cost_Factor = $scope.Sum.TotalCost / $scope.Sum.TotalInvoice;
    }

    $scope.getRowPrices = function (item) {
        var Quantity = 0;
        var Price = 0;
        var Discount = 0;
        var Taxes = 0;
        var TaxesDiscount = 0;

        if (item.Quantity != undefined)
            Quantity = item.Quantity;
        else
            Quantity = 0;

        if (item.Amount != undefined)
            Price = item.Amount;
        else
            Price = 0;

        if (item.Discount != undefined)
            Discount = ((Quantity * Price) * item.Discount) / 100;
        else
            Discount = 0;

        if (item.Taxes != undefined)
            Taxes = ((Quantity * Price) * item.Taxes) / 100;
        else
            Taxes = 0;

        if (item.TaxesDiscount != undefined)
            TaxesDiscount = ((Quantity * Price) * item.TaxesDiscount) / 100;
        else
            TaxesDiscount = 0;

        item.TotalPrice = ((Quantity * Price) + Taxes - TaxesDiscount - Discount).toString();
        $scope.getNetTotalPrice();
    }

    $scope.deleteDetail = function (model) {
        swConfirmDeleteAr({
            function () {
                $scope.Purchase_InvoiceDetails.splice($.inArray(model, $scope.Purchase_InvoiceDetails), 1);

                $scope.$apply();
                $scope.selectedDetails = [];
                $scope.getTotalQuantity();
                $scope.getPrice();
                $scope.getDiscount();
                $scope.getTaxes();
                $scope.getTaxesDiscount();
                $scope.getNetTotalPrice();
            }
        });
    }


    $scope.deleteExpense = function (model) {
        swConfirmDeleteAr(function () {
            $scope.Purchase_InvoiceExpenses.splice($.inArray(model, $scope.Purchase_InvoiceExpenses), 1);
            $scope.$apply();
            $scope.getExpenseTotalPrice();
            $scope.getTotalCost();
            $scope.getTotalInvoice();
        });
    }

    // Attachments Methods
    $scope.addDetailAttachment = function (name, path) {
        //$scope.Attachment.IsDeleted = 0;
        $scope.Attachment.Name = name;
        $scope.Attachment.Path = path;
        $scope.Attachments.push($scope.Attachment);
        $scope.Attachment = {};
    };

    $scope.deleteDetailAttachment = function (model) {
        swConfirmDeleteAr(function () {
            if (model.AttachmentID != undefined) {
                $http.get('/ Purchase_Attachments/deleteAttachment/' + model.AttachmentID).success(function (results) {
                    getAttachments(model.JobOrderID);
                });
            }
            else {
                $scope.Attachments.splice($.inArray(model, $scope.Attachments), 1);
                $scope.$apply();
            }
        });
    }

    function getAttachments(InvoiceID) {
        $http.get('/Accounting/Purchase_Invoice/getInvoiceAttachmentByInvoiceID/' + InvoiceID).success(function (results) {
            $scope.Attachments = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.savePayment = function () {
        $http.post('/Accounting/Purchase_Invoice/saveInvoicePayment', { model: $scope.Purchase_InvoicePayment, Purchase_InvoiceID: $scope.Purchase_Invoice.InvoiceID }).success(function (results) {
            recordPaymentAutoTransaction(results);
            $scope.Purchase_InvoicePayments.push($scope.Purchase_InvoicePayment);
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    }

    $scope.savePaymentCash = function (InvoiceID) {
        $scope.Purchase_InvoicePayment.PaymentTypeID = 1;
        $scope.Purchase_InvoicePayment.Amount = $scope.Sum.NetTotalPrice;
        $scope.Purchase_InvoicePayment.PaymentDate = $scope.Purchase_Invoice.InvoiceDate;

        $http.post('/Accounting/Purchase_Invoice/saveInvoicePayment', { model: $scope.Purchase_InvoicePayment, Purchase_InvoiceID: InvoiceID }).success(function (results) {
            //recordPaymentAutoTransactionCash(results);
            recordPaymentAutoTransaction(results);
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    }

    function recordPaymentAutoTransaction(PurchaseInvoicePaymentID) {
        var Note;

        $http.get("/accounting/Purchase_Invoice/getCurrentPaymentNoteByPurchaseInvoicePaymentID/" + PurchaseInvoicePaymentID).success(function (result) {
            Note = result;
            recordAutoTransaction();
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });

        function recordAutoTransaction() {
            // get Customer Chart Of Account [not implemented yet]
            var data = {
                Amount: $scope.Purchase_InvoicePayment.Amount,
                AutoTransactionOperationID: 6,
                CurrencyID: $scope.Purchase_Invoice.CurrencyID,
                //FromID: $scope.Sales_Invoice.CurrencyID.CustomerID,
                PaymentTypeID: $scope.Purchase_InvoicePayment.PaymentTypeID,
                currentDate: $scope.Purchase_InvoicePayment.PaymentDate,
                Note: Note
            };
            $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction", data).success(function () {
                $scope.cancelDialog();
                $rootScope.$emit("swAlertSave", {});
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }

        //$scope.getCurrencyConvert = function (CurrencyID) {
        //    $http.get('/Currency/getConvertValueByCurrencyID?id=' + CurrencyID).success(function (data) {
        //        $scope.Purchase_Invoice.Currency_Convert = data;
        //    });
        //};

    }
    $scope.openImage = function (Path) {

        window.open(Path, '_blank');


    };



    $scope.checkReport = function (InvoiceID) {
        var reportParams = {
            "Parms": { "InvoiceID": InvoiceID },
            "ReportName": "PurchaseReport/PurchaseInvoiceReport.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }


});