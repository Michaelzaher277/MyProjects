﻿
angular.module('globalApp')
.controller('AllergyTypeController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.AllergyTypes = [];
    $scope.AllergyType = {};

    $scope.selected = [];


    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };

    getAllergyTypes();

    //function success(desserts) {
    //    $scope.desserts = ['christian', 'Non-christian'];
    //}

    //$scope.getDesserts = function () {
    //  $scope.promise = $nutrition.desserts.get($scope.query, success).$promise;
    //};

    function getAllergyTypes() {
        $http.get('/AllergyType/getAllergyTypes').success(function (results) {
            $scope.AllergyTypes = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/AllergyType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom : '.addButton',
            closeTo: '.addButton'
        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/AllergyType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.AllergyType = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.AllergyType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.AllergyType),
            url: '/AllergyType/saveAllergyType',
            success: function () {
                getAllergyTypes();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {
        swConfirmDeleteEn(function () {
            $http.post('/AllergyType/deleteAllergyType', JSON.stringify($scope.selected)).success(function () {
                getAllergyTypes();
                $scope.selected = [];
            });
        });
    }
    $scope.edit = function (AllergyTypeID) {
        $http.get('/AllergyType/getAllergyTypeByID/' + AllergyTypeID).success(function (data) {
            $scope.AllergyType = data;
            $scope.showAdvancedEdit();
        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});