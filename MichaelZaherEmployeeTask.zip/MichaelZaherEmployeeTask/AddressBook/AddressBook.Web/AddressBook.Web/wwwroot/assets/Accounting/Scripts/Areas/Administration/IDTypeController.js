﻿
angular.module('globalApp')
.controller('IDTypeController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.IDTypes = [];
    $scope.IDType = {};

    $scope.selected = [];


    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };

    getIDTypes();

   

    function getIDTypes() {
        $http.get('/IDType/getIDTypes').success(function (results) {
            $scope.IDTypes = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/IDType.tmpl.html',
             onRemoving: function () {
                $scope.cancel();
            },
             clickOutsideToClose: true,
             openFrom: '.addButton',
             closeTo: '.addButton'

        })

    };

    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/IDType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.IDType = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.IDType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.IDType),
            url: '/IDType/saveIDType',
            success: function () {
                getIDTypes();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {
        swConfirmDeleteEn(function () {
            $http.post('/IDType/deleteIDType', JSON.stringify($scope.selected)).success(function () {
                getIDTypes();
                $scope.selected = [];
            });
        });
    }
    $scope.edit = function (IDTypeID) {
        $http.get('/IDType/getIDTypeByID/' + IDTypeID).success(function (data) {
            $scope.IDType = data;
            $scope.showAdvancedEdit();
        });
    };
    $scope.deleteRowCallback = function (rows) {
        swConfirmDeleteWithActions(function () {
            for (var i = 0; i < rows.length; i++) {
                $scope.selected.push({ IDTypeID: rows[i], IsDeleted: false });
            }
            //= rows;
            $http.post('/Administration/IDType/deleteIDType', JSON.stringify($scope.selected)).success(function () {

                getIDTypes();
                $scope.selected = [];
            });
        }, function () {
            $http.get('/Administration/IDType/getIDTypes').success(function (results) {
                $scope.IDTypes = results;
            }).error(function () {
                swAlertErrorAr();
            });
        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});