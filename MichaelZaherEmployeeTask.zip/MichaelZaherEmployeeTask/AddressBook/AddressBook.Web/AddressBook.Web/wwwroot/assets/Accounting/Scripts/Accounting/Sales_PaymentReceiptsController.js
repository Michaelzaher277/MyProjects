﻿
angular.module('globalApp')
.controller('Sales_PaymentReceiptController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.SalesPaymentReceipts = [];
    

    getAllPayemntReceipts();



    function getAllPayemntReceipts() {
        $http.get('/Sales_PaymentReceipts/getAllSalesPaymentReceipts').success(function (results) {
            $scope.SalesPaymentReceipts = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.TransactionType = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.TransactionType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


   
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});