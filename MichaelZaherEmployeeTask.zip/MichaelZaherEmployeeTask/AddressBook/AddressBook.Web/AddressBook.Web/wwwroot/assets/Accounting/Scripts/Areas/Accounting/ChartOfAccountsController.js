﻿angular.module('globalApp')
    .controller('ChartOfAccountsController', function ($scope, $mdDialog, $http, $rootScope, $cookies) {
        var ChartOfAccountTree, nextId;
        //Chart Of Accounts Variables
        $scope.ChartOfAccounts = [];
        $scope.ChartOfAccount = {};
        $scope.ChartOfAccountScope = {};
        $scope.ChartOfAccountList = [];
        $scope.TreeIsValidate = true;

        //Chart Of Accounts Variables
        $scope.CostCenters = [];
        $scope.CostCenter = {};

        // Drop Down List Variables
        $scope.AccountTypes = [];
        $scope.AccountModes = [];
        $scope.Currencies = [];
        $scope.selected = [];
        // run at start
        getChartOfAccountTree();

        // Tree Functions
        //$scope.selectNode = function (node) {
        //    $scope.loadAccountTypes();
        //    $scope.loadAccountModes();
        //    $scope.loadCurrencies();
        //    $scope.ChartOfAccount = node.$modelValue;
        //    $scope.ChartOfAccountScope = node;
        //    $scope.accountForm.$setPristine();
        //    $scope.accountForm.$setUntouched();
        //    validateTree();
        //    //loadCostCenter();
        //}
        $scope.toggle = function (scope) {
            scope.toggle();
        };
        function openNode(id, select) {
            for (var i = 0; i < ChartOfAccountTree.length; i++)
                if (ChartOfAccountTree[i].id == id) {
                    ChartOfAccountTree[i].state = { "opened": true, "selected": select };
                    if (ChartOfAccountTree[i].parent != null)
                        openNode(ChartOfAccountTree[i].parent, false);
                    break;
                }
        }

        function loadChartOfAccount(data) {
            $scope.loadAccountTypes();
            $scope.loadAccountModes();
            $scope.loadCurrencies();
            $scope.ChartOfAccount = data;
            $scope.$apply();
            $scope.accountForm.$setPristine();
            $scope.accountForm.$setUntouched();
        }

        $scope.createSubParentAccount = function () {
            nextId++;
            ChartOfAccountTree.push({
                id: nextId,
                text: ($cookies.get('ERP_lang') == 'ar-EG') ? 'حساب رئيسى جديد' : 'New Parent-Account',
                parent: $scope.ChartOfAccount.ChartOfAccountID,
                type: 'parent'
            });
            $scope.ChartOfAccount = {
                ChartOfAccountID: nextId,
                AccountEnglishName: 'حساب رئيسى جديد',
                AccountArabicName: 'New Parent-Account',
                AccountCode: "",
                DefaultCurrencyID: "",
                IsGroup: true,
                ParentID: $scope.ChartOfAccount.ChartOfAccountID,
                Credit_OpeningBalance: 0,
                Debit_OpeningBalance:0
            };
            $scope.ChartOfAccountList.push($scope.ChartOfAccount);
            openNode($scope.ChartOfAccount.ChartOfAccountID, true);
            loadJsTree();
            loadChartOfAccount($scope.ChartOfAccount);
            //if ($cookies.get('ERP_lang') == 'ar-EG') {
            //    $scope.ChartOfAccount.Children.push({
            //        Name: 'حساب رئيسى جديد',
            //        ParentID: $scope.ChartOfAccount.ChartOfAccountID,
            //        Children: [],
            //        IsGroup: true
            //    });
            //}
            //else {
            //    $scope.ChartOfAccount.Children.push({
            //        Name: 'New Parent-Account',
            //        ParentID: $scope.ChartOfAccount.ChartOfAccountID,
            //        Children: [],
            //        IsGroup: true
            //    });
            //}
            //validateTree();
        }
        
        $scope.createSubAccount = function () {
            nextId++;
            ChartOfAccountTree.push({
                id: nextId,
                text: ($cookies.get('ERP_lang') == 'ar-EG') ? 'حساب فرعى جديد' : 'New Sub-Account',
                parent: $scope.ChartOfAccount.ChartOfAccountID,
                icon: `/Areas/Accounting/assets/images/file.png`,
                type: 'sub',               
            });
            $scope.ChartOfAccount = {
                ChartOfAccountID: nextId,
                AccountEnglishName: 'حساب فرعى جديد',
                AccountArabicName: 'New Sub-Account',
                AccountCode: "",
                DefaultCurrencyID: "",
                IsGroup: false,
                ParentID: $scope.ChartOfAccount.ChartOfAccountID,
                Credit_OpeningBalance: 0,
                Debit_OpeningBalance: 0
            };
            $scope.ChartOfAccountList.push($scope.ChartOfAccount);
            openNode($scope.ChartOfAccount.ChartOfAccountID, true);
            loadJsTree();
            loadChartOfAccount($scope.ChartOfAccount);
            //if ($cookies.get('ERP_lang') == 'ar-EG') {
            //    $scope.ChartOfAccount.Children.push({
            //        Name: 'حساب فرعى جديد',
            //        ParentID: $scope.ChartOfAccount.ChartOfAccountID,
            //        Children: [],
            //        IsGroup: false
            //    });
            //}
            //else {
            //    $scope.ChartOfAccount.Children.push({
            //        Name: 'New Sub-Account',
            //        ParentID: $scope.ChartOfAccount.ChartOfAccountID,
            //        Children: [],
            //        IsGroup: false
            //    });
            //}
            //validateTree();
        }
        //$scope.createMainSubParentAccount = function () {
        //    if ($cookies.get('ERP_lang') == 'ar-EG') {
        //        $scope.ChartOfAccounts.push({
        //            Name: 'حساب رئيسى جديد',
        //            Children: [],
        //            IsGroup: true
        //        });
        //    }
        //    else {
        //        $scope.ChartOfAccounts.push({
        //            Name: 'New Parent-Account',
        //            Children: [],
        //            IsGroup: true
        //        });
        //    }
        //    validateTree();
        //}
        //$scope.createMainSubAccount = function () {
        //    if ($cookies.get('ERP_lang') == 'ar-EG') {
        //        $scope.ChartOfAccounts.push({
        //            Name: 'حساب فرعى جديد',
        //            Children: [],
        //            IsGroup: false
        //        });
        //    }
        //    else {
        //        $scope.ChartOfAccounts.push({
        //            Name: 'New Sub-Account',
        //            Children: [],
        //            IsGroup: false
        //        });
        //    }
        //    validateTree();
        //}

        $scope.deleteSelectedNode = function (account) {
            $rootScope.$emit("swConfirmDelete",
                {
                    function() {
                        if (account.ChartOfAccountID != undefined) {
                            $http.get('/Accounting/ChartOfAccounts/deleteChartOfAccountByAccountID/' + account.ChartOfAccountID).success(function (result) {
                                if (result == 1) {
                                    getChartOfAccountTree();
                                    $scope.ChartOfAccount = {};
                                    $scope.ChartOfAccountScope = {};
                                } else {
                                    $rootScope.$emit("swAlertSorry", {});
                                }

                            }).error(function () {
                                $rootScope.$emit("swAlertError", {});
                            });
                        } else {
                            //$scope.ChartOfAccounts.splice($.inArray(account, $scope.ChartOfAccounts), 1);
                            //$scope.$apply();
                            $scope.ChartOfAccountScope.remove();
                            $scope.ChartOfAccountScope = {};
                        }
                    }
                });
        }

        $scope.saveTree = function () {
            $scope.accountForm.$setSubmitted();
            //validateTree();
            //if ($scope.TreeIsValidate) {
            $http.post('/Accounting/ChartOfAccounts/updateTree', $scope.ChartOfAccountList).success(function () {
                $rootScope.$emit("swAlertSave", {});
                getChartOfAccountTree();
                $scope.ChartOfAccount = {};
                $scope.accountForm.$setPristine()=-9
                $scope.accountForm.$setUntouched();
                validateTree();
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
            //} else {
            //    $rootScope.$emit("swErrorValidation", {});
            //}
        }

        function loadJsTree() {
            $("#ChartOfAccount").jstree('destroy');
            $("#ChartOfAccount").on('changed.jstree', function (e, data) {
                
                if (data.selected.length > 0) {
                    for (var i = 0; i < $scope.ChartOfAccountList.length; i++)
                        if ($scope.ChartOfAccountList[i].ChartOfAccountID == data.selected[data.selected.length - 1])
                            loadChartOfAccount($scope.ChartOfAccountList[i]);
                }
            }).jstree({
                'core': {
                    'data': ChartOfAccountTree,
                    "multiple": false,
                },
                "checkbox": {
                    "keep_selected_style": false,
                    "three_state": false,
                },
                "plugins": ["checkbox"]
            });
        }

        function getChartOfAccountTree() {
            $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTre').success(function (results) {
                $scope.ChartOfAccountList = results;
                ChartOfAccountTree = new Array();
                for (var i = 0; i < results.length; i++) {
                    var temp = { "id": results[i].ChartOfAccountID };
                    ($cookies.get('ERP_lang') == 'ar-EG') ? temp.text = results[i].AccountArabicName : results[i].AccountEnglishName
                    temp.parent = (results[i].ParentID == null) ? "#" : results[i].ParentID;
                    temp.state = (results[i].ParentID == null) ? { "opened": true } : null;
                    var check = false;
                    for (var m = 0; m < results.length; m++)
                        if (results[m].ParentID == temp.id)
                            check = true;
                    temp.icon = (check) ? null : "/Areas/Accounting/assets/images/file.png";
                    ChartOfAccountTree.push(temp);
                }
                nextId = results[results.length - 1].ChartOfAccountID;
                //$scope.ChartOfAccounts = results.treeObj;
                //$scope.ChartOfAccountList = results.treeList;
                loadJsTree();
                //validateTree();
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };

        function validateTree() {
            $scope.TreeIsValidate = true;
            $.each($scope.ChartOfAccounts, function (i, item) {
                if (!item.ParentID) {

                    if (item.AccountArabicName && item.AccountEnglishName && item.AccountArabicDisplayPath && item.AccountEnglishDisplayPath && item.AccountCode && ((item.AccountTypeID && item.AccountModeID && item.DefaultCurrencyID && item.Credit_OpeningBalance != undefined && item.Debit_OpeningBalance != undefined) || item.IsGroup)) {
                        item.isValidate = true;
                        item.AccountCodeIsNotValidate = false;
                        $.each($scope.ChartOfAccountList, function (i, accItem) {
                            if (accItem.AccountCode == item.AccountCode && accItem.ChartOfAccountID != item.ChartOfAccountID) {
                                $scope.TreeIsValidate = false;
                                item.AccountCodeIsNotValidate = true;
                                item.isValidate = false;
                            }
                        });
                    }
                    else {
                        item.isValidate = false;
                        $scope.TreeIsValidate = false;
                    }

                    if (item.Children != null) {
                        validateTreeChildren(item.Children);
                    }

                }

            });
        }

        function validateTreeChildren(account) {
            $.each(account, function (i, item) {

                if (item.AccountArabicName && item.AccountEnglishName && item.AccountArabicDisplayPath && item.AccountEnglishDisplayPath && item.AccountCode && ((item.AccountTypeID && item.AccountModeID && item.DefaultCurrencyID && item.Credit_OpeningBalance != undefined && item.Debit_OpeningBalance != undefined) || item.IsGroup)) {
                    item.isValidate = true;
                    item.AccountCodeIsNotValidate = false;
                    $.each($scope.ChartOfAccountList, function (i, accItem) {
                        if (accItem.AccountCode == item.AccountCode && accItem.ChartOfAccountID != item.ChartOfAccountID) {
                            $scope.TreeIsValidate = false;
                            item.AccountCodeIsNotValidate = true;
                            item.isValidate = false;
                        }
                    });
                }
                else {
                    item.isValidate = false;
                    $scope.TreeIsValidate = false;
                }

                if (item.Children != null) {
                    validateTreeChildren(item.Children);
                }

            });
        }

        // Cost Center Function
        function loadCostCenter() {
            $http.get('/Accounting/ChartOfAccounts/getCostCentersByChartOfAccountID/' + $scope.ChartOfAccount.ChartOfAccountID).success(function (results) {
                $scope.CostCenters = results;
                for (var i = 0; i < $scope.CostCenters.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.CostCenters[i].Title = $scope.CostCenters[i].CostCenterArabicName;
                    }
                    else {
                        $scope.CostCenters[i].Title = $scope.CostCenters[i].CostCenterEnglishName;
                    }
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
        $scope.showAddCostCenter = function () {

        }

        // Drop Down List Functions
        $scope.loadAccountTypes = function () {
            if ($scope.AccountTypes.length <= 0) {
                $http.get('/Accounting/AccountTypes/getAllAcountTypes').success(function (results) {
                    $scope.AccountTypes = results;
                    for (var i = 0; i < $scope.AccountTypes.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.AccountTypes[i].Title = $scope.AccountTypes[i].NameAr;
                        }
                        else {
                            $scope.AccountTypes[i].Title = $scope.AccountTypes[i].NameEn;
                        }
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        }
        $scope.loadAccountModes = function () {
            if ($scope.AccountModes.length <= 0) {
                $http.get('/Accounting/AccountModes/getAllAccountModes').success(function (results) {
                    $scope.AccountModes = results;
                    for (var i = 0; i < $scope.AccountModes.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.AccountModes[i].Title = $scope.AccountModes[i].NameAr;
                        }
                        else {
                            $scope.AccountModes[i].Title = $scope.AccountModes[i].NameEn;
                        }
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        }
        $scope.loadCurrencies = function () {
            if ($scope.Currencies.length <= 0) {
                $http.get('/Accounting/Currency/GetCurrencies').success(function (results) {
                    $scope.Currencies = results;
                    for (var i = 0; i < $scope.Currencies.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                        }
                        else {
                            $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                        }
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        }
        $scope.checkAccountCode = function () {
            validateTree();
        }
    });