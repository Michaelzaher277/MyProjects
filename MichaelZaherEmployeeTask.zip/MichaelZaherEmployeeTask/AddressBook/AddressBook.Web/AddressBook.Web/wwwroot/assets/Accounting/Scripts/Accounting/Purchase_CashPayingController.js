﻿angular.module('globalApp')
.controller('Purchase_CashPayingController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $element) {

    $scope.Purchase_CashPaying = {};
    $scope.Purchase_Invoices = [];
    $scope.Purchase_InvoicesSelected = [];

    $scope.Suppliers = [];
    $scope.searchTerm = "";
    $scope.SelectedSupplierID = 0;

    $scope.clearSearchTerm = function () {
        $scope.searchTerm = "";
        $scop.getAvailablePurchase_Invoices();
    };


    $element.find('input#searchSuppliers').on('keydown', function (ev) {
        ev.stopPropagation();
    });

    $scope.SearchSuppliers = function () {
        
        $http.get('/Purchase_Invoice/GetSuppliers').success(function (results) {
            $scope.Suppliers = results;
         
            for (var i = 0; i < $scope.Suppliers.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Suppliers[i].Title = $scope.Suppliers[i].NameAr;
                }
                else {
                    $scope.Suppliers[i].Title = $scope.Suppliers[i].NameEng;
                }
            }
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function clearFields() {
        $scope.Purchase_CashPaying = {};
        $scope.Purchase_InvoicesSelected = [];
    };

    $scope.getAvailablePurchase_Invoices = function () {
            $http.get('/Purchase_Invoice/getUnPaidInvoicesBySupplierID/' + $scope.SelectedSupplierID).success(function (results) {
                $scope.Purchase_Invoices = results;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
    };

    $scope.save = function () {
        if ($cookies.get('ERP_lang') == 'ar-EG') {
            $rootScope.$emit("swConfirmAction", {
                text: "هل تريد الدفع للفواتير المختارة", function () {
                    $.each($scope.Purchase_Invoices, function (i, item) {
                        if (item.IsSelected) {
                            $scope.Purchase_InvoicesSelected.push(item);
                        }
                    });
                    var parms = {
                        PurchaseInvoices: $scope.Purchase_InvoicesSelected,
                        cashPaying: $scope.Purchase_CashPaying
                    }
                    $.ajax({
                        type: 'POST',
                        contentType: 'application/json; charset=utf-8',
                        data: JSON.stringify(parms),
                        url: '/Purchase_CashPaying/PayPurchaseInvoices',
                        success: function (result) {
                            $scope.Purchase_CashPaying = result;
                            recordPaymentAutoTransaction($scope.Purchase_CashPaying);
                        },
                        error: function () {
                            $rootScope.$emit("swAlertError", {});
                        }
                    });

                }
            });
           
        }
        else {
            $rootScope.$emit("swConfirmAction", {
                text: "Are you need to pay selected invoices ?", function () {
                    $.each($scope.Purchase_Invoices, function (i, item) {
                        if (item.IsSelected) {
                            $scope.Purchase_InvoicesSelected.push(item);
                        }
                    });
                    var parms = {
                        PurchaseInvoices: $scope.Purchase_InvoicesSelected,
                        cashPaying: $scope.Purchase_CashPaying
                    }
                    $.ajax({
                        type: 'POST',
                        contentType: 'application/json; charset=utf-8',
                        data: JSON.stringify(parms),
                        url: '/Purchase_CashPaying/PayPurchaseInvoices',
                        success: function (result) {
                            $scope.Purchase_CashPaying = result;
                            recordPaymentAutoTransaction($scope.Purchase_CashPaying);
                        },
                        error: function () {
                            $rootScope.$emit("swAlertError", {});
                        }
                    });

                }
            });
        }
    };

    $scope.cancel = function()
    {
        clearFields();
        $scope.getAvailablePurchase_Invoices();
    }

    $scope.select = function (model) {
        model.IsSelected = true;
    }

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';
        $scope.SelectedSupplierID = 0;
        $scope.searchTerm = "";
        $scope.Suppliers = [];
        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
        $scope.getAvailablePurchase_Invoices();

    };
    function swPaymentDoneAr(remainingAmount) {
        swal({
            title: 'تم الحفظ بنجاح!',
            text: 'باقى القيمة : ' + remainingAmount,
            type: 'success',
            showCancelButton: false,
            confirmButtonColor: '#BFBFBF',
            confirmButtonText: '<i class="fa fa-check"></i> تم',
        }).then(function () {
            clearFields();
            $scope.getAvailablePurchase_Invoices();
        })
    }

    function swPaymentDoneEn(remainingAmount) {
        swal({
            title: 'Saved successfully!',
            text: 'Remaining Amount: ' + remainingAmount,
            type: 'success',
            showCancelButton: false,
            confirmButtonColor: '#BFBFBF',
            confirmButtonText: '<i class="fa fa-check"></i> Ok',
        }).then(function () {
            clearFields();
         //   getAvailablePurchase_Invoices();
        })
    }

    function recordPaymentAutoTransaction(CashPaying) {
        var Note;
        $http.post("/accounting/Purchase_CashPaying/getCurrentNoteByCashPaying", CashPaying).success(function (result) {
            Note = result;
            recordAutoTransaction(CashPaying);
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });

        function recordAutoTransaction(CashPaying) {
            // get Customer Chart Of Account [not implemented yet]
            var data = {
                Amount: CashPaying.Amount,
                AutoTransactionOperationID: 20,
                CurrencyID: 1, // should be set dynamically based on the default currency for the account
                //FromID: $scope.Sales_Invoice.CurrencyID.CustomerID,
                PaymentTypeID: 1, // 1 for cash payments in PaymentType Table in DB
                currentDate: CashPaying.PaymentDate,
                Note: Note
            };

            $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction", data).success(function () {
                swPaymentDoneAr($scope.Purchase_CashPaying.RemainingAmount);
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    }
});