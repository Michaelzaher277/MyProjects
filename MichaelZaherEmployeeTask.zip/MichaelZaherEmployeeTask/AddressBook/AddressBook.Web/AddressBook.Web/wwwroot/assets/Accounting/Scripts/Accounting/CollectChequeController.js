﻿

angular.module('globalApp')
.controller('CollectChequeController', function ($scope, $mdDialog, $http, $rootScope, $element, $cookies) {

    $scope.CollectCheque = {};

    $scope.Cheques = [];
    $scope.Safes = [];
    $scope.Banks = [];
    $scope.BankBranches = [];
    $scope.BankBranchAccounts = [];   

    $scope.SelectedCheque = {};
    $scope.SelectedToSafeCheque = {};
    $scope.SelectedToBankCheque = {};

    //$scope.Currencies = [];   

    $scope.getCheques = function () {
        $http.get('/Accounting/ChequeRecieve/getSavedChequeRecieves').success(function (results) {
            $scope.Cheques = results;           
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.ChangeStatusCheque = function (id) {
        var satus;

        if ($scope.CollectCheque.CollectChequeTo == 1) {
            status = 3
        }
        else if ($scope.CollectCheque.CollectChequeTo == 2)
        {
            status = 3;
        }

        $http.get('/Accounting/ChequeRecieve/ChangeStatusCheque?id='+id+'&status='+status).success(function (results) {
        //    $scope.Cheques = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    //$scope.loadCurrencies = function () {
    //    if ($scope.Currencies.length <= 0) {
    //        $http.get('/Accounting/Currency/GetCurrencies').success(function (results) {
    //            $scope.Currencies = results;
    //            for (var i = 0; i < $scope.Currencies.length; i++) {
    //                if ($cookies.get('ERP_lang') == 'ar-EG') {
    //                    $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
    //                }
    //                else {
    //                    $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
    //                }
    //            }
    //        }).error(function () {
    //            $rootScope.$emit("swAlertError", {});
    //        });
    //    }
    //}

    $scope.getSafes = function () {
        $http.get('Accounting/CollectCheque/GetALLSafes').success(function (results) {
            $scope.Safes = results;
            for (var i = 0; i < $scope.Safes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Safes[i].Title = $scope.Safes[i].SafeNameAr;
                }
                else {
                    $scope.Safes[i].Title = $scope.Safes[i].SafeNameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    // Bank Branches Functions
    $scope.getBanks = function () {
        $http.get('/Accounting/Banks/getBanks').success(function (results) {
            $scope.Banks = results;
            for (var i = 0; i < $scope.Banks.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Banks[i].Title = $scope.Banks[i].NameAr;
                }
                else {
                    $scope.Banks[i].Title = $scope.Banks[i].NameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.getBankBranches = function (id) {
        if (id != undefined) {
            $http.get('/Accounting/BankBranches/getBankBranchesByBankID/' + id).success(function (results) {
                $scope.BankBranches = results;
                for (var i = 0; i < $scope.BankBranches.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.BankBranches[i].Title = $scope.BankBranches[i].NameAr;
                    }
                    else {
                        $scope.BankBranches[i].Title = $scope.BankBranches[i].NameEn;
                    }
                }
                $scope.BranchID = null;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.getBankBranchAccounts = function (id) {
        if (id != undefined) {
            $http.get('/Accounting/BankBranchAccounts/getBankBranchAccountsByBankBranchID/' + id).success(function (results) {
                $scope.BankBranchAccounts = results;
                for (var i = 0; i < $scope.BankBranchAccounts.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameAr;
                    }
                    else {
                        $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameEn;
                    }
                }
                $scope.BranchID = null;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.savediag = function () {
        $scope.save();
    };

    $scope.save = function () {

        if ($scope.SelectedCheque.SupplierChartAccountID > 0) {
            $scope.CollectCheque.CreditAccountID = $scope.SelectedCheque.SupplierChartAccountID;
        }
        else if ($scope.SelectedCheque.CustomerChartAccountID > 0) {
            $scope.CollectCheque.CreditAccountID = $scope.SelectedCheque.CustomerChartAccountID;
        }
        else if ($scope.SelectedCheque.ChartOfAccountID != undefined) {
            $scope.CollectCheque.CreditAccountID = $scope.SelectedCheque.ChartOfAccountID;
        }


        if ($scope.CollectCheque.CollectChequeTo == 1) {
            if ($scope.SelectedToSafeCheque.ChartOfAccount_Cheque != undefined)
                $scope.CollectCheque.DepitAccountID = $scope.SelectedToSafeCheque.ChartOfAccount_Cheque;
            else
                $scope.CollectCheque.DepitAccountID = $scope.SelectedToSafeCheque.ChartOfAccount_Cash;
        }
        else if ($scope.CollectCheque.CollectChequeTo == 2) {
            if ($scope.SelectedToBankCheque.ChartOfAccount_Cheque != undefined)
                $scope.CollectCheque.DepitAccountID = $scope.SelectedToBankCheque.ChartOfAccount_Cheque;
            else
                $scope.CollectCheque.DepitAccountID = $scope.SelectedToBankCheque.ChartOfAccount_Cash;
        }     

        $scope.CollectCheque.Amount = $scope.SelectedCheque.Amount;
        $scope.CollectCheque.CurrencyID = $scope.SelectedCheque.CurrencyID;
        $scope.CollectCheque.Currency_Convert = $scope.SelectedCheque.Currency_Convert;

        //$http.post("/Accounting/CollectCheque/saveTransaction", $scope.CollectCheque).success(function () {

            $scope.ChangeStatusCheque($scope.SelectedCheque.ChequeID);

            var note;
            var AutoTransactionOperationID;

            if ($scope.CollectCheque.CollectChequeTo == 1) {
                 note = 'تحصيل الشيك من الخزنة';
                 AutoTransactionOperationID = 11;
               
            }
            else if ($scope.CollectCheque.CollectChequeTo == 2)
            {
                note = 'تحصيل الشيك من البنك';
                AutoTransactionOperationID = 10;
            }

            var data = {
                Amount: $scope.SelectedCheque.Amount,
                AutoTransactionOperationID: AutoTransactionOperationID,
                CurrencyID: $scope.SelectedCheque.CurrencyID,
                //FromID: $scope.CollectCheque.DepitAccountID,
                ToID: $scope.CollectCheque.DepitAccountID,
                currencyConvert: $scope.SelectedCheque.Currency_Convert,
                //currentDate: $scope.SelectedCheque.ChequeDate,
                currentDate: $scope.CollectCheque.Date,
                Note: note
            };

            recordAutoTransaction(data);

            $scope.CollectCheque = {};

            $scope.CollectCheque.Amount = undefined;            

            $scope.SelectedCheque = {};

            $scope.SelectedToSafeCheque = {};
            $scope.SelectedToBankCheque = {};           

            $rootScope.$emit("swAlertSave", {});

        //}).error(function () {
        //    $rootScope.$emit("swAlertError", {});
        //})

    };       
    
    function recordAutoTransaction(data) {


        $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction", data).success(function () {
            //  getSales_Invoices();
            /// HideMasterShowDetails('#divDetails', '#divMain');
            // $scope.clearFields();
            //swAlertSaveAr();
        

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    }

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Attendance = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Attendance = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };    

    $scope.limitOptions = [5, 10, 15];

    $scope.options = {
        pageSelect: true
    };

    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

});