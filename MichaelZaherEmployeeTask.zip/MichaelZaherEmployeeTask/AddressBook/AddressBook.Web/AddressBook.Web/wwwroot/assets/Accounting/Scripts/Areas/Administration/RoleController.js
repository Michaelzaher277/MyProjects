﻿
angular.module('globalApp')
.controller('RoleController', function ($scope, $http, $mdDialog, $rootScope) {
    $scope.Roles = [];
    $scope.Role = {};
    $scope.selected = [];
    
    getRoles();
   

    function clear() {
        $scope.Role = {};
    };

    function getRoles() {
        $http.get('/Administration/Security/GetRoles').success(function (results) {
            $scope.Roles = results;
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });

    };
    
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/Role.tmpl.html',            
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom : '.addButton',
            closeTo: '.addButton'
        })
        
    };

    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/Role.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Role = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Role = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };

    $scope.save = function () {
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Role),
            url: '/Administration/Security/saveRole',
            success: function () {
                getRoles();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.delete = function () {
        swConfirmDeleteEn(function () {
            $http.post('/Administration/Security/deleteRole/', JSON.stringify($scope.selected)).success(function () {
                getRoles();
                $scope.selected = [];
            });
        });
    }
    $scope.edit = function (RoleID) {
        $http.get('/Administration/Security/GetRoleByID/' + RoleID).success(function (data) {
            $scope.Role = data;
            $scope.showAdvancedEdit();
        });
    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

})