﻿
angular.module('globalApp')
.controller('ClaimController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter) {

    $scope.Claims = [];
    $scope.Claim = {};
    $scope.Examination_Records = [];
    $scope.filterJobOrdered = '';
    $scope.selected = [];
    $scope.selectedProduct = [];
    $scope.selectedDetails = [];
    $scope.selectedExaminationRecord = [];
    $scope.AddNew = false;
    getClaims();
    getReasons();
    $scope.ClaimDetail = {};
    $scope.ClaimDetails = [];
    $scope.Product = {};
    HideMasterShowDetails("#DivSave", "#DivShow");

    function getLastCodeClaims() {
        $http.get('/Claim/GetLastCodeClaims').success(function (results) {
            $scope.Claim.ClaimCode = results;
            //var today = $filter('date')(new Date(), 'yyyy-MM-dd');
            $scope.Claim.ClaimDate = new Date();;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    function getClaims() {
        $http.get('/Claim/GetALLClaims').success(function (results) {
            $scope.Claims = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.showAdvancedAdd = function (ev) {
        //  $("DivShow)
        HideMasterShowDetails("#DivShow", "#DivSave");
        getLastCodeClaims();


    };

    $scope.getMeasureUnit = function (productID) {
        $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
            $scope.MeasureUnits = results;
            for (var i = 0; i < $scope.MeasureUnits.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
                }
                else {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEng;
                }
            }

            for (var i = 0; i < $scope.ClaimDetails.length; i++) {
                if ($scope.ClaimDetails[i].ProductID == productID)
                    $scope.ClaimDetails[i].MeasureUnits = $scope.MeasureUnits;
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };


    $scope.getProductModal = function (modal) {

        for (i = 0; i < modal.length; i++) {
            if (modal[i].ProductID != null) {
                var item = {};
                item.ProductID = modal[i].ProductID;
                item.ProductName = modal[i].NameAr;
                item.ProductCode = modal[i].Code;
                item.MeasureUnits = modal[i].MeasureUnits;
                for (var j = 0; j < item.MeasureUnits.length; j++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                    }
                    else {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                    }
                }
                var foundItem = $filter('filter')($scope.ClaimDetails, { ProductCode: modal[i].Code }, true)[0];

                if (foundItem == undefined) {
                    $scope.ClaimDetails.push(item);
                }
                //$scope.ClaimDetails.push(item);
            }
        }
        //    $scope.cancelProduct();

        // $('#DivParts').modal('toggle');
    };

    $scope.getAllProductsModal = function () {
        $http.get('/Inventory/ProductDetails/GetProducts').success(function (results) {
            $scope.Products = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    }

    $scope.showProductsAdd = function (ev) {
        //  $("DivShow)
        //   $scope.Purchase_OrderDetails.push({});
        //  $scope.getAllProductsModal();
        $scope.GetTopProducts("");

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadProducts.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addProduct',
            closeTo: '.addProduct'
        })
    }

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Claim = {};
    };


    $scope.cancelDialog = function () {

        $mdDialog.cancel();
    };

    $scope.cancelProduct = function () {
        //$scope.AddNew = true;

        $mdDialog.cancel();
        $scope.selectedProduct = [];

        //   $scope.Claim = {};
    };
    $scope.cancelClaim = function () {
        //   $mdDialog.cancel();
        HideMasterShowDetails("#DivSave", "#DivShow");
        $scope.Claim = {};
        $scope.ClaimDetails = [];
        $scope.selected = [];
        $scope.selectedProduct = [];
        $scope.selectedDetails = [];

    };


    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {
        $scope.Claim.ClaimDetails = $scope.ClaimDetails;
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Claim),
            url: '/Claim/save',
            success: function () {
                getClaims();
                $scope.cancelClaim();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Claim/deleteExaminationClaim', JSON.stringify($scope.selected)).success(function () {
                       getClaims();
                       $scope.selected = [];
                   });
               }
           });
    }

    $scope.deleteDetail = function (model) {
        swConfirmDeleteAr({
            function () {
                $scope.ClaimDetails.splice($.inArray(model, $scope.ClaimDetails), 1);

                $scope.$apply();
                $scope.selectedDetails = [];

            }
        });
    }

    function getDetails(ClaimID) {
        $http.get('/Claim/GetDetailsByClaimID?id=' + ClaimID).success(function (results) {
            $scope.ClaimDetails = results;
            for (var i = 0; i < $scope.ClaimDetails.length; i++) {
                $scope.getMeasureUnit($scope.ClaimDetails[i].ProductID);
                $scope.ClaimDetails[i].MeasureUnits = $scope.MeasureUnits;
            }
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.edit = function (ClaimID) {
        $http.get('/Claim/GetClaimByID/' + ClaimID).success(function (data) {
            $scope.Claim = data;
            getDetails(ClaimID);
            // $scope.showAdvancedEdit();
            HideMasterShowDetails("#DivShow", "#DivSave");


        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.removeFilterProduct = function () {
        $scope.filtered.show = false;
        $scope.query.filtered = '';

        if ($scope.filtered.form.$dirty) {
            $scope.filtered.form.$setPristine();
        }
    };

    $scope.removeFilterDetails = function () {
        $scope.filterDetails.show = false;
        $scope.query.filterDetails = '';

        if ($scope.filterDetails.form.$dirty) {
            $scope.filterDetails.form.$setPristine();
        }
    };
    function getReasons() {
        $http.get('/Claim/GetReasons').success(function (results) {
            $scope.Reasons = results;
            for (var i = 0; i < $scope.Reasons.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Reasons[i].Title = $scope.Reasons[i].NameAr;
                }
                else {
                    $scope.Reasons[i].Title = $scope.Reasons[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.LoadExaminationRecord = function (ev) {

        getOrders();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Claim_LoadExaminationRecord.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.LoadOrder',
            closeTo: '.LoadOrder'
        })

    };

    //load Order
    function getOrders() {

        $http.get('/Examination_Record/GetALLRecordsApprovedClaim').success(function (results) {
            $scope.Examination_Records = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    $scope.getOrder = function (OrderID) {
        $http.get('/Examination_Record/GetDetailsByApprovedRecordID?id=' + OrderID).success(function (results) {
            $scope.ClaimDetails = results;
            //$scope.invoice.OrderID = results[0].RecordID;
            $scope.Claim.RecordID = results[0].RecordID;
            for (var i = 0; i < $scope.ClaimDetails.length; i++) {
                $scope.getMeasureUnit($scope.ClaimDetails[i].ProductID);
                $scope.ClaimDetails[i].MeasureUnits = $scope.MeasureUnits;
                $scope.ClaimDetails[i].MeasureUnitID = $scope.ClaimDetails[i].MeasureID;

            }
            //$('#DivOrders').modal('toggle');
            $scope.cancelProduct();

        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.checkReport = function (InvoiceID) {
        var reportParams = {
            "Parms": { "InvoiceID": InvoiceID },
            "ReportName": "PurchaseReport/ClaimReport.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }

});