﻿angular.module('globalApp')
.controller('AutoTransactionOperationController', function ($scope, $mdToast, $mdDialog, $http, $rootScope, $cookies) {
    // scope variables
    $scope.AutoTransactionOperations = [];
    $scope.AutoTransactionOperation = {};

    // functions to run on start
    getAutoTransactionOperations();

    // md-table variables
    $scope.selected = [];
    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };

    // Auto Transaction Operation functions
    function getAutoTransactionOperations() {
        $http.get('/Accounting/AutoTransactionOperation/getAutoTransactionOperations').success(function (results) {
            $scope.AutoTransactionOperations = results;
            for (var i = 0; i < $scope.AutoTransactionOperations.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.AutoTransactionOperations[i].Name = $scope.AutoTransactionOperations[i].NameAr;
                    $scope.AutoTransactionOperations[i].DefaultNote = $scope.AutoTransactionOperations[i].DefaultNoteAr;
                }
                else {
                    $scope.AutoTransactionOperations[i].Name = $scope.AutoTransactionOperations[i].NameEn;
                    $scope.AutoTransactionOperations[i].DefaultNote = $scope.AutoTransactionOperations[i].DefaultNoteEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.edit = function (selectedModel) {
        $scope.AutoTransactionOperation = selectedModel;
        $scope.showEditDialog();
    };
    $scope.showEditDialog = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/EditAutoTransactionOperation.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })
    };
    $scope.save = function () {
        $http.post('/Accounting/AutoTransactionOperation/saveAutoTransactionOperation', $scope.AutoTransactionOperation).success(function () {
            $scope.cancel();
            $rootScope.$emit("swAlertSave", {});
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.AutoTransactionOperation = {};
        getAutoTransactionOperations();
    };
});