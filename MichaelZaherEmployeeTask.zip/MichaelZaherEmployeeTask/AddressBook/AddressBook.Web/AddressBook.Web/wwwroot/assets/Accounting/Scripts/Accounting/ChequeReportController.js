﻿angular.module('globalApp')
.controller('ChequeReportController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter) {
    
    $scope.model = {};

    if ($scope.model.DateFrom == undefined) {
        //$scope.model.DateFrom = new Date('01/01/1999');
        $scope.model.DateFrom = new Date();
    };

    if ($scope.model.DateTo == undefined) {
        //$scope.model.DateTo = new Date('01/01/2020');
        $scope.model.DateTo = new Date();
    };

    $scope.Branches = [];  
    $scope.Banks = [];
    $scope.BankBranches = [];
    $scope.ChequeStatuses = [];

    getBanks();
    

    $scope.getBranch = function () {
        $http.get('HR/Branch/GetUserBarnches').success(function (results) {
            $scope.Branches = results;
            for (var i = 0; i < $scope.Branches.length; i++) {
                if ($cookies.get('HMS_lang') == 'ar-EG') {
                    $scope.Branches[i].Title = $scope.Branches[i].NameAr;
                }
                else {
                    $scope.Branches[i].Title = $scope.Branches[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    }

    function getBanks() {
        $http.get('/Accounting/Banks/getBanks').success(function (results) {
            $scope.Banks = results;
            for (var i = 0; i < $scope.Banks.length; i++) {
                if ($cookies.get('HMS_lang') == 'ar-EG') {
                    $scope.Banks[i].Name = $scope.Banks[i].NameAr;
                }
                else {
                    $scope.Banks[i].Name = $scope.Banks[i].NameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.getBankBranches = function () {
        if ($scope.model.BankID != undefined) {
            $http.get('/Accounting/BankBranches/getBankBranchesByBankID/' + $scope.model.BankID).success(function (results) {
                $scope.BankBranches = results;
                for (var i = 0; i < $scope.BankBranches.length; i++) {
                    if ($cookies.get('HMS_lang') == 'ar-EG') {
                        $scope.BankBranches[i].Name = $scope.BankBranches[i].NameAr;
                    }
                    else {
                        $scope.BankBranches[i].Name = $scope.BankBranches[i].NameEn;
                    }
                }
                $scope.BranchID = null;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.getChequeStatus = function () {
        $http.get('/Accounting/ChequeRecieve/getChequeStatus').success(function (results) {
            $scope.ChequeStatuses = results;
            for (var i = 0; i < $scope.ChequeStatuses.length; i++) {
                //if ($cookies.get('HMS_lang') == 'ar-EG') {
                $scope.ChequeStatuses[i].Title = $scope.ChequeStatuses[i].NameAr;

                //}
                //else {
                //    $scope.ChequeStatuses[i].Title = $scope.ChequeStatuses[i].NameEn;
                //}
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.getChequeStatus();

    $scope.checkReport = function (model) {

        if ($scope.model.DateFrom == undefined) {
            $scope.model.DateFrom = null;
        }

        if ($scope.model.DateTo == undefined) {
            $scope.model.DateTo = null;
        }        

        //if ($scope.model.Branch != undefined) {
        //    $scope.model.BranchID = $scope.model.Branch.BranchID;
        //    $scope.model.BranchName = $scope.model.Branch.NameAr;
        //}
        //else {
        //    $scope.model.BranchID = $scope.model.StoreBranchID;
        //    $scope.model.BranchName = '';
        //}

        if ($scope.model.Branch == undefined || $scope.model.Branch == 'None') {
            $scope.model.BranchID = 0;
            $scope.model.BranchName = "كل الفروع";
        }
        else {

            if ($scope.model.Branch.BranchID == 'None') {
                $scope.model.BranchID = 0;
            }
            else {
                $scope.model.BranchID = $scope.model.Branch.BankID;
                $scope.model.BranchName = $scope.model.Branch.NameAr;
            }
        }


        if ($scope.model.Bank == undefined || $scope.model.Bank == 'None') {
            $scope.model.BankID = 0;
            $scope.model.BankName = "كل البنوك";
        }
        else {

            if ($scope.model.Bank.BankID == 'None') {
                $scope.model.BankID = 0;
            }
            else {
                $scope.model.BankID = $scope.model.Bank.BankID;
                $scope.model.BankName = $scope.model.Bank.NameAr;
            }
        }


        if ($scope.model.BankBranch == undefined || $scope.model.BankBranch == 'None') {
            $scope.model.BankBranchID = 0;
            $scope.model.BankBranchName = "كل الفروع";
        }
        else {

            if ($scope.model.BankBranch.BankBranchID == 'None') {
                $scope.model.BankBranchID = 0;
            }
            else {
                $scope.model.BankBranchID = $scope.model.BankBranch.BankBranchID;
                $scope.model.BankBranchName = $scope.model.BankBranch.NameAr;
            }
        }


        if ($scope.model.ChequeStatus == undefined || $scope.model.ChequeStatus == 'None') {
            $scope.model.ChequeStatusID = 0;
            $scope.model.ChequeStatusName = "كل الحالات";
        }
        else {

            if ($scope.model.ChequeStatus.ChequeStatusID == 'None') {
                $scope.model.ChequeStatusID = 0;
            }
            else {
                $scope.model.ChequeStatusID = $scope.model.ChequeStatus.ChequeStatusID;
                $scope.model.ChequeStatusName = $scope.model.ChequeStatus.NameAr;
            }
        }


        var 
            reportParams = {
                "Parms": { "DateFrom": $filter('date')(model.DateFrom, "yyyy-MM-dd"), "DateTo": $filter('date')(model.DateTo, "yyyy-MM-dd"), "BranchID": model.BranchID, "BranchName": $scope.model.BranchName, "BankID": model.BankID, "BankName": $scope.model.BankName, "BankBranchID": model.BankBranchID, "BankBranchName": $scope.model.BankBranchName, "ChequeStatusID": model.ChequeStatusID, "ChequeStatusName": $scope.model.ChequeStatusName },
                "ReportName": "ChequeReport.trdx"
        };

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }

    $scope.clearFields = function () {
        $scope.model = {};        
    }

});