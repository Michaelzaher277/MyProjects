﻿
angular.module('globalApp')
    .controller('ChequePayingController', function ($scope, $mdDialog, $http, $rootScope, $cookies) {

        $scope.ChequePayings = [];
        $scope.ChequePaying = {};
        $scope.Currencies = [];
        $scope.Suppliers = [];
        $scope.selected = [];
        $scope.ChequeStatuses = [];
        $scope.Banks = [];
        $scope.BankBranches = [];
        $scope.BankBranchAccounts = [];
        $scope.ChartOfAccounts = [];
        //$scope.ChartOfAccount = { IsGroup: true };
        $scope.ChartOfAccountsFilter = "";
        $scope.Customers = [];
        $scope.AddNew = false;

        getChequePayings();


        ///chart of account
        // ----------------------------- this fuctions transfer to app.js -----------------------------------------
        //function getChartOfAccountTree() {
        //    $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
        //        $scope.ChartOfAccounts = results.treeObj;
        //    }).error(function () {
        //        $rootScope.$emit("swAlertError", {});
        //    });
        //};

        $scope.getAccountingSubPeriod = function () {
            $http.get('HR/EmployeeVacation/getVacationType').success(function (results) {
                $scope.VacationTypes = results;
                for (var i = 0; i < $scope.VacationTypes.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.VacationTypes[i].Title = $scope.VacationTypes[i].NameAr;
                    }
                    else {
                        $scope.VacationTypes[i].Title = $scope.VacationTypes[i].NameEn;
                    }
                }
            }).error(function (data, status, headers, config) {
                $rootScope.$emit("swAlertError", {});
            });
        };    

        $scope.AddNewAutoTransactionSetting = function () {
            $scope.getChartOfAccountTree();
            //if ($scope.ChartOfAccounts.length <= 0) {
            //    $scope.getChartOfAccountTree();
            //}
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
                onRemoving: function () {
                    $scope.cancelChartOfAccountsDialog();
                },
                clickOutsideToClose: true,
                openFrom: '.addButton',
                closeTo: '.addButton'
            });
        }

        function getChartOfAccountTreeDetail() {
            $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
                $scope.ChartOfAccountsDetails = results.treeObj;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };

        $scope.selectNode = function (node) {
            $scope.ChartOfAccount = node.$modelValue;
        }

        $scope.findNodes = function (item) {
            $scope.ChartOfAccountsFilter = item.ChartOfAccountsFilter;
        };

        $scope.chooseChartOfAccount = function () {
            $scope.ChequePaying.ChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
            $scope.ChequePaying.ChartOfAccount_CashNameAr = ($cookies.get('ERP_lang') == 'ar-EG') ? $scope.ChartOfAccount.AccountArabicName : $scope.ChartOfAccount.AccountEnglishName;
            $scope.ChequePaying.AccountCode = $scope.ChartOfAccount.AccountCode;
            $scope.cancelChartOfAccountsDialog();
        };

        $scope.FilterChartOfAccounts = function (item) {
            return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
        };

        $scope.cancelChartOfAccountsDialog = function () {
            $mdDialog.cancel();
            $scope.ChartOfAccount = { IsGroup: true };
            $scope.ChartOfAccountsFilter = "";
        };

        $scope.getCurrency = function (CurrencyID) {
            $http.get('/Currency/getCurrencyByID?id=' + CurrencyID).success(function (data) {
                $scope.ChequePaying.Currency_Convert = data.ConvertValue;
            });
        };

        $scope.showEditDialog = function (obj) {
            $scope.ChequePaying = obj;
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/EditChequePayingStatus.tmpl.html',
                onRemoving: function () {
                    $scope.cancel();
                },
                clickOutsideToClose: true,
                openFrom: '.editButton',
                closeTo: '.editButton'
            })
        };

        function getChequePayings() {
            $http.get('/ChequePaying/getChequePayings').success(function (results) {
                $scope.ChequePayings = results;
                for (var i = 0; i < $scope.ChequePayings.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.ChequePayings[i].Status = $scope.ChequePayings[i].ChequeStatusNameAr;
                    }
                    else {
                        $scope.ChequePayings[i].Status = $scope.ChequePayings[i].ChequeStatusNameEn;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };

        //$scope.getChequeStatus = function () {
        //    $http.get('/Accounting/ChequePaying/getChequeStatus').success(function (results) {
        //        $scope.ChequeStatuses=results;
        //        for (var i = 0; i < $scope.ChequeStatuses.length; i++) {
        //            //if ($cookies.get('ERP_lang') == 'ar-EG') {
        //            $scope.ChequeStatuses[i].Title = $scope.ChequeStatuses[i].NameAr;

        //            //}
        //            //else {
        //            //    $scope.ChequeStatuses[i].Title = $scope.ChequeStatuses[i].NameEn;
        //            //}
        //        }

        //    }).error(function () {
        //        $rootScope.$emit("swAlertError", {});
        //    });
        //};
        $scope.showAdvancedAdd = function (ev) {
            //  $("DivShow)

            $scope.AddNew = true;

            HideMasterShowDetails('#DivShow', '#DivSave');
            $scope.getChartOfAccountTree();
            //   $scope.getChequeStatus();
            //  $scope.ChequeStatuses= $scope.ChequeStatuses.slice(2, 3);
            // $scope.getShipping_Ways();
            //$scope.getAllProductsModal();

        };

        $scope.hide = function () {
            $mdDialog.hide();

            //var x = $scope.ChequePayings.filter(function (obj) {
            //    return obj.ChequeID == $scope.ChequePaying.ChequeID;
            //});

            for (var i = 0; i < $scope.ChequePayings.length; i++) {
                if ($scope.ChequePayings[i].ChequeID == $scope.ChequePaying.ChequeID) {
                    $scope.ChequePayings[i].IsPaying = false;
                    break;
                }
            }

            $scope.ChequePaying = {};
        };

        $scope.cancelChequePaying = function () {
            //   $mdDialog.cancel();

            //$scope.AddNew = false;

            HideMasterShowDetails('#DivSave', '#DivShow');

            $scope.ChequePaying = {};
            $scope.selected = [];
        };


        $scope.answer = function (answer) {
            $mdDialog.hide(answer);
        };

        $scope.savediag = function () {
            $scope.save();
        };

        $scope.saveChequePayingStatus = function () {

            $.ajax({
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify($scope.ChequePaying),
                url: '/ChequePaying/saveChequePaying',
                success: function (result) {

                    getChequePayings();

                    $scope.getAllBankBranchAccounts();

                    //$scope.ChequePaying.BankChartAccountID = $scope.BankBranchAccounts.filter(function (obj) {
                    //    return obj.BankBranchAccountID == $scope.ChequePaying.BankBranchAccountID;
                    //})[0];

                    //var data = {
                    //    Amount: $scope.ChequePaying.Amount,
                    //    AutoTransactionOperationID: 13,
                    //    CurrencyID: $scope.ChequePaying.CurrencyID,
                    //    // FromID: $scope.ChequePaying.ChartOfAccountID,
                    //    FromID: $scope.ChequePaying.BankChartAccountID,
                    //    currencyConvert: $scope.ChequePaying.Currency_Convert,
                    //    //ToID: $scope.ChequePaying.BankChartAccountID,
                    //    // Sales_InvoiceTypeID: $scope.Sales_Invoice.InvoiceTypeID,
                    //    currentDate: $scope.ChequePaying.ChequeDate,
                    //    Note: 'سداد اوراق دفع'
                    //};

                    //recordAutoTransaction(data);

                    //$scope.cancelChequePaying();
                    //$mdDialog.hide();
                    //$rootScope.$emit("swAlertSave", {});
                    //$scope.selected = [];

                },
                error: function () {
                    $rootScope.$emit("swAlertError", {});
                }
            });
        };


        $scope.save = function () {


            if ($scope.ChequePaying.group1 == 1) {
                $scope.ChequePaying.ChartOfAccountID = $scope.ChequePaying.SelectedCustomer.ChartOfAccountID;
                $scope.ChequePaying.CustomerID = $scope.ChequePaying.SelectedCustomer.CustID;
            }
            else if ($scope.ChequePaying.group1 == 2) {
                $scope.ChequePaying.ChartOfAccountID = $scope.ChequePaying.SelectedSupplier.ChartOfAccountID;
                $scope.ChequePaying.SupplierID = $scope.ChequePaying.SelectedSupplier.supplierID;
            }

            $.ajax({
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify($scope.ChequePaying),
                url: '/ChequePaying/saveChequePaying',
                success: function (result) {

                    getChequePayings();

                    if ($scope.ChequePaying.ChequeID == undefined) {

                        //var FromID;
                        //if ($scope.ChequePaying.group1 == 1) {

                        //    FromID = $scope.ChequePaying.CustomerID;
                        //}
                        //else if ($scope.ChequePaying.group1 == 2) {
                        //    FromID = $scope.ChequePaying.SupplierID;

                        //}
                        //else {
                        //    FromID = $scope.ChequePaying.ChartOfAccountID;

                        //}

                        var data = {
                            Amount: $scope.ChequePaying.Amount,
                            AutoTransactionOperationID: 12,
                            CurrencyID: $scope.ChequePaying.CurrencyID,
                            //FromID: $scope.ChequePaying.ChartOfAccountID,
                            ToID: $scope.ChequePaying.ChartOfAccountID,
                            currencyConvert: $scope.ChequePaying.Currency_Convert,
                            //FromID: $scope.Sales_Invoice.CurrencyID.CustomerID,
                            // Sales_InvoiceTypeID: $scope.Sales_Invoice.InvoiceTypeID,
                            currentDate: $scope.ChequePaying.ChequeDate,
                            ChequePayingID: result,
                            Note: 'قيد انشاء اوراق دفع'
                        };

                        recordAutoTransaction(data);
                    }

                    $scope.cancelChequePaying();
                    $rootScope.$emit("swAlertSave", {});


                    $scope.selected = [];
                },
                error: function () {
                    $rootScope.$emit("swAlertError", {});
                }
            });
        };

        function recordAutoTransaction(data) {


            $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction2", data).success(function () {

                //  getSales_Invoices();
                /// HideMasterShowDetails('#divDetails', '#divMain');
                // $scope.clearFields();
                //swAlertSaveAr();
                //var data2 = {
                //    Amount: $scope.ChequePaying.Amount,
                //    AutoTransactionOperationID: 9,
                //    CurrencyID: $scope.ChequePaying.CurrencyID,
                //    currencyConvert:Currency_Convert,
                //    //ToID: scope.ChequePaying.CustomerID,
                //    //FromID: $scope.Sales_Invoice.CurrencyID.CustomerID,
                //    // Sales_InvoiceTypeID: $scope.Sales_Invoice.InvoiceTypeID,
                //    currentDate: $scope.ChequePaying.ChequeDate,
                //    Note: 'قيد  اوراق قبض حافظة الشيكات'
                //};
                //recordAutoTransaction(data2);

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }

        $scope.edit = function (ChequePayingID) {
            $scope.getCurrencies();
            $scope.getBanks();
            $scope.AddNew = false;

            $http.get('/ChequePaying/getChequePayingByID?id=' + ChequePayingID).success(function (data) {

                $scope.ChequePaying = data;

                //$scope.ChequePaying.Currency_Convert = $scope.ChequePaying.CurrencyID;

                $scope.getBankBranches($scope.ChequePaying.BankID);
                $scope.getBankBranchAccounts($scope.ChequePaying.BankBranchID);

                if ($scope.ChequePaying.CustomerID != null) {
                    $scope.loadCustomers();
                    $scope.ChequePaying.group1 = 1
                }
                else if ($scope.ChequePaying.SupplierID != null) {
                    $scope.getSuppliers();
                    $scope.ChequePaying.group1 = 2
                }
                else {
                    $scope.getChartOfAccountTree();
                    $scope.ChequePaying.ChartOfAccount_CashNameAr = $scope.ChequePaying.AccountNameAr;
                    $scope.ChequePaying.group1 = 3
                }

                // $scope.getChequeStatus();
                //if ($scope.ChequePaying.ChequeStatusID==1)
                //$scope.ChequeStatuses.slice(1, 2);


                //$scope.AddNew = true;

                HideMasterShowDetails('#DivShow', '#DivSave');
            });
        };

        $scope.removeFilter = function () {
            $scope.filter.show = false;
            $scope.query.filter = '';

            if ($scope.filter.form.$dirty) {
                $scope.filter.form.$setPristine();
            }
        };

        $scope.limitOptions = [5, 10, 15];
        $scope.options = {
            pageSelect: true
        };
        $scope.query = {
            Invoice: 'name',
            filter: '',
            limit: 5,
            page: 1
        };
        // Begin  drop down lists //
        $scope.getCurrencies = function () {
            $http.get('/Currency/GetCurrencies').success(function (results) {
                $scope.Currencies = results;

                for (var i = 0; i < $scope.Currencies.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                    }
                    else {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                    }
                }
            }).error(function (data, status, headers, config) {
                $rootScope.$emit("swAlertError", {});
            });
        };

        $scope.getSuppliers = function () {
            $http.get('/Administration/Supplier/GetSuppliers').success(function (results) {
                $scope.Suppliers = results;

                for (var i = 0; i < $scope.Suppliers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Suppliers[i].Title = $scope.Suppliers[i].NameAr;
                    }
                    else {
                        $scope.Suppliers[i].Title = $scope.Suppliers[i].NameEng;
                    }

                }
                if ($scope.AddNew === false) {
                    $scope.ChequePaying.SelectedSupplier = $scope.Suppliers.filter(function (obj) {
                        return obj.SupplierID == $scope.ChequePaying.supplierID;
                    })[0];
                }
            }).error(function (data, status, headers, config) {
                $rootScope.$emit("swAlertError", {});
            });
        };


        // Bank Branches Functions
        $scope.getBanks = function () {
            $http.get('/Accounting/Banks/getBanks').success(function (results) {
                $scope.Banks = results;
                for (var i = 0; i < $scope.Banks.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Banks[i].Title = $scope.Banks[i].NameAr;
                    }
                    else {
                        $scope.Banks[i].Title = $scope.Banks[i].NameEn;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };

        $scope.getBankBranches = function (id) {
            if (id != undefined) {
                $http.get('/Accounting/BankBranches/getBankBranchesByBankID/' + id).success(function (results) {
                    $scope.BankBranches = results;
                    for (var i = 0; i < $scope.BankBranches.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.BankBranches[i].Title = $scope.BankBranches[i].NameAr;
                        }
                        else {
                            $scope.BankBranches[i].Title = $scope.BankBranches[i].NameEn;
                        }
                    }
                    $scope.BranchID = null;
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        };

        $scope.getBankBranchAccounts = function (id) {
            if (id != undefined) {
                $http.get('/Accounting/BankBranchAccounts/getBankBranchAccountsByBankBranchID/' + id).success(function (results) {
                    $scope.BankBranchAccounts = results;
                    for (var i = 0; i < $scope.BankBranchAccounts.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameAr;
                        }
                        else {
                            $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameEn;
                        }
                    }
                    $scope.BranchID = null;
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        };

        $scope.getAllBankBranchAccounts = function () {
            $http.get('/Accounting/BankBranchAccounts/getAllBankBranchAccounts/').success(function (results) {

                $scope.BankBranchAccounts = results;

                $scope.ChequePaying.BankBranchAccount = $scope.BankBranchAccounts.filter(function (obj) {
                    return obj.BankBranchAccountID == $scope.ChequePaying.BankBranchAccountID;
                })[0];

                var data = {
                    Amount: $scope.ChequePaying.Amount,
                    AutoTransactionOperationID: 13,
                    CurrencyID: $scope.ChequePaying.CurrencyID,
                    // FromID: $scope.ChequePaying.ChartOfAccountID,
                    FromID: $scope.ChequePaying.BankBranchAccount.ChartOfAccount_Cash,
                    currencyConvert: $scope.ChequePaying.Currency_Convert,
                    //ToID: $scope.ChequePaying.BankChartAccountID,
                    // Sales_InvoiceTypeID: $scope.Sales_Invoice.InvoiceTypeID,
                    //currentDate: $scope.ChequePaying.ChequeDate,
                    currentDate: $scope.ChequePaying.PayDate,
                    Note: 'سداد اوراق دفع'
                };

                recordAutoTransaction(data);

                $scope.cancelChequePaying();
                $mdDialog.hide();
                $rootScope.$emit("swAlertSave", {});
                $scope.selected = [];

                //for (var i = 0; i < $scope.BankBranchAccounts.length; i++) {
                //    if ($cookies.get('ERP_lang') == 'ar-EG') {
                //        $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameAr;
                //    }
                //    else {
                //        $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameEn;
                //    }
                //}

                //$scope.BranchID = null;

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };

        // End Select2 drop down lists //


        $scope.loadCustomers = function () {

            $http.get('/Administration/Customer/GetCustomers').success(function (results) {
                $scope.Customers = results;
                for (var i = 0; i < $scope.Customers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Customers[i].Title = $scope.Customers[i].NameAr;
                    }
                    else {
                        $scope.Customers[i].Title = $scope.Customers[i].NameEng;
                    }
                }
                if ($scope.AddNew === false) {
                    $scope.ChequePaying.SelectedCustomer = $scope.Customers.filter(function (obj) {
                        return obj.CustID == $scope.ChequePaying.CustomerID;
                    })[0];
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });

        };

        $scope.delete = function () {
            $rootScope.$emit("swConfirmDelete",
                {
                    function() {
                        //if (ChequeRecieveID > 0) {
                        $http.post('/Accounting/ChequePaying/deleteChequePaying/', JSON.stringify($scope.selected[0])).success(function () {
                            getChequePayings();
                            $scope.selected = [];
                        }).error(function () {
                            $rootScope.$emit("swAlertError", {});
                        });
                        //}
                    }
                });
        }

    });