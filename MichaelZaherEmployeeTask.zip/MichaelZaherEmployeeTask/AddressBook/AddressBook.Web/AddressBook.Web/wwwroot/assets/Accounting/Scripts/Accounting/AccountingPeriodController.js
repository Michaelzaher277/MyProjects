﻿
angular.module('globalApp')
.controller('AccountingPeriodController', function ($scope, $mdToast, $mdDialog, $http, $rootScope) {

    $scope.AccountingPeriods = [];
    $scope.AccountingPeriod = {};

    $scope.selected = [];


    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };

    getAccountingPeriods();



    function getAccountingPeriods() {
        $http.get('/Accounting/AccountingPeriod/getAccountingPeriods').success(function (results) {
            $scope.AccountingPeriods = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/AccountingPeriod.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/AccountingPeriod.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.AccountingPeriod = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.AccountingPeriod = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.AccountingPeriod),
            url: '/Accounting/AccountingPeriod/saveAccountingPeriod',
            success: function () {
                getAccountingPeriods();
                $scope.cancel();
                //swAlertSave();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };



    $scope.edit = function (AccountingPeriodID) {
        $http.get('/Accounting/AccountingPeriod/getAccountingPeriodByID/' + AccountingPeriodID).success(function (data) {
            $scope.AccountingPeriod = data;
            $scope.showAdvancedEdit();
        });
    };

    //New md Table



    //$scope.delete = function () {
    //    $rootScope.$emit("swConfirmDelete", 
    //        {
    //            function () {
    //                $http.post('/Gender/deleteGender', JSON.stringify($scope.selected)).success(function () {
    //                    getGenders();
    //                    $scope.selected = [];
    //                });

    //            }
    //        });
    //    //swConfirmDeleteEn(function () {
    //    //    $http.post('/Gender/deleteGender', JSON.stringify($scope.selected)).success(function () {
    //    //        getGenders();
    //    //        $scope.selected = [];
    //    //    });
    //    //});
    //}


    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Accounting/AccountingPeriod/deleteAccountingPeriod', JSON.stringify($scope.selected)).success(function () {
                       getAccountingPeriods();
                       $scope.selected = [];
                   });
               }
           });
    }



    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
});