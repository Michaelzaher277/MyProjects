﻿angular.module('globalApp')
.controller('Sales_InvoiceController', function ($scope, $mdToast, $mdDialog, $http, $rootScope, $element, $cookies, $filter) {

    $scope.Sales_Invoices = [];
    $scope.Sales_Invoice = {};

    $scope.Sales_InvoiceDetails = [];
    $scope.Sales_InvoiceDetail = {};

    $scope.Sales_InvoicePayments = [];
    $scope.Sales_InvoicePayment = {};
    $scope.Sales_InvoicePaymentID = '';

    $scope.SalesPaymentReceipts = [];
    $scope.SalesPaymentReceipt = {};

    $scope.SalesPaymentReceiptsDetails = [];
    $scope.SalesPaymentReceiptsDetail = {};

    $scope.SellInvoices = [];
    $scope.invoiceDetails = [];
    $scope.InvoiceStatuses = [];

    $scope.Parts = [];
    $scope.Customers = [];
    $scope.InvoiceTypes = [];
    $scope.PaymentTypes = [];
    $scope.Currencies = [];
    $scope.MeasureUnits = [];
    $scope.JobOrderDetails = [];
    $scope.JOFinalIndexaion = [];
    $scope.JOExtraWorks = [];
    $scope.JOWorkDone = [];


    $scope.Invoiceselected = [];
    $scope.InvoiceDetailSelected = [];
    $scope.InvoicePaymentSelected = [];

    $scope.selectedProduct = [];
    $scope.selectedJobOrder = [];
    $scope.selectedSellInvoice = [];

    $scope.searchTerm = '';
    $scope.clearSearchTerm = function () {
        $scope.searchTerm = '';
    };

    $scope.Sum = {};
    $scope.Sum.TotalQuantity = '0';
    $scope.Sum.Price = '0';
    $scope.Sum.Discount = '0';
    $scope.Sum.TotalPrice = '0';
    $scope.Sum.Taxes = '0';
    $scope.Sum.TaxesDiscount = '0';
    $scope.Sum.NetTotalPrice = '0';   
   
    $scope.Sum.Amount = 0;   
    $scope.Sum.TotalCost = 0;
    $scope.Sum.TotalInvoice = 0;

    $scope.Setting = {};

    $scope.parseInt = parseInt;

    getSales_Invoices();
    getInvoiceTypes();
    getInvoiceStatuses();
    getInvoicePayments();
    getJobOrders();

  //  getSellInvoices();
    //getCustomers();
    
    getCurrencies();

    $scope.getSetting = function () {
        $http.get('/AccountingSettings/getAccountingSettings').success(function (results) {
            $scope.Setting = results;
        })
    };

    $scope.getSetting();

    $scope.clearFields = function () {
        HideMasterShowDetails('#divDetails', '#divMain');
        $scope.Sales_Invoice = {};
        $scope.Sales_InvoiceDetails = [];
        $scope.Sales_InvoicePayments = [];
        $scope.edit.show = false;
    };

   


    $scope.GetLastCodeInvoices = function (id) {
        if (id == 1) {
            $http.get('/Sales_Invoice/GetLastCodeInvoicesCash').success(function (results) {
                $scope.Sales_Invoice.InvoiceCode = results;
                //var today = $filter('date')(new Date(), 'yyyy-MM-dd');
                $scope.Sales_Invoice.InvoiceDate = new Date();;
            }).error(function (data, status, headers, config) {
                swAlertErrorAr();
            });
        }
        else {

            $http.get('/Sales_Invoice/GetLastCodeInvoicesNotCash').success(function (results) {
                $scope.Sales_Invoice.InvoiceCode = results;
                //var today = $filter('date')(new Date(), 'yyyy-MM-dd');
                $scope.Sales_Invoice.InvoiceDate = new Date();;
            }).error(function (data, status, headers, config) {
                swAlertErrorAr();
            });
        }
    };

    $scope.showAdvancedAdd = function (ev) {       
        HideMasterShowDetails('#divMain', '#divDetails');
        //getInvoiceTypes();
      
        //getLastCodeInvoices();

        $scope.TotalQuantity = 0;
        $scope.Amount = 0;
        $scope.Discount = 0;
        $scope.Taxes = 0;
        $scope.TaxesDiscount = 0;
    };

    //Reports
    $scope.checkReport = function (model) {
        var reportParams = {
            "Parms": { "InvoiceID": model.InvoiceID },
            "ReportName": "Sales_InvoiceReport.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }


    // Begin Select2 drop down lists //

    function getInvoiceTypes() {
        $http.get('/Sales_InvoiceType/getSales_InvoiceTypes').success(function (results) {
            $scope.InvoiceTypes = results;
            for (var i = 0; i < $scope.InvoiceTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameAr;
                }
                else {
                    $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameEn;
                }
            }

        }).error(function () {
            swAlertErrorAr();
        });
    };

    function getInvoiceStatuses() {
        $http.get('/Sales_Invoice/getInvoiceStatuses').success(function (results) {
            $scope.InvoiceStatuses = results;
            for (var i = 0; i < $scope.InvoiceStatuses.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.InvoiceStatuses[i].Title = $scope.InvoiceStatuses[i].NameAr;
                }
                else {
                    $scope.InvoiceStatuses[i].Title = $scope.InvoiceStatuses[i].NameEn;
                }
            }

        }).error(function () {
            swAlertErrorAr();
        });
    }

    function getInvoicePayments() {
        $http.get('/Sales_Invoice/getPaymentTypes').success(function (results) {
            $scope.PaymentTypes = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };


    function getCurrencies() {
        $http.get('/Purchase_Invoice/getAllCurrencies').success(function (results) {
            $scope.Currencies = results;
            for (var i = 0; i < $scope.Currencies.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                }
                else {
                    $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                }
            }
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.getCurrency = function (CurrencyID) {
        $http.get('/Currency/getCurrencyByID?id=' + CurrencyID).success(function (data) {
            $scope.Sales_Invoice.Currency_Convert = data.ConvertValue;
        });
    };

    $scope.getMeasureUnits = function (viewValue) {
        var params = { id: viewValue };
        return $http.get('/Purchases_Invoice/BindMeasureUnit', { params: params })
       .then(function (res) {
           $scope.MeasureUnits = res.data;
       });
    };

    //$scope.getParts = function (viewValue) {
    //    var params = { id: viewValue };
    //    return $http.get('/MaintenaceProgram/BindSparePartsByName', { params: params })
    //    .then(function (res) {
    //        $scope.Parts = res.data;
    //    });
    //};




    $scope.SearchMeasureUnits = function ($event, filterMeasureUnit, item) {
        $event.stopPropagation();
        $http.get('/Purchases_Invoice/BindMeasureUnit/' + filterMeasureUnit).success(function (results) {
            item.MeasureUnits = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.SearchParts = function ($event, filterText, item) {
        $event.stopPropagation();
        $http.get('/MaintenaceProgram/BindSparePartsByName/' + filterText).success(function (results) {
            item.Parts = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $element.find('input#searchCustomers').on('keydown', function (ev) {
        ev.stopPropagation();
    });

    $scope.loadCustomers = function () {
        if ($scope.Customers.length <= 0) {
            $http.get('/Administration/Customer/GetCustomers').success(function (results) {
                $scope.Customers = results;

                for (var i = 0; i < $scope.Customers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Customers[i].Title = $scope.Customers[i].NameAr;
                    }
                    else {
                        $scope.Customers[i].Title = $scope.Customers[i].NameEng;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.loadCustomers();

    //$scope.getCustomers = function (viewValue) {
    //    if (viewValue != '') {
    //        var params = { id: viewValue };
    //        return $http.get('/JobOrder/getCustomerByName/', { params: params })
    //        .then(function (res) {
    //            $scope.Customers = res.data;
    //        });
    //    }
    //};
    //function getCustomers() {
    //    $http.get('/JobOrder/getAllCustomers').success(function (results) {
    //        $scope.Customers = results;
    //    }).error(function () {
    //        swAlertErrorAr();
    //    });
    //};

    // onSelect Functions //


    // End Select2 drop down lists //

    function getJobOrders() {
        $http.get('/JobOrder/JobOrder/GetALLJobOrder').success(function (results) {
            $scope.JobOrderDetails = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    function getSales_Invoices() {
        $http.get('/Sales_Invoice/getInvoices').success(function (results) {
            $scope.Sales_Invoices = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.savePaymentReceipt = function () {
        $scope.SalesPaymentReceipt.SalesPaymentReceiptsDetails = $scope.SalesPaymentReceiptsDetails;

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.SalesPaymentReceipt),
            url: '/Sales_Invoice/SavePaymentReceipt',
            success: function () {
                swAlertSaveAr();
            },
            error: function () {
                swAlertErrorAr();
            }
        });
    };

    $scope.save = function () {
        $scope.Sales_Invoice.Sales_InvoiceDetail = $scope.Sales_InvoiceDetails;
        $scope.Sales_Invoice.Sales_InvoicePayment = $scope.Sales_InvoicePayments;

        //if ($scope.Sales_Invoice.SelectedCurrency != undefined) {
        //    $scope.Sales_Invoice.CurrencyID = $scope.Sales_Invoice.SelectedCurrency.CurrencyID;
        //    $scope.Sales_Invoice.Currency_Convert = $scope.Sales_Invoice.SelectedCurrency.ConvertValue;
        //}

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Sales_Invoice),
            url: '/Sales_Invoice/saveInvoice',
            success: function (result) {

                $scope.saveAutoTransaction(result);

                if ($scope.Sales_Invoice.InvoiceTypeID = 1) {
                    $scope.savePaymentCash(result);
                }
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.saveAutoTransaction = function (SalesInvoiceID) {
        var totalAmount;
        var Note;

        $http.get("/accounting/Sales_Invoice/getInvoiceTotalAmountByInvoiceID/" + SalesInvoiceID).success(function (result) {
            totalAmount = result;
            getNote(SalesInvoiceID);
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });

        function getNote(SalesInvoiceID) {
            $http.get("/accounting/Sales_Invoice/getCurrentNoteBySalesInvoiceID/" + SalesInvoiceID).success(function (result) {
                Note = result;
                recordAutoTransaction();
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }

        function recordAutoTransaction() {
            // get Customer Chart Of Account [not implemented yet]
            var data = {
                Amount: totalAmount,
                AutoTransactionOperationID: 1,
                CurrencyID: $scope.Sales_Invoice.CurrencyID,
                //FromID: $scope.Sales_Invoice.CurrencyID.CustomerID,
                Sales_InvoiceTypeID: $scope.Sales_Invoice.InvoiceTypeID,
                currentDate: $scope.Sales_Invoice.InvoiceDate,
                Note: Note
            };
            $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction", data).success(function () {
                getSales_Invoices();
                HideMasterShowDetails('#divDetails', '#divMain');
                $scope.clearFields();
                swAlertSaveAr();
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    }

    $scope.edit = function (model) {
        $scope.Sales_Invoice = model
        getInvoiceDetailsByInvoiceID(model.InvoiceID);
        getInvoicePaymentsByInvoiceID(model.InvoiceID);
        HideMasterShowDetails('#divMain', '#divDetails');

        getCurrencies();

        //if ($scope.Sales_Invoice.CurrencyID != undefined) {

        //    getCurrency($scope.Sales_Invoice.CurrencyID);
        //}

        setTimeout(function () {
            $scope.getTotalQuantity();
            $scope.getPrice();
            $scope.getDiscount();
            $scope.getTotalPrice();
            $scope.getTaxes();
            $scope.getTaxesDiscount();
            $scope.getNetTotalPrice();

        }, 1000)

    };

    $scope.loadDetailsFrom = function (JobOrder) {
        $http.get('/accounting/Sales_Invoice/getJobOrderPartsByID/' + JobOrder.JobOrderID).success(function (results) {
            $scope.JOWorkDone = results;
            addDetailsWorkDoneInInvoice();
            $scope.Sales_Invoice.JobOrderCode = JobOrder.JobOrderNumber;
            $scope.Sales_Invoice.JobOrderID = JobOrder.JobOrderID;
        }).error(function () {
            swAlertErrorAr();
        });
        $scope.hide();
    }

    $scope.loadDetailsFromSellInvoice = function (SellInvoice) {
        $http.get('/InvoiceBuy/getInvoiceDetailsByInvoiceID/' + SellInvoice.InvoiceID).success(function (results) {
            $scope.invoiceDetails = results;
            addDetailsSellInvoiceInInvoice();
            $scope.Sales_Invoice.BarCode = SellInvoice.BarCode;
        }).error(function () {
            swAlertErrorAr();
        });
        $scope.hide();
    }

    function addDetailsWorkDoneInInvoice() {
        for (i = 0; i < $scope.JOWorkDone.length; i++) {

            //if ($scope.JOWorkDone[i].PartID != null) {
            //    $scope.Sales_InvoiceDetails.push({
            //        IsPart: true,
            //        Quantity: $scope.JOWorkDone[i].Quantity,
            //        PartID: $scope.JOWorkDone[i].PartID,
            //        ProductName: $scope.JOWorkDone[i].WorkDoneText,
            //        DisplayName: $scope.JOWorkDone[i].WorkDoneText,
            //        PartName: $scope.JOWorkDone[i].WorkDoneText,
            //        Notes: $scope.JOWorkDone[i].Notes,
            //        Amount: $scope.JOWorkDone[i].Price
            //    });
            //}
            //else {
            //    $scope.Sales_InvoiceDetails.push({
            //        ProductName: $scope.JOWorkDone[i].WorkDoneText,
            //        DisplayName: $scope.JOWorkDone[i].WorkDoneText,
            //        Notes: $scope.JOWorkDone[i].Notes,
            //        Amount: $scope.JOWorkDone[i].Price

            //    });
            //}

            if ($scope.JOWorkDone[i].SparePartID != null) {
                var item = {};
                item.PartID = $scope.JOWorkDone[i].SparePartID;
                item.ProductName = $scope.JOWorkDone[i].PartName;
                item.ProductCode = $scope.JOWorkDone[i].PartCode;

                //item.MeasureUnits = JOWorkDone[i].MeasureUnits;

                //for (var j = 0; j < item.MeasureUnits.length; j++) {
                //    if ($cookies.get('ERP_lang') == 'ar-EG') {
                //        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                //    }
                //    else {
                //        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                //    }
                //}

                if ($scope.Setting != undefined) {
                    item.Taxes = $scope.Setting.SalesInvoiceTaxAmount;
                    item.TaxesDiscount = $scope.Setting.SalesDiscountInvoiceAmount;
                }
                else {
                    $scope.getSetting();
                    if ($scope.Setting != undefined) {
                        item.Taxes = $scope.Setting.SalesInvoiceTaxAmount;
                        item.TaxesDiscount = $scope.Setting.SalesDiscountInvoiceAmount;
                    }
                }

                var foundItem = $filter('filter')($scope.Sales_InvoiceDetails, { ProductCode: $scope.JOWorkDone.PartCode }, true)[0];

                if (foundItem == undefined) {
                    $scope.Sales_InvoiceDetails.push(item);
                }                

            }

        };

        $scope.getTotalQuantity();
        $scope.getPrice();
        $scope.getDiscount();
        $scope.getTotalPrice();
        $scope.getTaxes();
        $scope.getTaxesDiscount();
        $scope.getNetTotalPrice();
    }

    function addDetailsSellInvoiceInInvoice() {

        for (i = 0; i < $scope.invoiceDetails.length; i++) {
            if ($scope.invoiceDetails[i].ProductID != null) {
                $scope.Sales_InvoiceDetails.push({
                    IsPart: true,
                    Quantity: $scope.invoiceDetails[i].Quantity,
                    PartID: $scope.invoiceDetails[i].ProductID,
                    PartName: $scope.invoiceDetails[i].ProductName,
                    ProductName: $scope.invoiceDetails[i].ProductName,
                    DisplayName: $scope.invoiceDetails[i].ProductName,
                    InvoiceDetailCode: $scope.invoiceDetails[i].ProductCode,
                    ProductCode: $scope.invoiceDetails[i].ProductCode,
                    MeasureUnitID: $scope.invoiceDetails[i].MeasureID
                });
            }
        };

        $scope.getTotalQuantity();
        $scope.getPrice();
        $scope.getDiscount();
        $scope.getTotalPrice();
        $scope.getTaxes();
        $scope.getTaxesDiscount();
        $scope.getNetTotalPrice();
    }

    function addDetailsIndexationInInvoice() {
        for (i = 0; i < $scope.JOFinalIndexaion.IndexationDetails.length; i++) {
            if ($scope.JOFinalIndexaion.IndexationDetails[i].IsPart) {
                $scope.Sales_InvoiceDetails.push({
                    IsPart: true,
                    Quantity: $scope.JOFinalIndexaion.IndexationDetails[i].Quantity,
                    PartID: $scope.JOFinalIndexaion.IndexationDetails[i].PartID,
                    PartName: $scope.JOFinalIndexaion.IndexationDetails[i].PartName,
                    Notes: $scope.JOFinalIndexaion.IndexationDetails[i].IssueDescription
                });
            }
            else {
                $scope.Sales_InvoiceDetails.push({
                    Description: $scope.JOFinalIndexaion.IndexationDetails[i].WorkPoints,
                    Notes: $scope.JOFinalIndexaion.IndexationDetails[i].IssueDescription
                });
            }
        };

        $scope.getTotalQuantity();
        $scope.getPrice();
        $scope.getDiscount();
        $scope.getTotalPrice();
        $scope.getTaxes();
        $scope.getTaxesDiscount();
        $scope.getNetTotalPrice();
    }

    function addDetailsExtraWorksInInvoice() {
        for (i = 0; i < $scope.JOExtraWorks.length; i++) {
            $scope.Sales_InvoiceDetails.push({
                Notes: $scope.JOExtraWorks[i].Description
            });
        };
    }

    function getInvoiceDetailsByInvoiceID(InvoiceID) {
        $http.get('/Sales_Invoice/getInvoiceDetailsByInvoiceID/' + InvoiceID).success(function (results) {

            //for (var i = 0; i < results.length; i++) {
            //    results[i].Parts = [];
            //    results[i].Parts.push(results[i].Product);
            //    results[i].MeasureUnits = [];
            //    results[i].MeasureUnits.push(results[i].MeasureUnit);
            //}

            $scope.Sales_InvoiceDetails = results;

            for (var i = 0; i < $scope.Sales_InvoiceDetails.length; i++) {
                $scope.getMeasureUnit($scope.Sales_InvoiceDetails[i].PartID);
                $scope.Sales_InvoiceDetails[i].MeasureUnits = $scope.MeasureUnits;
                $scope.getRowPrices($scope.Sales_InvoiceDetails[i]);
            }

            $scope.TotalQuantity = 0;
            $scope.Amount = 0;
            $scope.Discount = 0;
            $scope.Taxes = 0;
            $scope.TaxesDiscount = 0;

            $.each($scope.Sales_InvoiceDetails, function (i, item) {

                if (!isNaN(parseFloat(item.Quantity))) {
                    $scope.TotalQuantity += parseFloat(item.Quantity);
                }

                if (!isNaN(parseFloat(item.Amount))) {
                    $scope.Amount += parseFloat(item.Amount);
                }

                if (!isNaN(parseFloat(item.Discount))) {
                    $scope.Discount += parseFloat(item.Discount);
                }

                if (!isNaN(parseFloat(item.Taxes))) {
                    $scope.Taxes += parseFloat(item.Taxes);
                }

                if (!isNaN(parseFloat(item.TaxesDiscount))) {
                    $scope.TaxesDiscount += parseFloat(item.TaxesDiscount);
                }

            });

            //$scope.getInvoiceTypes();
            //$scope.getTotalQuantity();
            //$scope.getPrice();
            //$scope.getTaxes();
            //$scope.getDiscount();
            //$scope.getTaxesDiscount();

        }).error(function () {
            swAlertErrorAr();
        });
    }

    $scope.getMeasureUnit = function (productID) {
        $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
            $scope.MeasureUnits = results;
            for (var i = 0; i < $scope.MeasureUnits.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
                }
                else {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEn;
                }
            }


            for (var i = 0; i < $scope.Sales_InvoiceDetails.length; i++) {
                if ($scope.Sales_InvoiceDetails[i].PartID == productID)
                    $scope.Sales_InvoiceDetails[i].MeasureUnits = $scope.MeasureUnits;
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function getInvoicePaymentsByInvoiceID(InvoiceID) {
        $http.get('/Sales_Invoice/getInvoicePaymentsByInvoiceID/' + InvoiceID).success(function (results) {
            $scope.Sales_InvoicePayments = results;
        }).error(function () {
            swAlertErrorAr();
        });
    }

    function getSellInvoices() {
        $http.get('/Inventory/InvoiceSell/getInvoices').success(function (results) {
            $scope.SellInvoices = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    //$scope.delete = function (id) {
    //    swConfirmDeleteAr(function () {
    //        $http.get('/Sales_Invoice/deleteInvoice/' + id).success(function (results) {
    //            getSales_Invoices();
    //        });
    //    })
    //}

    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Accounting/Sales_Invoice/deleteInvoice', JSON.stringify($scope.Invoiceselected)).success(function () {
                       getSales_Invoices();
                       $scope.Invoiceselected = [];
                   });
               }
           });
    }

    $scope.deleteDetail = function (model) {
        if (model.InvoiceDetailID != undefined) {
            $rootScope.$emit("swAlertSorry", {});
            //$scope.Sales_InvoiceDetails.splice($.inArray(model, $scope.Sales_InvoiceDetails), 1);
        }
        else {
            $rootScope.$emit("swConfirmDelete",
              {
                  function () {
                      $http.post('/Accounting/Sales_Invoice/deleteInvoiceDetail', JSON.stringify($scope.InvoiceDetailSelected)).success(function () {
                          $scope.Sales_InvoiceDetails.splice($.inArray(model, $scope.Sales_InvoiceDetails), 1);
                          $scope.$apply();
                          $scope.getTotalQuantity();
                          $scope.getPrice();
                          $scope.getDiscount();
                          $scope.getTotalPrice();
                          $scope.getTaxes();
                          $scope.getTaxesDiscount();
                          $scope.getNetTotalPrice();
                      });

                      $scope.InvoiceDetailSelected = [];
                  }
              });
        }

    }

    $scope.deletePayment = function (model) {
        if (model.InvoicePaymentID != 0) {
            $rootScope.$emit("swAlertSorry", {});

        }
        else {
            $rootScope.$emit("swConfirmDelete",
              {
                  function () {
                      //$http.post('/Accounting/Sales_Invoice/deleteInvoicePayment', JSON.stringify($scope.InvoicePaymentSelected)).success(function () {
                      $scope.Sales_InvoicePayments.splice($.inArray(model, $scope.Sales_InvoicePayments), 1);
                      $scope.$apply();

                      $scope.InvoicePaymentSelected = [];
                      getInvoicePayments();

                      //});
                  }
              });
        }

    }


    //$scope.AddInvoiceDetail = function () {
    //    $scope.Sales_InvoiceDetails.push({ IsPart: 0 });
    //    setTimeout(function () {
    //        $('.invoiceDetailCode').last().focus();
    //    }, 300);
    //}

    $scope.showProductsAdd = function (ev) {
        //  $("DivShow)
        //   $scope.Purchase_InvoiceDetails.push({});
        //  $scope.getAllProductsModal();

        $scope.GetTopAvailableProducts("");

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadAvailableProducts.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addProduct',
            closeTo: '.addProduct'
        })

    };

    $scope.getProductModal = function (modal) {

        for (i = 0; i < modal.length; i++) {
            if (modal[i].ProductID != null) {
                var item = {};
                item.PartID = modal[i].ProductID;
                item.ProductName = modal[i].NameAr;
                item.ProductCode = modal[i].Code;
                item.MeasureUnits = modal[i].MeasureUnits;

                for (var j = 0; j < item.MeasureUnits.length; j++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                    }
                    else {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                    }
                }

                if ($scope.Setting != undefined) {
                    item.Taxes = $scope.Setting.SalesInvoiceTaxAmount;
                    item.TaxesDiscount = $scope.Setting.SalesDiscountInvoiceAmount;
                }
                else {
                    $scope.getSetting();
                    if ($scope.Setting != undefined) {
                        item.Taxes = $scope.Setting.SalesInvoiceTaxAmount;
                        item.TaxesDiscount = $scope.Setting.SalesDiscountInvoiceAmount;
                    }
                }

                var foundItem = $filter('filter')($scope.Sales_InvoiceDetails, { ProductCode: modal[i].Code }, true)[0];

                if (foundItem == undefined) {
                    $scope.Sales_InvoiceDetails.push(item);
                }

                //$scope.Sales_InvoiceDetails.push(item);

            }
        }

        $scope.Invoiceselected = [];
        $scope.InvoiceDetailSelected = [];
        $scope.InvoicePaymentSelected = [];
        $scope.selectedProduct = [];
        $scope.selectedJobOrder = [];
        $scope.selectedSellInvoice = [];

        //$scope.cancelProduct();

        // $('#DivParts').modal('toggle');

    };

    $scope.cancelProduct = function () {        

        $mdDialog.cancel();

        $scope.Invoiceselected = [];
        $scope.InvoiceDetailSelected = [];
        $scope.InvoicePaymentSelected = [];
        $scope.selectedProduct = [];
        $scope.selectedJobOrder = [];
        $scope.selectedSellInvoice = [];
    };

    $scope.AddInvoicePayment = function () {
        $scope.Sales_InvoicePayments.push({ InvoicePaymentID: 0 });
        setTimeout(function () {
            $('.invoicePaymentAmount').last().focus();
        }, 300)
    }

    $scope.AddPaymentReceipt = function (PaymentID) {
        $scope.SalesPaymentReceiptsDetails = [{
            InvoicePaymentID: PaymentID
        }];
    }

    $scope.AddInvoiceDetailEnter = function (keyEvent) {
        if (keyEvent.which === 13) {
            keyEvent.preventDefault();
            $scope.AddInvoiceDetail();
        }
    }

    $scope.AddInvoicePaymentEnter = function (keyEvent) {
        if (keyEvent.which === 13) {
            keyEvent.preventDefault();
            $scope.AddInvoicePayment();
        }
    }

    $scope.getTotalQuantity = function () {
        //var total = 0;
        //for (var i = 0; i < $scope.Sales_InvoiceDetails.length; i++) {
        //    var item = $scope.Sales_InvoiceDetails[i];
        //    if (item.Quantity != undefined) {
        //        total += item.Quantity;
        //    }
        //}

        //$scope.Sum.TotalQuantity = total.toString();

        $scope.Sum.TotalQuantity = 0;
        $.each($scope.Sales_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Quantity))) {
                $scope.Sum.TotalQuantity += parseFloat(item.Quantity);
            }
        });
    }

    $scope.getPrice = function () {
        //var total = 0;
        //for (var i = 0; i < $scope.Sales_InvoiceDetails.length; i++) {
        //    var item = $scope.Sales_InvoiceDetails[i];
        //    if (item.Amount != undefined) {
        //        total += item.Amount;
        //    }
        //}

        //$scope.Sum.Price = total.toString();

        $scope.Sum.Amount = 0;

        $.each($scope.Sales_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Amount))) {
                $scope.Sum.Amount += parseFloat(item.Amount);
            }
        });
    }

    $scope.getDiscount = function () {
        //var total = 0;
        //for (var i = 0; i < $scope.Sales_InvoiceDetails.length; i++) {
        //    var item = $scope.Sales_InvoiceDetails[i];
        //    if (item.Discount != undefined) {
        //        total += item.Discount;
        //    }
        //}

        //$scope.Sum.Discount = total.toString();

        $scope.Sum.Discount = 0;

        $.each($scope.Sales_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Discount))) {
                $scope.Sum.Discount += parseFloat(item.Discount);
            }
        });
    }

    $scope.getTotalPrice = function () {
        var total = 0;
        for (var i = 0; i < $scope.Sales_InvoiceDetails.length; i++) {
            var item = $scope.Sales_InvoiceDetails[i];
            if (item.TotalPrice != undefined) {
                total +=parseFloat( item.TotalPrice);
            }
        }
        $scope.Sum.TotalPrice = total.toString();
    }

    $scope.getTaxes = function () {
        //var total = 0;
        //for (var i = 0; i < $scope.Sales_InvoiceDetails.length; i++) {
        //    var item = $scope.Sales_InvoiceDetails[i];
        //    if (item.Taxes != undefined) {
        //        total += item.Taxes;
        //    }
        //}

        //$scope.Sum.Taxes = total.toString();

        $scope.Sum.Taxes = 0;

        $.each($scope.Sales_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Taxes))) {
                $scope.Sum.Taxes += parseFloat(item.Taxes);
            }
        });
    }

    $scope.getTaxesDiscount = function () {
        //var total = 0;
        //for (var i = 0; i < $scope.Sales_InvoiceDetails.length; i++) {
        //    var item = $scope.Sales_InvoiceDetails[i];
        //    if (item.TaxesDiscount != undefined) {
        //        total += item.TaxesDiscount;
        //    }
        //}

        //$scope.Sum.TaxesDiscount = total.toString();

        $scope.Sum.TaxesDiscount = 0;
        $.each($scope.Sales_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.TaxesDiscount))) {
                $scope.Sum.TaxesDiscount += parseFloat(item.TaxesDiscount);
            }
        });
    }

    $scope.getNetTotalPrice = function () {
        var total = 0;
        for (var i = 0; i < $scope.Sales_InvoiceDetails.length; i++) {
            var item = $scope.Sales_InvoiceDetails[i];
            if (item.NetTotalPrice != undefined) {
                total += item.NetTotalPrice;
            }
        }
        $scope.Sum.NetTotalPrice = total.toString();
    }

    $scope.getRowPrices = function (item) {
        var Quantity = 0;
        var Price = 0;
        var Discount = 0;
        var Taxes = 0;
        var TaxesDiscount = 0;
        var TotalQuantityFromChild = 1;
        if (item.TotalQuantityFromChild != undefined)
            TotalQuantityFromChild = item.TotalQuantityFromChild

        if (item.Quantity != undefined)
            Quantity = item.Quantity * TotalQuantityFromChild;
        else
            Quantity = 0;

        if (item.Amount != undefined)
            Price = item.Amount;
        else
            Price = 0;

        if (item.Discount != undefined)
            Discount = ((Quantity * Price) * item.Discount) / 100;
        else
            Discount = 0;

        if (item.Taxes != undefined)
            Taxes = ((Quantity * Price) * item.Taxes) / 100;
        else
            Taxes = 0;

        if (item.TaxesDiscount != undefined)
            TaxesDiscount = ((Quantity * Price) * item.TaxesDiscount) / 100;
        else
            TaxesDiscount = 0;

        item.TotalPrice = ((Quantity * Price) + Taxes - TaxesDiscount - Discount).toString();
        $scope.getTotalPrice();
    }

    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;

        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };



    $scope.queryDetails = {
        orderDetails: 'name',
        filterDetails: '',
        limitDetails: 5,
        pageDetails: 1
    };
    $scope.removeFilterDetails = function () {
        $scope.filterDetails.show = false;

        $scope.queryDetails.filterDetails = '';

        if ($scope.filterDetails.form.$dirty) {
            $scope.filterDetails.form.$setPristine();
        }
    };
    $scope.limitOptionsDetails = [5, 10, 15];
    $scope.optionsDetails = {
        pageSelectDetails: true
    };



    $scope.queryInvoice = {
        orderInvoice: 'name',
        filterInvoice: '',
        limitInvoice: 5,
        pageInvoice: 1
    };
    $scope.removeFilterInvoice = function () {
        $scope.filterInvoice.show = false;

        $scope.queryInvoice.filterInvoice = '';

        if ($scope.filterInvoice.form.$dirty) {
            $scope.filterInvoice.form.$setPristine();
        }
    };
    $scope.limitOptionsInvoice = [5, 10, 15];
    $scope.optionsInvoice = {
        pageSelectInvoice: true
    };



    $scope.queryJobOrder = {
        orderJobOrder: 'name',
        filterJobOrder: '',
        limitJobOrder: 5,
        pageJobOrder: 1
    };
    $scope.removeFilterJobOrder = function () {
        $scope.filterJobOrder.show = false;

        $scope.queryJobOrder.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
    $scope.limitOptionsJobOrder = [5, 10, 15];
    $scope.optionsJobOrder = {
        pageSelectJobOrder: true
    };


    $scope.showAdvancedAddJobOrder = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Sales_InvoiceLoadJobOrders.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };





    $scope.hide = function () {
        $mdDialog.hide();

    };

    $scope.cancel = function () {
        $mdDialog.cancel();

        $scope.Invoiceselected = [];
        $scope.InvoiceDetailSelected = [];
        $scope.InvoicePaymentSelected = [];
        $scope.selectedProduct = [];
        $scope.selectedJobOrder = [];
    };


    $scope.querySellInvoice = {
        orderSellInvoice: 'name',
        filterSellInvoice: '',
        limitSellInvoice: 5,
        pageSellInvoice: 1
    };
    $scope.removeFilterSellInvoice = function () {
        $scope.filterSellInvoice.show = false;

        $scope.querySellInvoice.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
    $scope.limitOptionsSellInvoice = [5, 10, 15];
    $scope.optionsSellInvoice = {
        pageSelectSellInvoice: true
    };


    $scope.showAdvancedAddSellInvoice = function (ev) {
        getSellInvoices();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Sales_InvoiceLoadSellInvoices.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };

    $scope.cancelSellInvoice = function () {
        $mdDialog.cancel();

        //$scope.Invoiceselected = [];
        //$scope.InvoiceDetailSelected = [];
        //$scope.InvoicePaymentSelected = [];
        //$scope.selectedProduct = [];

        $scope.selectedSellInvoice = [];
    };

    $scope.showPaymentDialog = function () {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Sales_InvoiceAddPayment.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.AddPaymentButton',
            closeTo: '.AddPaymentButton'
        })
    }

    //$scope.cancel = function () {
    //    $mdDialog.cancel();
    //    $scope.Sales_InvoicePayment = {};
    //    getInvoicePaymentsByInvoiceID($scope.Sales_Invoice.InvoiceID);
    //};

    $scope.savePayment = function () {
        $http.post('/Accounting/Sales_Invoice/saveInvoicePayment', { model: $scope.Sales_InvoicePayment, Sales_InvoiceID: $scope.Sales_Invoice.InvoiceID }).success(function (results) {
            recordPaymentAutoTransaction(results);
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    }

    $scope.savePaymentCash = function (SalesInvoiceID) {
        $scope.Sales_InvoicePayment.PaymentTypeID = 1;
        $scope.Sales_InvoicePayment.Amount = $scope.Sum.NetTotalPrice;
        $scope.Sales_InvoicePayment.PaymentDate = $scope.Sales_Invoice.InvoiceDate;

        $http.post('/Accounting/Sales_Invoice/saveInvoicePayment', { model: $scope.Sales_InvoicePayment, Sales_InvoiceID: SalesInvoiceID }).success(function (results) {
            recordPaymentAutoTransaction(results);
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    }

    function recordPaymentAutoTransaction(SalesInvoicePaymentID) {
        var Note;
        $http.get("/accounting/Sales_Invoice/getCurrentPaymentNoteBySalesInvoicePaymentID/" + SalesInvoicePaymentID).success(function (result) {
            Note = result;
            recordAutoTransaction();
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });

        function recordAutoTransaction() {
            // get Customer Chart Of Account [not implemented yet]

            //if ($scope.Sales_Invoice.SelectedCurrency != undefined) {
            //    $scope.Sales_Invoice.CurrencyID = $scope.Sales_Invoice.SelectedCurrency.CurrencyID;                
            //}

            var data = {
                Amount: $scope.Sales_InvoicePayment.Amount,                
                AutoTransactionOperationID: 2,
                CurrencyID: $scope.Sales_Invoice.CurrencyID,
                //FromID: $scope.Sales_Invoice.CurrencyID.CustomerID,
                PaymentTypeID: $scope.Sales_InvoicePayment.PaymentTypeID,
                currentDate: $scope.Sales_InvoicePayment.PaymentDate,
                Note: Note
            };
            $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction", data).success(function () {
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    }


    $scope.GetMeasureUnitQuanity = function (model) {
        $http.get('/Inventory/ProductDetails/GetMeasureUnitQuantity?ProductID=' + model.PartID + '&MeasureID=' + model.MeasureUnitID).success(function (results) {
            model.TotalQuantityFromChild = results;

            $scope.getRowPrices(model);
            $scope.getPrice();
            $scope.getTotalQuantity();

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

});