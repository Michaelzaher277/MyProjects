﻿angular.module('globalApp')
.controller('PayingCashFromSafeController', function ($scope, $mdToast, $mdDialog, $http, $rootScope) {

});