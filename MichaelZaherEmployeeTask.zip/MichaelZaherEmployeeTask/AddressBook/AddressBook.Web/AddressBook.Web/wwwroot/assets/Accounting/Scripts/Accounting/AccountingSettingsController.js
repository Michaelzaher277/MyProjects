﻿angular.module('globalApp')
.controller('AccountingSettingsController', function ($scope, $mdToast, $mdDialog, $http, $rootScope) {
    // Main Scope variables
    $scope.AccountingSettings = {};

    // Chart Of Accounts Tree Scope variables
    $scope.ChartOfAccounts = [];
    //$scope.ChartOfAccount = { IsGroup: false };
    $scope.ChartOfAccountsFilter = "";
    $scope.SettingMode = "";

    // Run at start
    //$scope.getChartOfAccountTree();
    $scope.getChartOfAccountTree2();

    getAccountingSetting();

    // Chart Of Accounts Tree Functions
    // -------------------------------- this function moved to app.js --------------------------------
    //function getChartOfAccountTree() {
    //    $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
    //        $scope.ChartOfAccounts = results.treeObj;
    //    }).error(function () {
    //        $rootScope.$emit("swAlertError", {});
    //    });
    //};

    $scope.selectNode = function (node) {
        $scope.ChartOfAccount = node.$modelValue;
    }

    $scope.findNodes = function (item) {
        $scope.ChartOfAccountsFilter = item.ChartOfAccountsFilter;
    };

    $scope.chooseChartOfAccount = function () {
        if ($scope.AccountingSettings == "null")
            $scope.AccountingSettings = {};

        switch ($scope.SettingMode) {
            case "client":
                chooseClientAccount();
                break;
            case "supplier":
                chooseSupplierAccount();
                break;
            case "safeCash":
                chooseSafeCashAccount();
                break;
            case "safeCheque":
                chooseSafeChequeAccount();
                break;
            case "bankBranchAccount":
                chooseBankBranchAccount();
                break;
            case "Salary":
                chooseSalaryAccount();
                break;
            case "Insurance":
                chooseInsuranceAccount();
                break;
            case "Tax":
                chooseTaxAccount();
                break;
            default:
                break;
        }

        $scope.cancelChartOfAccountsDialog();
    };

    $scope.FilterChartOfAccounts = function (item) {
        return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
    };

    $scope.cancelChartOfAccountsDialog = function () {
        $mdDialog.cancel();
        $scope.SettingMode = "";
        //$scope.ChartOfAccount = { IsGroup: false };
        $scope.ChartOfAccountsFilter = "";
    };

    $scope.showChartOfAccountsTree = function () {

        if ($scope.ChartOfAccounts.length <= 0) {
            //$scope.getChartOfAccountTree();
            $scope.getChartOfAccountTree2();
        }

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/AccountingSettingsChartOfAccount.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        });
    }

    // showing ChartOfAccounts Tree
    $scope.showClientChartOfAccountsTree = function () {
        $scope.SettingMode = "client";
        $scope.showChartOfAccountsTree();
    }

    $scope.showSupplierChartOfAccountsTree = function () {
        $scope.SettingMode = "supplier";
        $scope.showChartOfAccountsTree();
    }

    $scope.showSafeCashChartOfAccountsTree = function () {
        $scope.SettingMode = "safeCash";
        $scope.showChartOfAccountsTree();
    }

    $scope.showSafeChequeChartOfAccountsTree = function () {
        $scope.SettingMode = "safeCheque";
        $scope.showChartOfAccountsTree();
    }

    $scope.showBankBranchAccountChartOfAccountsTree = function () {
        $scope.SettingMode = "bankBranchAccount";
        $scope.showChartOfAccountsTree();
    }

    $scope.showSalaryAccountChartOfAccountsTree = function () {
        $scope.SettingMode = "Salary";
        $scope.showChartOfAccountsTree();
    }

    $scope.showInsuranceAccountChartOfAccountsTree = function () {
        $scope.SettingMode = "Insurance";
        $scope.showChartOfAccountsTree();
    }

    $scope.showTaxAccountChartOfAccountsTree = function () {
        $scope.SettingMode = "Tax";
        $scope.showChartOfAccountsTree();
    }

    // on choosing ChartOfAccount
    function chooseClientAccount() {
        $scope.AccountingSettings.ClientsParentID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.AccountingSettings.ClientsParentName = $scope.ChartOfAccount.Name;
    }

    function chooseSupplierAccount() {
        $scope.AccountingSettings.SuppliersParentID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.AccountingSettings.SuppliersParentName = $scope.ChartOfAccount.Name;
    }

    function chooseSafeCashAccount() {
        $scope.AccountingSettings.SafesCashParentID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.AccountingSettings.SafesCashParentName = $scope.ChartOfAccount.Name;
    }

    function chooseSafeChequeAccount() {
        $scope.AccountingSettings.SafesChequeParentID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.AccountingSettings.SafesChequeParentName = $scope.ChartOfAccount.Name;
    }

    function chooseBankBranchAccount() {
        $scope.AccountingSettings.BankBranchAccountsParentID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.AccountingSettings.BankBranchAccountsParentName = $scope.ChartOfAccount.Name;
    }

    function chooseSalaryAccount() {
        $scope.AccountingSettings.SalaryParentID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.AccountingSettings.SalaryParentAccountName = $scope.ChartOfAccount.Name;
    }

    function chooseInsuranceAccount() {
        $scope.AccountingSettings.InsuranceParentID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.AccountingSettings.InsuranceParentAccountName = $scope.ChartOfAccount.Name;
    }

    function chooseTaxAccount() {
        $scope.AccountingSettings.TaxParentID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.AccountingSettings.TaxParentAccountName = $scope.ChartOfAccount.Name;
    }

    // Main Functions
    function getAccountingSetting() {
        $http.get('/Accounting/AccountingSettings/getAccountingSettings').success(function (results) {
            $scope.AccountingSettings = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.Save = function () {
        $http.post("/Accounting/AccountingSettings/Save", $scope.AccountingSettings).success(function () {
            $rootScope.$emit("swAlertSave", {});
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        })
    };

});