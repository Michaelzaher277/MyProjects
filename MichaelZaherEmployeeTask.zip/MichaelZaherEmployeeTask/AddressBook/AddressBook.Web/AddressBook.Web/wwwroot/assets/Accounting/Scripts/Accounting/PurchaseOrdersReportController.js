﻿angular.module('globalApp')
    .controller('PurchaseOrdersReportController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter, $element) {
    
    $scope.model = {};    

    $scope.checkReport = function (model) {
        
        var 
            reportParams = {
                "Parms": { "DateFrom": $filter('date')(model.DateFrom, "yyyy-MM-dd"), "DateTo": $filter('date')(model.DateTo, "yyyy-MM-dd")
                         },
                "ReportName": "PurchaseReport/PurchaseOrdersReport.trdx"
        };

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }

    $scope.clearFields = function () {
        $scope.model = {};        
    }

});