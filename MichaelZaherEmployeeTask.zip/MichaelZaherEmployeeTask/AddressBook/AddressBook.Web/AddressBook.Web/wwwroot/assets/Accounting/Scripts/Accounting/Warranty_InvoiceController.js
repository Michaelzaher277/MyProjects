﻿angular.module('globalApp')
.controller('Warranty_InvoiceController', function ($scope, $mdToast, $mdDialog, $http, $rootScope, $element, $cookies, $filter) {

    $scope.Warranty_Invoices = [];
    $scope.Warranty_Invoice = {};

    $scope.Warranty_InvoiceDetails = [];
    $scope.Warranty_InvoiceDetail = {};
    $scope.Parts = [];
    $scope.Customers = [];
    $scope.InvoiceTypes = [];
    $scope.PaymentTypes = [];
    $scope.Currencies = [];
    $scope.MeasureUnits = [];
    $scope.JobOrderDetails = [];
    $scope.JOFinalIndexaion = [];
    $scope.JOExtraWorks = [];
    $scope.JOWorkDone = [];

    $scope.Invoiceselected = [];
    $scope.InvoiceDetailSelected = [];
    $scope.InvoicePaymentSelected = [];

    $scope.selectedProduct = [];
    $scope.selectedJobOrder = [];
    $scope.selectedSellInvoice = [];

    $scope.searchTerm = '';
    $scope.clearSearchTerm = function () {
        $scope.searchTerm = '';
    };

    $scope.Sum = {};
    $scope.Sum.TotalQuantity = '0';
    $scope.Sum.Price = '0';
    $scope.Sum.Discount = '0';
    $scope.Sum.TotalPrice = '0';
    $scope.Sum.Taxes = '0';
    $scope.Sum.TaxesDiscount = '0';
    $scope.Sum.NetTotalPrice = '0';   
   
    $scope.Sum.Amount = 0;   
    $scope.Sum.TotalCost = 0;
    $scope.Sum.TotalInvoice = 0;

    $scope.Setting = {};

    $scope.parseInt = parseInt;

    getWarranty_Invoices();
    getJobOrders();

  //  getSellInvoices();
    //getCustomers();
    
    getCurrencies();

    $scope.getSetting = function () {
        $http.get('/AccountingSettings/getAccountingSettings').success(function (results) {
            $scope.Setting = results;
        })
    };

    $scope.getSetting();

    $scope.clearFields = function () {
        HideMasterShowDetails('#divDetails', '#divMain');
        $scope.Warranty_Invoice = {};
        $scope.Warranty_InvoiceDetails = [];
        $scope.Warranty_InvoicePayments = [];
        $scope.edit.show = false;
        $scope.Invoiceselected = [];
    };

   


    function GetLastCodeInvoices  (id) {
            $http.get('/Warranty_Invoice/GetLastCodeInvoices').success(function (results) {
                $scope.Warranty_Invoice.InvoiceCode = results;
                $scope.Warranty_Invoice.InvoiceDate = new Date();;
            }).error(function (data, status, headers, config) {
                swAlertErrorAr();
            });

    };

    var Init =(function () {
        function Init() {
            $scope.Warranty_Invoice.InvoiceDate = new Date();
            ;
        }
        Init.prototype.GetLastCodeInvoices = function () {
            $http.get('/Warranty_Invoice/GetLastCodeInvoices').success(function (results) {
                $scope.Warranty_Invoice.InvoiceCode = results;
            }).error(function (data, status, headers, config) {
                swAlertErrorAr();
            });
        };
        return Init;
    }());
    $scope.showAdvancedAdd = function (ev) {       
        HideMasterShowDetails('#divMain', '#divDetails');
        //getInvoiceTypes();
      
       // GetLastCodeInvoices();
        var init = new Init();
        init.GetLastCodeInvoices();
        //$scope.getMeasureUnits();
        //console.log(greeter.greet());
        $scope.TotalQuantity = 0;
        $scope.Amount = 0;
        $scope.Discount = 0;
        $scope.Taxes = 0;
        $scope.TaxesDiscount = 0;
    };

    //Reports
    $scope.checkReport = function (model) {
        var reportParams = {
            "Parms": { "InvoiceID": model.InvoiceID },
            "ReportName": "Warranty_InvoiceReport.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }
    // Begin Select2 drop down lists //

   

    function getCurrencies() {
        $http.get('/Purchase_Invoice/getAllCurrencies').success(function (results) {
            $scope.Currencies = results;
            for (var i = 0; i < $scope.Currencies.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                }
                else {
                    $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                }
            }
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.getCurrency = function (CurrencyID) {
        $http.get('/Currency/getCurrencyByID?id=' + CurrencyID).success(function (data) {
            $scope.Warranty_Invoice.Currency_Convert = data.ConvertValue;
        });
    };

    $scope.getMeasureUnits = function (viewValue) {
        var params = { ProductID: viewValue.PartID };
        return $http.get('/Purchase_Invoice/GetMeasureUnitByProductID', { params: params })
       .then(function (res) {
          
           for (var j = 0; j < res.data.length; j++) {
               if ($cookies.get('ERP_lang') == 'ar-EG') {
                   res.data[j].Title = res.data[j].NameAr;
               }
               else {
                   res.data[j].Title = res.data[j].NameEng;
               }
           }
           viewValue.MeasureUnits = res.data;
       });
    };

   

    $scope.SearchMeasureUnits = function ($event, filterMeasureUnit, item) {
        $event.stopPropagation();
        $http.get('/Purchase_Invoice/BindMeasureUnit/' + filterMeasureUnit).success(function (results) {
            item.MeasureUnits = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.SearchParts = function ($event, filterText, item) {
        $event.stopPropagation();
        $http.get('/MaintenaceProgram/BindSparePartsByName/' + filterText).success(function (results) {
            item.Parts = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $element.find('input#searchCustomers').on('keydown', function (ev) {
        ev.stopPropagation();
    });

    $scope.loadCustomers = function () {
        if ($scope.Customers.length <= 0) {
            $http.get('/Administration/Customer/GetCustomers').success(function (results) {
                $scope.Customers = results;

                for (var i = 0; i < $scope.Customers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Customers[i].Title = $scope.Customers[i].NameAr;
                    }
                    else {
                        $scope.Customers[i].Title = $scope.Customers[i].NameEng;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.loadCustomers();

    

    // onSelect Functions //


    // End Select2 drop down lists //

    function getJobOrders() {
        $http.get('/JobOrder/JobOrder/GetALLJobOrder').success(function (results) {
            $scope.JobOrderDetails = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    function getWarranty_Invoices() {
        $http.get('/Warranty_Invoice/getInvoices').success(function (results) {
            $scope.Warranty_Invoices = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };



    $scope.save = function () {
        $scope.Warranty_Invoice.Warranty_InvoiceDetail = $scope.Warranty_InvoiceDetails;
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Warranty_Invoice),
            url: '/Warranty_Invoice/saveInvoice',
            success: function (result) {
                HideMasterShowDetails('#divDetails', '#divMain');
                $scope.clearFields();
                swAlertSaveAr();
                getWarranty_Invoices();
               // $scope.saveAutoTransaction(result);

                //if ($scope.Warranty_Invoice.InvoiceTypeID = 1) {
                //    $scope.savePaymentCash(result);
                //}
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.saveAutoTransaction = function (WarrantyInvoiceID) {
        var totalAmount;
        var Note;

        $http.get("/accounting/Warranty_Invoice/getInvoiceTotalAmountByInvoiceID/" + WarrantyInvoiceID).success(function (result) {
            totalAmount = result;
            getNote(WarrantyInvoiceID);
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });

        function getNote(WarrantyInvoiceID) {
            $http.get("/accounting/Warranty_Invoice/getCurrentNoteByWarrantyInvoiceID/" + WarrantyInvoiceID).success(function (result) {
                Note = result;
                recordAutoTransaction();
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }

        function recordAutoTransaction() {
            // get Customer Chart Of Account [not implemented yet]
            var data = {
                Amount: totalAmount,
                AutoTransactionOperationID: 1,
                CurrencyID: $scope.Warranty_Invoice.CurrencyID,
                //FromID: $scope.Warranty_Invoice.CurrencyID.CustomerID,
                Warranty_InvoiceTypeID: $scope.Warranty_Invoice.InvoiceTypeID,
                currentDate: $scope.Warranty_Invoice.InvoiceDate,
                Note: Note
            };
            $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction", data).success(function () {
                getWarranty_Invoices();
                HideMasterShowDetails('#divDetails', '#divMain');
                $scope.clearFields();
                swAlertSaveAr();
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    }

    $scope.edit = function (model) {
        $scope.Warranty_Invoice = model
        getInvoiceDetailsByInvoiceID(model.InvoiceID);
        HideMasterShowDetails('#divMain', '#divDetails');
        getCurrencies();
        setTimeout(function () {
            $scope.getTotalQuantity();
            $scope.getPrice();
            $scope.getDiscount();
            $scope.getTotalPrice();
            $scope.getTaxes();
            $scope.getTaxesDiscount();
            $scope.getNetTotalPrice();

        }, 1000)

    };

    $scope.loadDetailsFrom = function (JobOrder) {
        $http.get('/accounting/Warranty_Invoice/getJobOrderPartsByID/' + JobOrder.JobOrderID).success(function (results) {
            $scope.JOWorkDone = results;
            $http.get('/accounting/Warranty_Invoice/getJobOrderWorksByID/' + JobOrder.JobOrderID).success(function (results2) {
              //  $scope.JOWorkDone.concat(results2);
                Array.prototype.push.apply($scope.JOWorkDone, results2);
            debugger;
            addDetailsWorkDoneInInvoice();
            $scope.Warranty_Invoice.JobOrderCode = JobOrder.JobOrderNumber;
            $scope.Warranty_Invoice.JobOrderID = JobOrder.JobOrderID;
        }).error(function () {
            swAlertErrorAr();
        });
        });
        $scope.hide();
    }

 


    function addDetailsWorkDoneInInvoice() {
        for (i = 0; i < $scope.JOWorkDone.length; i++) {

            if ($scope.JOWorkDone[i].SparePartID != null) {
                var item = {};
                item.PartID = $scope.JOWorkDone[i].SparePartID;
                item.ProductName = $scope.JOWorkDone[i].PartName;
                item.ProductCode = $scope.JOWorkDone[i].PartCode;
                item.Quantity = $scope.JOWorkDone[i].Quantity;
               // item.MeasureUnits = $scope.JOWorkDone[i].MeasureUnits;

                //for (var j = 0; j < item.MeasureUnits.length; j++) {
                //    if ($cookies.get('ERP_lang') == 'ar-EG') {
                //        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                //    }
                //    else {
                //        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                //    }
                //}

                if ($scope.Setting != undefined) {
                    item.Taxes = $scope.Setting.WarrantyInvoiceTaxAmount;
                    item.TaxesDiscount = $scope.Setting.WarrantyDiscountInvoiceAmount;
                }
                else {
                    $scope.getSetting();
                    if ($scope.Setting != undefined) {
                        item.Taxes = $scope.Setting.WarrantyInvoiceTaxAmount;
                        item.TaxesDiscount = $scope.Setting.WarrantyDiscountInvoiceAmount;
                    }
                }

                var foundItem = $filter('filter')($scope.Warranty_InvoiceDetails, { ProductCode: $scope.JOWorkDone[i].PartCode }, true)[0];

                if (foundItem == undefined) {
                    $scope.Warranty_InvoiceDetails.push(item);
                }

            }
            else {

                var item = {};
                item.workID = $scope.JOWorkDone[i].WorkID;
                item.WorkName = $scope.JOWorkDone[i].WorkName;
                item.DisplayName = $scope.JOWorkDone[i].WorkName;

                if ($scope.Setting != undefined) {
                    item.Taxes = $scope.Setting.WarrantyInvoiceTaxAmount;
                    item.TaxesDiscount = $scope.Setting.WarrantyDiscountInvoiceAmount;
                }
                else {
                    $scope.getSetting();
                    if ($scope.Setting != undefined) {
                        item.Taxes = $scope.Setting.WarrantyInvoiceTaxAmount;
                        item.TaxesDiscount = $scope.Setting.WarrantyDiscountInvoiceAmount;
                    }
                }

                var foundItem = $filter('filter')($scope.Warranty_InvoiceDetails, { WorkID: $scope.JOWorkDone[i].WorkID }, true)[0];

                if (foundItem == undefined) {
                    $scope.Warranty_InvoiceDetails.push(item);
                }
            }

        };

        $scope.getTotalQuantity();
        $scope.getPrice();
        $scope.getDiscount();
        $scope.getTotalPrice();
        $scope.getTaxes();
        $scope.getTaxesDiscount();
        $scope.getNetTotalPrice();
    }



    function addDetailsIndexationInInvoice() {
        for (i = 0; i < $scope.JOFinalIndexaion.IndexationDetails.length; i++) {
            if ($scope.JOFinalIndexaion.IndexationDetails[i].IsPart) {
                $scope.Warranty_InvoiceDetails.push({
                    IsPart: true,
                    Quantity: $scope.JOFinalIndexaion.IndexationDetails[i].Quantity,
                    PartID: $scope.JOFinalIndexaion.IndexationDetails[i].PartID,
                    PartName: $scope.JOFinalIndexaion.IndexationDetails[i].PartName,
                    Notes: $scope.JOFinalIndexaion.IndexationDetails[i].IssueDescription
                });
            }
            else {
                $scope.Warranty_InvoiceDetails.push({
                    Description: $scope.JOFinalIndexaion.IndexationDetails[i].WorkPoints,
                    Notes: $scope.JOFinalIndexaion.IndexationDetails[i].IssueDescription
                });
            }
        };

        $scope.getTotalQuantity();
        $scope.getPrice();
        $scope.getDiscount();
        $scope.getTotalPrice();
        $scope.getTaxes();
        $scope.getTaxesDiscount();
        $scope.getNetTotalPrice();
    }

    function addDetailsExtraWorksInInvoice() {
        for (i = 0; i < $scope.JOExtraWorks.length; i++) {
            $scope.Warranty_InvoiceDetails.push({
                Notes: $scope.JOExtraWorks[i].Description
            });
        };
    }

    function getInvoiceDetailsByInvoiceID(InvoiceID) {
        $http.get('/Warranty_Invoice/getInvoiceDetailsByInvoiceID/' + InvoiceID).success(function (results) {

            //for (var i = 0; i < results.length; i++) {
            //    results[i].Parts = [];
            //    results[i].Parts.push(results[i].Product);
            //    results[i].MeasureUnits = [];
            //    results[i].MeasureUnits.push(results[i].MeasureUnit);
            //}

            $scope.Warranty_InvoiceDetails = results;

            for (var i = 0; i < $scope.Warranty_InvoiceDetails.length; i++) {
                $scope.getMeasureUnits($scope.Warranty_InvoiceDetails[i]);
                $scope.Warranty_InvoiceDetails[i].MeasureUnits = $scope.MeasureUnits;
                $scope.getRowPrices($scope.Warranty_InvoiceDetails[i]);
            }

            $scope.TotalQuantity = 0;
            $scope.Amount = 0;
            $scope.Discount = 0;
            $scope.Taxes = 0;
            $scope.TaxesDiscount = 0;

            $.each($scope.Warranty_InvoiceDetails, function (i, item) {

                if (!isNaN(parseFloat(item.Quantity))) {
                    $scope.TotalQuantity += parseFloat(item.Quantity);
                }

                if (!isNaN(parseFloat(item.Amount))) {
                    $scope.Amount += parseFloat(item.Amount);
                }

                if (!isNaN(parseFloat(item.Discount))) {
                    $scope.Discount += parseFloat(item.Discount);
                }

                if (!isNaN(parseFloat(item.Taxes))) {
                    $scope.Taxes += parseFloat(item.Taxes);
                }

                if (!isNaN(parseFloat(item.TaxesDiscount))) {
                    $scope.TaxesDiscount += parseFloat(item.TaxesDiscount);
                }

            });

            //$scope.getInvoiceTypes();
            //$scope.getTotalQuantity();
            //$scope.getPrice();
            //$scope.getTaxes();
            //$scope.getDiscount();
            //$scope.getTaxesDiscount();

        }).error(function () {
            swAlertErrorAr();
        });
    }

  

    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Accounting/Warranty_Invoice/deleteInvoice', JSON.stringify($scope.Invoiceselected)).success(function () {
                       getWarranty_Invoices();
                       $scope.Invoiceselected = [];
                   });
               }
           });
    }

    $scope.deleteDetail = function (model) {
        if (model.InvoiceDetailID != undefined) {
            $rootScope.$emit("swAlertSorry", {});
            //$scope.Warranty_InvoiceDetails.splice($.inArray(model, $scope.Warranty_InvoiceDetails), 1);
        }
        else {
            $rootScope.$emit("swConfirmDelete",
              {
                  function () {
                      $http.post('/Accounting/Warranty_Invoice/deleteInvoiceDetail', JSON.stringify($scope.InvoiceDetailSelected)).success(function () {
                          $scope.Warranty_InvoiceDetails.splice($.inArray(model, $scope.Warranty_InvoiceDetails), 1);
                          $scope.$apply();
                          $scope.getTotalQuantity();
                          $scope.getPrice();
                          $scope.getDiscount();
                          $scope.getTotalPrice();
                          $scope.getTaxes();
                          $scope.getTaxesDiscount();
                          $scope.getNetTotalPrice();
                      });

                      $scope.InvoiceDetailSelected = [];
                  }
              });
        }

    }

   

    $scope.AddInvoiceDetailEnter = function (keyEvent) {
        if (keyEvent.which === 13) {
            keyEvent.preventDefault();
            $scope.AddInvoiceDetail();
        }
    }

  


    $scope.getTotalQuantity = function () {
       
        $scope.Sum.TotalQuantity = 0;
        $.each($scope.Warranty_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Quantity))) {
                $scope.Sum.TotalQuantity += parseFloat(item.Quantity);
            }
        });
    }

    $scope.getPrice = function () {
       

        $scope.Sum.Amount = 0;

        $.each($scope.Warranty_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Amount))) {
                $scope.Sum.Amount += parseFloat(item.Amount);
            }
        });
    }

    $scope.getDiscount = function () {
      


        $scope.Sum.Discount = 0;

        $.each($scope.Warranty_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Discount))) {
                $scope.Sum.Discount += parseFloat(item.Discount);
            }
        });
    }

    $scope.getTotalPrice = function () {
        var total = 0;
        for (var i = 0; i < $scope.Warranty_InvoiceDetails.length; i++) {
            var item = $scope.Warranty_InvoiceDetails[i];
            if (item.TotalPrice != undefined) {
                total += item.TotalPrice;
            }
        }
        $scope.Sum.TotalPrice = total.toString();
    }

    $scope.getTaxes = function () {
       


        $scope.Sum.Taxes = 0;

        $.each($scope.Warranty_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Taxes))) {
                $scope.Sum.Taxes += parseFloat(item.Taxes);
            }
        });
    }

    $scope.getTaxesDiscount = function () {
     

        $scope.Sum.TaxesDiscount = 0;
        $.each($scope.Warranty_InvoiceDetails, function (i, item) {
            if (!isNaN(parseFloat(item.TaxesDiscount))) {
                $scope.Sum.TaxesDiscount += parseFloat(item.TaxesDiscount);
            }
        });
    }

    $scope.getNetTotalPrice = function () {
        var total = 0;
        for (var i = 0; i < $scope.Warranty_InvoiceDetails.length; i++) {
            var item = $scope.Warranty_InvoiceDetails[i];
            if (item.NetTotalPrice != undefined) {
                total += item.NetTotalPrice;
            }
        }
        $scope.Sum.NetTotalPrice = total.toString();
    }

    $scope.getRowPrices = function (item) {
        var Quantity = 0;
        var Price = 0;
        var Discount = 0;
        var Taxes = 0;
        var TaxesDiscount = 0;
        
        var TotalQuantityFromChild = 1;
        if (item.TotalQuantityFromChild != undefined)
            TotalQuantityFromChild = item.TotalQuantityFromChild

        if (item.Quantity != undefined)
            Quantity = item.Quantity * TotalQuantityFromChild;
        else
            Quantity = 0;

        if (item.Amount != undefined)
            Price = item.Amount;
        else
            Price = 0;

        if (item.Discount != undefined)
            Discount = ((Quantity * Price) * item.Discount) / 100;
        else
            Discount = 0;

        if (item.Taxes != undefined)
            Taxes = ((Quantity * Price) * item.Taxes) / 100;
        else
            Taxes = 0;

        if (item.TaxesDiscount != undefined)
            TaxesDiscount = ((Quantity * Price) * item.TaxesDiscount) / 100;
        else
            TaxesDiscount = 0;

        item.TotalPrice = ((Quantity * Price) + Taxes - TaxesDiscount - Discount).toString();
        $scope.getTotalPrice();
    }

    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;

        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };



    $scope.queryDetails = {
        orderDetails: 'name',
        filterDetails: '',
        limitDetails: 5,
        pageDetails: 1
    };
    $scope.removeFilterDetails = function () {
        $scope.filterDetails.show = false;

        $scope.queryDetails.filterDetails = '';

        if ($scope.filterDetails.form.$dirty) {
            $scope.filterDetails.form.$setPristine();
        }
    };
    $scope.limitOptionsDetails = [5, 10, 15];
    $scope.optionsDetails = {
        pageSelectDetails: true
    };



    $scope.queryInvoice = {
        orderInvoice: 'name',
        filterInvoice: '',
        limitInvoice: 5,
        pageInvoice: 1
    };
    $scope.removeFilterInvoice = function () {
        $scope.filterInvoice.show = false;

        $scope.queryInvoice.filterInvoice = '';

        if ($scope.filterInvoice.form.$dirty) {
            $scope.filterInvoice.form.$setPristine();
        }
    };
    $scope.limitOptionsInvoice = [5, 10, 15];
    $scope.optionsInvoice = {
        pageSelectInvoice: true
    };



    $scope.queryJobOrder = {
        orderJobOrder: 'name',
        filterJobOrder: '',
        limitJobOrder: 5,
        pageJobOrder: 1
    };
    $scope.removeFilterJobOrder = function () {
        $scope.filterJobOrder.show = false;

        $scope.queryJobOrder.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
    $scope.limitOptionsJobOrder = [5, 10, 15];
    $scope.optionsJobOrder = {
        pageSelectJobOrder: true
    };


    $scope.showAdvancedAddJobOrder = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Sales_InvoiceLoadJobOrders.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };

    $scope.hide = function () {
        $mdDialog.hide();

    };

    $scope.cancel = function () {
        $mdDialog.cancel();

        $scope.Invoiceselected = [];
        $scope.InvoiceDetailSelected = [];
        $scope.selectedProduct = [];
        $scope.selectedJobOrder = [];
    };

 function recordAutoTransaction() {
          

            var data = {
                Amount: $scope.Warranty_InvoicePayment.Amount,                
                AutoTransactionOperationID: 2,
                CurrencyID: $scope.Warranty_Invoice.CurrencyID,
                //FromID: $scope.Warranty_Invoice.CurrencyID.CustomerID,
                PaymentTypeID: $scope.Warranty_InvoicePayment.PaymentTypeID,
                currentDate: $scope.Warranty_InvoicePayment.PaymentDate,
                Note: Note
            };
            $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction", data).success(function () {
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    


 $scope.GetMeasureUnitQuanity = function (model) {
     $http.get('/Inventory/ProductDetails/GetMeasureUnitQuantity?ProductID=' + model.PartID + '&MeasureID=' + model.MeasureUnitID).success(function (results) {
         model.TotalQuantityFromChild = results;

         $scope.getRowPrices(model);
         $scope.getPrice();
         $scope.getTotalQuantity();

     }).error(function (data, status, headers, config) {
         swAlertErrorAr();
     });
 };

});