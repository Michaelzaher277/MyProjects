﻿
angular.module('globalApp')
.controller('Examination_RecordController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter) {

    $scope.Examination_Records = [];
    $scope.Examination_Record = {};
    $scope.filterJobOrdered = '';
    $scope.selected = [];
    $scope.selectedProduct = [];
    $scope.selectedDetails = [];
    $scope.selectedPurchaseOrder = [];
    $scope.AddNew = false;
    getExamination_Records();
    $scope.Examination_RecordDetail = {};
    $scope.Examination_RecordDetails = [];
    $scope.Product = {};
    HideMasterShowDetails("#DivSave", "#DivShow");

    function getLastCodeRecords() {
        $http.get('/Examination_Record/GetLastCodeRecords').success(function (results) {
            $scope.Examination_Record.RecordCode = results;
            //var today = $filter('date')(new Date(), 'yyyy-MM-dd');
            $scope.Examination_Record.RecordDate = new Date();;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    function getExamination_Records() {
        $http.get('/Examination_Record/GetALLRecords').success(function (results) {
            $scope.Examination_Records = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.showAdvancedAdd = function (ev) {
        //  $("DivShow)
        HideMasterShowDetails("#DivShow", "#DivSave");

        getLastCodeRecords();


    };

    $scope.getMeasureUnit=function(productID) {
        $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
            $scope.MeasureUnits = results;
            for (var i = 0; i < $scope.MeasureUnits.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
                }
                else {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEng;
                }
            }

            for (var i = 0; i < $scope.Examination_RecordDetails.length; i++) {
                if ($scope.Examination_RecordDetails[i].ProductID == productID)
                    $scope.Examination_RecordDetails[i].MeasureUnits = $scope.MeasureUnits;
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };


    $scope.getProductModal = function (modal) {

        for (i = 0; i < modal.length; i++) {
            if (modal[i].ProductID != null) {
                var item = {};
                item.ProductID = modal[i].ProductID;
                item.ProductName = modal[i].NameAr;
                item.ProductCode = modal[i].Code;
                item.MeasureUnits = modal[i].MeasureUnits;
                for (var j = 0; j < item.MeasureUnits.length; j++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                    }
                    else {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                    }
                }
                var foundItem = $filter('filter')($scope.Examination_RecordDetails, { ProductCode: modal[i].Code }, true)[0];

                if (foundItem == undefined) {
                    $scope.Examination_RecordDetails.push(item);
                }
//$scope.Examination_RecordDetails.push(item);
            }
        }
       // $scope.cancelProduct();

        // $('#DivParts').modal('toggle');
    };

    $scope.getAllProductsModal = function () {
        $http.get('/Inventory/ProductDetails/GetProducts').success(function (results) {
            $scope.Products = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    }

    $scope.showProductsAdd = function (ev) {
        //  $("DivShow)
        //   $scope.Purchase_OrderDetails.push({});
        //  $scope.getAllProductsModal();
        $scope.GetTopProducts("");

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadProducts.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addProduct',
            closeTo: '.addProduct'
        })
    }

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Examination_Record = {};
    };


    $scope.cancelDialog = function () {

        $mdDialog.cancel();
    };

    $scope.cancelProduct = function () {
        $mdDialog.cancel();
        $scope.selectedProduct = [];
    };
    $scope.cancelExamination_Record = function () {
        //   $mdDialog.cancel();
        HideMasterShowDetails("#DivSave", "#DivShow");
        $scope.Examination_Record = {};
        $scope.Examination_RecordDetails = [];
        $scope.selectedDetails = [];
        $scope.selected = [];

    };


    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {
        $scope.Examination_Record.Examination_RecordDetail = $scope.Examination_RecordDetails;
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Examination_Record),
            url: '/Examination_Record/save',
            success: function () {
                getExamination_Records();
                $scope.cancelExamination_Record();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Examination_Record/deleteExaminationRecord', JSON.stringify($scope.selected)).success(function () {
                       getExamination_Records();
                       $scope.selected = [];
                   });
               }
           });
    }

    function getDetails(RecordID) {
        $http.get('/Examination_Record/GetDetailsByRecordID?id=' + RecordID).success(function (results) {
            $scope.Examination_RecordDetails = results;
            for (var i = 0; i < $scope.Examination_RecordDetails.length; i++) {
                $scope.getMeasureUnit($scope.Examination_RecordDetails[i].ProductID);
                $scope.Examination_RecordDetails[i].MeasureUnits = $scope.MeasureUnits;
            }
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.edit = function (Examination_RecordID) {
        $http.get('/Examination_Record/GetRecordByID/' + Examination_RecordID).success(function (data) {
            $scope.Examination_Record = data;
            getDetails(Examination_RecordID);
            HideMasterShowDetails("#DivShow", "#DivSave");

        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.removeFilterProduct = function () {
        $scope.filtered.show = false;
        $scope.query.filtered = '';

        if ($scope.filtered.form.$dirty) {
            $scope.filtered.form.$setPristine();
        }
    };


    $scope.LoadSupplyOrders = function (ev) {

        getSupplyOrders();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Record_LoadSupplyOrder.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        })

    };

    //load supply order

    function getSupplyOrders() {
        $http.get('/Sales_SupplyOrders/getAllSupplyOrdersExaminationRecord').success(function (results) {
            $scope.SupplyOrders = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.getSupplyOrder = function (OrderID) {
        $scope.EditProduct = 'true';
        $http.get('/Sales_SupplyOrders/GetNotAvailableDetailsBySupplyOrderID?id=' + OrderID).success(function (results) {
            $scope.Examination_RecordDetails = results;
            $scope.Examination_Record.SupplyOrderID = OrderID;
            $scope.cancelProduct();

        }).error(function () {
            swAlertErrorAr();
        });
    };


    $scope.LoadPurchaseOrder = function (ev) {
        $scope.getOrders();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Confirmation_LoadPurchaseOrder.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.LoadOrder',
            closeTo: '.LoadOrder'
        })

    };

    //load Order
    $scope.getOrders = function () {
        $http.get('/Purchase_Order/GetALLOrders').success(function (results) {
            $scope.Purchase_Orders = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };
    $scope.getOrder = function (OrderID) {
        $http.get('/Purchase_Order/GetDetailsByOrderID/' + OrderID).success(function (results) {
           
            $scope.Examination_RecordDetails = results;
            for (var i = 0; i < $scope.Examination_RecordDetails.length; i++) {
                $scope.getMeasureUnit($scope.Examination_RecordDetails[i].ProductID);
                $scope.Examination_RecordDetails[i].MeasureUnits = $scope.MeasureUnits;

            }
            //    $scope.Confirmation_Order.OrderID = results[0].OrderID;
            $scope.cancelProduct();
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.checkReport = function (InvoiceID) {
        var reportParams = {
            "Parms": { "InvoiceID": InvoiceID },
            "ReportName": "PurchaseReport/ExaminationRecordReport.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }


});