﻿
angular.module('globalApp')
.controller('SalesInvoiceIFlightController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $element, $filter, $timeout, $q) {

    $scope.SalesInvoiceIFlights = [];
    $scope.SalesInvoiceIFlight = {};

    $scope.SalesInvoiceIFlightDetails = [];
    $scope.SalesInvoiceIFlightDetail = {};

    $scope.Flights = [];
    $scope.Flight = {};

    $scope.selected = [];
    $scope.selectedDetails = [];
    $scope.selectedFlight = [];

    $scope.AddNew = false;

    $scope.Banks = [];
    $scope.BankBranches = [];
    $scope.BankBranchAccounts = [];

    $scope.Customers = [];
    $scope.Contracts = [];

    $scope.SearchSalesInvoiceIFlight = {};

    $scope.FinalSalesInvoiceIFlights = [];

    $scope.SectorInfo = {};

    getSalesInvoiceIFlights();
    HideMasterShowDetails("#DivSave", "#DivShow");


    //////// get invoices
    function getSalesInvoiceIFlights() {
        $http.get('/accounting/SalesInvoiceIFlight/GetALLInvoices').success(function (results) {
            $scope.SalesInvoiceIFlights = results;

            for (var i = 0; i < $scope.SalesInvoiceIFlights.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.SalesInvoiceIFlights[i].CustomerTitle = $scope.SalesInvoiceIFlights[i].CustomerNameAr;
                }
                else {
                    $scope.SalesInvoiceIFlights[i].CustomerTitle = $scope.SalesInvoiceIFlights[i].CustomerNameEn;
                }
            }

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    //Search
    $scope.getSalesInvoiceIFlightAll = function () {

        if ($scope.selectedInvoice != null)
            $scope.SearchSalesInvoiceIFlight.InvoiceCode = $scope.selectedInvoice.InvoiceCode;
        else
            $scope.SearchSalesInvoiceIFlight.InvoiceCode = '';

        if ($scope.selectedCustomer != null)
            $scope.SearchSalesInvoiceIFlight.CustomerID = $scope.selectedCustomer.CustomerID;
        else
            $scope.SearchSalesInvoiceIFlight.CustomerID = 0;

        if ($scope.selectedContract != null)
            $scope.SearchSalesInvoiceIFlight.IFlightContractID = $scope.selectedContract.ClientContractsID;
        else
            $scope.SearchSalesInvoiceIFlight.IFlightContractID = 0;

        if ($scope.SearchSalesInvoiceIFlight.DateFrom == undefined)
            $scope.SearchSalesInvoiceIFlight.DateFrom = null;

        if ($scope.SearchSalesInvoiceIFlight.DateTo == undefined)
            $scope.SearchSalesInvoiceIFlight.DateTo = null;

        $http.post('/accounting/SalesInvoiceIFlight/FilterSalesInvoiceIFlight', { 'item': $scope.SearchSalesInvoiceIFlight }).success(function (results) {
            $scope.FinalSalesInvoiceIFlights = results;

            for (var i = 0; i < $scope.FinalSalesInvoiceIFlights.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.FinalSalesInvoiceIFlights[i].StatusTitle = $scope.FinalSalesInvoiceIFlights[i].StatusNameAr;
                }
                else {
                    $scope.FinalSalesInvoiceIFlights[i].StatusTitle = $scope.FinalSalesInvoiceIFlights[i].StatusNameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    }

    //////// get Customers
    $scope.loadCustomers = function () {
        if ($scope.Customers.length <= 0) {
            $http.get('/Administration/Customer/getOptimiseACtiveCustomers').success(function (results) {
                $scope.Customers = results;

                for (var i = 0; i < $scope.Customers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Customers[i].Title = $scope.Customers[i].NameAr;
                    }
                    else {
                        $scope.Customers[i].Title = $scope.Customers[i].NameEng;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.loadCustomers();

    /////////////// get contracts api
    $scope.GetContractsByClientID = function (ClientID) {
        if (ClientID != undefined) {
            $http.get('/accounting/SalesInvoiceIFlight/GetContractsByClientID?ClientID=' + ClientID).success(function (results) {
                $scope.Contracts = results;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    /////////////// get sector info api
    $scope.GetSectorInfoBySectorID = function (SectorID) {
        if (SectorID != undefined) {
            $http.get('/accounting/SalesInvoiceIFlight/GetSectorInfoBySectorID?SectorID=' + SectorID).success(function (results) {
                $scope.SectorInfo = results;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    ///////////////////////////////////////////// Auto Complete

    //////////////////// Customers By Code
    $scope.querySearchCustomersByCode = function (query) {
        var results = query ? $scope.Customers.filter(createFilterForCustomersByCode(query)) : $scope.Customers;
        var deferred = $q.defer();
        $timeout(function () { deferred.resolve(results); }, Math.random() * 1000, false);
        return deferred.promise;
    }

    function createFilterForCustomersByCode(query) {
        var lowercaseQuery = angular.uppercase(query);
        return function filterFn(aa) {
            if (aa.Code != null)
                return (aa.Code.indexOf(lowercaseQuery) != -1);
            else
                return false;
        };
    }

    //////////////////// Customers By Name
    $scope.querySearchCustomersByName = function (query) {
        var results = query ? $scope.Customers.filter(createFilterForCustomersByName(query)) : $scope.Customers;
        var deferred = $q.defer();
        $timeout(function () { deferred.resolve(results); }, Math.random() * 1000, false);
        return deferred.promise;
    }

    function createFilterForCustomersByName(query) {
        var lowercaseQuery = angular.uppercase(query);
        return function filterFn(aa) {
            if (aa.NameAr != null)
                return (aa.NameAr.indexOf(lowercaseQuery) != -1);
            else
                return false;
        };
    }

    //////////////////// Contract By Code
    $scope.querySearchContractsByCode = function (query) {
        var results = query ? $scope.Contracts.filter(createFilterForContractsByCode(query)) : $scope.Contracts;
        var deferred = $q.defer();
        $timeout(function () { deferred.resolve(results); }, Math.random() * 1000, false);
        return deferred.promise;
    }

    function createFilterForContractsByCode(query) {
        var lowercaseQuery = angular.uppercase(query);
        return function filterFn(aa) {
            if (aa.ContractCode != null)
                return (aa.ContractCode.indexOf(lowercaseQuery) != -1);
            else
                return false;
        };
    }

    //////////////////// Invoice By Code
    $scope.querySearchInvoices = function (query) {
        var results = query ? $scope.SalesInvoiceIFlights.filter(createFilterForInvoicesByCode(query)) : $scope.SalesInvoiceIFlights;
        var deferred = $q.defer();
        $timeout(function () { deferred.resolve(results); }, Math.random() * 1000, false);
        return deferred.promise;
    }

    function createFilterForInvoicesByCode(query) {
        var lowercaseQuery = angular.uppercase(query);
        return function filterFn(aa) {
            if (aa.InvoiceCode != null)
                return (aa.InvoiceCode.indexOf(lowercaseQuery) != -1);
            else
                return false;
        };
    }

    // Bank Branche Accounts Functions
    $scope.getBanks = function () {
        $http.get('/Accounting/Banks/getBanks').success(function (results) {
            $scope.Banks = results;
            for (var i = 0; i < $scope.Banks.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Banks[i].Title = $scope.Banks[i].NameAr;
                }
                else {
                    $scope.Banks[i].Title = $scope.Banks[i].NameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.getBankBranches = function (id) {
        if (id != undefined) {
            $http.get('/Accounting/BankBranches/getBankBranchesByBankID/' + id).success(function (results) {
                $scope.BankBranches = results;
                for (var i = 0; i < $scope.BankBranches.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.BankBranches[i].Title = $scope.BankBranches[i].NameAr;
                    }
                    else {
                        $scope.BankBranches[i].Title = $scope.BankBranches[i].NameEn;
                    }
                }
                $scope.BranchID = null;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.getBankBranchAccounts = function (id) {
        if (id != undefined) {
            $http.get('/Accounting/BankBranchAccounts/getBankBranchAccountsByBankBranchID/' + id).success(function (results) {
                $scope.BankBranchAccounts = results;
                for (var i = 0; i < $scope.BankBranchAccounts.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameAr;
                    }
                    else {
                        $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameEn;
                    }
                }
                $scope.BranchID = null;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    //////////// get invoice by id
    function getSalesInvoiceIFlight(id) {
        $http.get('/accounting/SalesInvoiceIFlight/GetInvoiceByID/' + id).success(function (results) {
            $scope.SalesInvoiceIFlight = results;
            $scope.searchTextCustomerByCode = $scope.SalesInvoiceIFlight.CustomerCode;
            $scope.searchTextCustomerByName = $scope.SalesInvoiceIFlight.CustomerNameAr;
            $scope.searchTextContractByCode = $scope.SalesInvoiceIFlight.IFlightContractNumber;

            $scope.getBanks();
            $scope.getBankBranches($scope.SalesInvoiceIFlight.BankID);
            $scope.getBankBranchAccounts($scope.SalesInvoiceIFlight.BankBranchID);

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    ////// get max code
    function getLastCodeSalesInvoiceIFlight() {
        $http.get('/accounting/SalesInvoiceIFlight/GetLastCodeInvoices').success(function (results) {
            $scope.SalesInvoiceIFlight.InvoiceCode = results;
            //$scope.SalesInvoiceIFlight.SalesInvoiceIFlightDate = new Date();;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    ///// when add
    $scope.showAdvancedAdd = function (ev) {
        HideMasterShowDetails("#DivShow", "#DivSave");

        getLastCodeSalesInvoiceIFlight();
    };

    ////// get flight selected from modal
    $scope.getFlightModal = function (modal) {
        //for (i = 0; i < modal.length; i++) {

        if (modal.SectorID !== null) {
            var item = {};
            item.IFlightSectorID = modal.SectorID;
            item.SectorDate = modal.sectordate;
            item.SectorNumber = modal.FlightNo;
            item.Route = modal.Route;

            var foundItem = $filter('filter')($scope.SalesInvoiceIFlightDetails, { SectorNumber: modal.FlightNo }, true)[0];

            if (foundItem == undefined) {
                $scope.SalesInvoiceIFlightDetails.push(item);
            }
        }

        //}
    };

    ////// get flights at modal
    $scope.getAllFlightsModal = function (IFlightCustomerID, DateFrom, DateTo) {

        if (IFlightCustomerID == undefined)
            IFlightCustomerID = 0;

        if (DateFrom == undefined)
            DateFrom = "";

        if (DateTo == undefined)
            DateTo = "";

        //var parms = {
        //    ClientID: IFlightCustomerID,
        //    FromDate: DateFrom,
        //    ToDate: DateTo
        //}

        //$http.get('/accounting/SalesInvoiceIFlight/GetFlightsDetail', { ClientID: IFlightCustomerID, FromDate: DateFrom, ToDate: DateTo }).success(function (results) {
        //$http.get('/accounting/SalesInvoiceIFlight/GetFlightsDetail', parms).success(function (results) {
        $http.get('/accounting/SalesInvoiceIFlight/GetFlightsDetail?ClientID=' + IFlightCustomerID + '&FromDate=' + DateFrom + '&ToDate=' + DateTo).success(function (results) {
            $scope.Flights = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    /////// show flights modal
    $scope.showFlightsAdd = function (ev) {
        $scope.getAllFlightsModal($scope.selectedCustomer.IFlightCustomerID, $scope.SalesInvoiceIFlight.DateFrom, $scope.SalesInvoiceIFlight.DateTo);

        //$scope.GetTopFlights("");

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/LoadFlights.tmpl.html',
            onRemoving: function () {
                $scope.cancelFlight();
            },
            clickOutsideToClose: true,
            openFrom: '.addFlight',
            closeTo: '.addFlight'
        })

    };

    ///// hide flights modal
    $scope.hide = function () {
        $mdDialog.hide();
        $scope.SalesInvoiceIFlight = {};
    };

    ///// cancel modal
    $scope.cancelDialog = function () {
        $mdDialog.cancel();
    };

    //////// cancel edit mode
    $scope.cancelFlight = function () {
        //$scope.AddNew = true;
        $mdDialog.cancel();
        $scope.selectedFlight = [];
    };

    $scope.cancelSalesInvoiceIFlight = function () {
        //   $mdDialog.cancel();
        HideMasterShowDetails("#DivSave", "#DivShow");

        $scope.SalesInvoiceIFlight = {};
        $scope.SalesInvoiceIFlightDetails = [];

    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };

    $scope.save = function () {
        $scope.SalesInvoiceIFlight.SalesInvoiceIFlightDetails = $scope.SalesInvoiceIFlightDetails;

        if ($scope.selectedCustomer != null)
            $scope.SalesInvoiceIFlight.CustomerID = $scope.selectedCustomer.CustID;

        if ($scope.selectedContract != null) {
            $scope.SalesInvoiceIFlight.IFlightContractID = $scope.selectedContract.ClientContractsID;
            $scope.SalesInvoiceIFlight.IFlightContractNumber = $scope.selectedContract.ContractCode;
            $scope.SalesInvoiceIFlight.PricePerHour = $scope.selectedContract.PricePerHour;
        }

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.SalesInvoiceIFlight),
            url: '/accounting/SalesInvoiceIFlight/save',
            success: function (result) {
                //$scope.checkReport(result);
                $rootScope.$emit("swAlertSave", {});
                $scope.cancelSalesInvoiceIFlight();
                getSalesInvoiceIFlights();
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.delete = function (id) {
        remove(id);
        //getInvoices();
    }

    function remove(InvoiceID) {
        swConfirmDeleteAr(
            {
                function () {
                    $http.get('/SalesInvoiceIFlight/delete/' + InvoiceID).success(function (results) {

                        if (parseInt(results) == -1) {
                            $rootScope.$emit("swAlertSorry", {});
                        }
                        else {
                            getSalesInvoiceIFlights();
                        }

                        $scope.selected = [];

                    }).error(function (data, status, headers, config) {
                        swAlertErrorAr();
                    });
                }
            }

        //return deferred.promise;
        );
    }

    function getDetails(SalesInvoiceIFlightID) {
        $http.get('/accounting/SalesInvoiceIFlight/GetDetailsByInvoiceID/' + SalesInvoiceIFlightID).success(function (results) {
            $scope.SalesInvoiceIFlightDetails = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.edit = function (SalesInvoiceIFlightID) {
        getSalesInvoiceIFlight(SalesInvoiceIFlightID);
        getDetails(SalesInvoiceIFlightID);
        HideMasterShowDetails("#DivShow", "#DivSave");

    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';
        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.removeFilterFlight = function () {
        $scope.filtered.show = false;
        $scope.query.filtered = '';

        if ($scope.filtered.form.$dirty) {
            $scope.filtered.form.$setPristine();
        }
    };

    $scope.removeFilterDetails = function () {
        $scope.filterDetail.show = false;
        $scope.query.filterDetails = '';

        if ($scope.filterDetail.form.$dirty) {
            $scope.filterDetail.form.$setPristine();
        }
    }

    $scope.limitOptions = [5, 10, 15];

    $scope.options = {
        pageSelect: true
    };

    $scope.query = {
        SalesInvoiceIFlight: 'name',
        filter: '',
        filterDetails: '',
        filterExpense: '',
        filterAttachment: '',

        limit: 5,
        page: 1
    };

    $scope.deleteDetails = function (model) {
        swConfirmDeleteAr(
            {
                function () {

                    if (model.SalesInvoiceIFlightDetailID != undefined) {
                        $http.get('/accounting/SalesInvoiceIFlight/deleteDetails/' + model.SalesInvoiceIFlightDetailID).success(function (results) {
                        });
                    }

                    $scope.SalesInvoiceIFlightDetails.splice($.inArray(model, $scope.SalesInvoiceIFlightDetails), 1);
                    $scope.$apply();

                    $scope.selectedDetails = [];

                }
            }
        );
    }

    /////// Change sector status to cancel
    $scope.CancelSector = function (item) {

        if ($cookies.get('ERP_lang') == 'ar-EG') {
            $rootScope.$emit("swConfirmAction", {
                text: "هل تريد الغاء الفاتوره ؟", function () {
                    $http.post('/accounting/SalesInvoiceIFlight/CancelSector?SalesInvoiceIFlightDetailID=' + item.SalesInvoiceIFlightDetailID).success(function (results) {

                        if (parseInt(results) == -1) {
                            $rootScope.$emit("swAlertSorry", {});
                        }
                        else {
                            $rootScope.$emit("swAlertSave", {});
                            $scope.getSalesInvoiceIFlightAll();
                        }

                        $scope.selected = [];

                    }).error(function (data, status, headers, config) {
                        swAlertErrorAr();
                    });
                }


            }

        );
        }
        else {
            $rootScope.$emit("swConfirmAction", {
                text: "Are you need to Cancel this invoice ?", function () {
                    $http.post('/accounting/SalesInvoiceIFlight/CancelSector?SalesInvoiceIFlightDetailID =' + item.SalesInvoiceIFlightDetailID).success(function (results) {

                        if (parseInt(results) == -1) {
                            $rootScope.$emit("swAlertSorry", {});
                        }
                        else {
                            $rootScope.$emit("swAlertSave", {});
                            $scope.getSalesInvoiceIFlightAll();
                        }

                        $scope.selected = [];

                    }).error(function (data, status, headers, config) {
                        swAlertErrorAr();
                    });
                }


            }

        );
        }
    }

    /////// Change sector status to Confirm
    $scope.ApproveSector = function (item) {

        if ($cookies.get('ERP_lang') == 'ar-EG') {
            $rootScope.$emit("swConfirmAction", {
                text: "هل تريد تاكيد الفاتوره ؟", function () {
                    $http.post('/accounting/SalesInvoiceIFlight/ConfirmSector?SalesInvoiceIFlightDetailID=' + item.SalesInvoiceIFlightDetailID + '&IFlightSectorID=' + item.IFlightSectorID + '&PricePerHour=' + item.PricePerHour).success(function (results) {

                        if (parseInt(results) == -1) {
                            $rootScope.$emit("swAlertSorry", {});
                        }
                        else {
                            $rootScope.$emit("swAlertSave", {});
                            $scope.getSalesInvoiceIFlightAll();
                        }

                        $scope.selected = [];

                    }).error(function (data, status, headers, config) {
                        swAlertErrorAr();
                    });
                }


            }

        );
        }
        else {
            $rootScope.$emit("swConfirmAction", {
                text: "Are you need to Confirm this invoice ?", function () {
                    $http.post('/accounting/SalesInvoiceIFlight/ConfirmSector?SalesInvoiceIFlightDetailID=' + item.SalesInvoiceIFlightDetailID + '&IFlightSectorID=' + item.IFlightSectorID + '&PricePerHour=' + item.PricePerHour).success(function (results) {

                        if (parseInt(results) == -1) {
                            $rootScope.$emit("swAlertSorry", {});
                        }
                        else {
                            $rootScope.$emit("swAlertSave", {});
                            $scope.getSalesInvoiceIFlightAll();
                        }

                        $scope.selected = [];

                    }).error(function (data, status, headers, config) {
                        swAlertErrorAr();
                    });
                }

            }

        );
        }
    }

    $scope.showSectorInfoDialog = function (IFlightSectorID) {

        $scope.GetSectorInfoBySectorID(IFlightSectorID);

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/SectorInfo.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })
    };

    //$scope.checkReport = function (SalesInvoiceIFlightID) {

    //    if (SalesInvoiceIFlightID != undefined) {

    //        var reportParams = {
    //            "Parms": {
    //                "SalesInvoiceIFlightID": SalesInvoiceIFlightID
    //            },
    //            "ReportName": "StockReport/SalesInvoiceIFlightReport.trdx"
    //        };

    //        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

    //            var x = window.open();
    //            x.document.open();
    //            x.document.write(results);
    //            x.document.close();
    //        })
    //    }
    //}

});