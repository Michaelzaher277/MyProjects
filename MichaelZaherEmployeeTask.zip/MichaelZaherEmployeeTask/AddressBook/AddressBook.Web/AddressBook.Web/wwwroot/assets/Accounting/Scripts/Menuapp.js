﻿var app = angular.module('menuApp', []);

app.controller('PermissionMenuController', function ($scope, $http) {    
    $scope.MenuItems = [];
    $scope.MenuPermission = {};
        
    
    $scope.LoadMenuItems = function () {
        $http.get('/Common/GetPermissionMenu').success(function (results) {            
            $scope.MenuItems = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });

    };
});

//angular.bootstrap(document.getElementById("divContainer"), ['MenuApp']);