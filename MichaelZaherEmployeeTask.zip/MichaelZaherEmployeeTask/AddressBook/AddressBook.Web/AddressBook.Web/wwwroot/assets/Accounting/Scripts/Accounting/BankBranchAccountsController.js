﻿angular.module('globalApp')
.controller('BankBranchAccountsController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $element,$filter) {
    // scope variables
    $scope.Banks = [];
    $scope.BankBranches = [];
    $scope.BankBranchAccounts = [];
    $scope.BankBranchAccount = {};
    $scope.Currencies = [];

    // functions to run on start
    getBanks();
    loadCurrencies();

    HideMasterShowDetails("#DivSave", "#DivShow");

    $scope.ChangeChecked = function () {
        if (!$scope.BankBranchAccount.ChooseAccount) {
            $scope.BankBranchAccount.ChartOfAccountID = null;
            $scope.BankBranchAccount.AccountCode = null;
            $scope.BankBranchAccount.ChartOfAccount_CashNameAr = ''

        }
    }

   // $scope.ChartOfAccounts = [];
    $scope.AddNewAutoTransactionSetting = function () {
        if ($scope.ChartOfAccounts.length <= 0) {
            $scope.getChartOfAccountTree();
        }
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        });
    }

    function getChartOfAccountTreeDetail() {
        $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
            $scope.ChartOfAccountsDetails = results.treeObj;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.selectNode = function (node) {
        $scope.ChartOfAccount = node.$modelValue;
    }

    $scope.findNodes = function (item) {
        $scope.ChartOfAccountsFilter = item.ChartOfAccountsFilter;
    };

    $scope.chooseChartOfAccount = function () {
        $scope.BankBranchAccount.ChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.BankBranchAccount.ChartOfAccount_CashNameAr = ($cookies.get('ERP_lang') == 'ar-EG') ? $scope.ChartOfAccount.AccountArabicName : $scope.ChartOfAccount.AccountEnglishName;
        $scope.BankBranchAccount.AccountCode = $scope.ChartOfAccount.AccountCode;
        $scope.cancelChartOfAccountsDialog();
    //    $scope.showAddDialog();


    };

    $scope.FilterChartOfAccounts = function (item) {
        return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
    };

    $scope.cancelChartOfAccountsDialog = function () {
        $mdDialog.cancel();
        //$scope.ChartOfAccount = { IsGroup: true };
        $scope.ChartOfAccountsFilter = "";
    };


    


    // md-table variables
    $scope.selected = [];
    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };

    // Bank Branches Functions
    function loadCurrencies() {
        if ($scope.Currencies.length <= 0) {
            $http.get('/Accounting/Currency/GetCurrencies').success(function (results) {
                $scope.Currencies = results;
                for (var i = 0; i < $scope.Currencies.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                    }
                    else {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                    }
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    }
    function getBanks() {
        $http.get('/Accounting/Banks/getBanks').success(function (results) {
            $scope.Banks = results;
            for (var i = 0; i < $scope.Banks.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Banks[i].Name = $scope.Banks[i].NameAr;
                }
                else {
                    $scope.Banks[i].Name = $scope.Banks[i].NameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.getBankBranches = function () {
        if ($scope.BankID != undefined) {
            $http.get('/Accounting/BankBranches/getBankBranchesByBankID/' + $scope.BankID).success(function (results) {
                $scope.BankBranches = results;
                for (var i = 0; i < $scope.BankBranches.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.BankBranches[i].Name = $scope.BankBranches[i].NameAr;
                    }
                    else {
                        $scope.BankBranches[i].Name = $scope.BankBranches[i].NameEn;
                    }
                }
                $scope.BranchID = null;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };
    $scope.getBankBranchAccounts = function () {
        $http.get('/Accounting/BankBranchAccounts/getBankBranchAccountsByBankBranchID/' + $scope.BranchID).success(function (results) {
            $scope.BankBranchAccounts = results;
            for (var i = 0; i < $scope.BankBranchAccounts.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.BankBranchAccounts[i].CurrencyName = $scope.BankBranchAccounts[i].CurrencyNameAr;
                }
                else {
                    $scope.BankBranchAccounts[i].CurrencyName = $scope.BankBranchAccounts[i].CurrencyNameEn;
                }
            }
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.edit = function (selectedModel) {

        $scope.BankBranchAccount = selectedModel;

        $scope.BankBranchAccount.ChooseAccount = ($scope.BankBranchAccount.ChartOfAccount_Cash > 0);

        //if ($scope.ChartOfAccounts.length <= 0 || $scope.ChartOfAccounts == undefined) {
        //    $scope.getChartOfAccountTree();
        //}

        //var account = $scope.ChartOfAccounts.filter(function (Account) {
        //    return Account.ChartOfAccountID == $scope.BankBranchAccount.ChartOfAccount_Cash;
        //});

        //$scope.BankBranchAccount.ChartOfAccount_CashNameAr = ($cookies.get('ERP_lang') == 'ar-EG') ? account.AccountArabicName : account.AccountEnglishName;

        //   $scope.showEditDialog();

        HideMasterShowDetails("#DivShow", "#DivSave");

    };

    //$scope.showEditDialog = function (ev) {
    //    $mdDialog.show({
    //        scope: $scope.$new(),
    //        templateUrl: '../../Areas/accounting/templates/BankBranchAccount.tmpl.html',
    //        onRemoving: function () {
    //            //$scope.cancel();
    //            //$mdDialog.cancel();
    //        },
    //        clickOutsideToClose: true,
    //        openFrom: '.editButton',
    //        closeTo: '.editButton'
    //    })
    //};

    $scope.showAddDialog = function (ev) {
        //$mdDialog.show({
        //    scope: $scope.$new(),
        //    templateUrl: '../../Areas/accounting/templates/BankBranchAccount.tmpl.html',
        //    onRemoving: function () {
        //     //   $scope.cancel();
        //    },
        //    clickOutsideToClose: true,
        //    openFrom: '.AddButton',
        //    closeTo: '.AddButton'
        //})
        HideMasterShowDetails("#DivShow", "#DivSave");

    };

    $scope.save = function () {
        $scope.BankBranchAccount.BankBranchID = $scope.BranchID;
        $http.post('/Accounting/BankBranchAccounts/save', $scope.BankBranchAccount).success(function () {
            $scope.cancel();
            $rootScope.$emit("swAlertSave", {});
            HideMasterShowDetails("#DivSave", "#DivShow");

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.delete = function () {
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Accounting/BankBranchAccounts/delete', JSON.stringify($scope.selected)).success(function () {
                       $scope.getBankBranchAccounts();
                       $scope.selected = [];
                   });
               }
           });
    }

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.selected = [];
        $scope.BankBranchAccount = {};
        $scope.getBankBranchAccounts();
        HideMasterShowDetails("#DivSave", "#DivShow");
    };

});