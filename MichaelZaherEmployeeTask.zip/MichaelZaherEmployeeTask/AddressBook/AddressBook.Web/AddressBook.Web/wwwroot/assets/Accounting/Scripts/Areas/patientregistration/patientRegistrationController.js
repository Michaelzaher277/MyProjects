﻿angular.module('globalApp').requires.push('mdSteppers');
angular.module('globalApp')
.controller('patientRegistrationController', function ($scope, $http, $cookies, $mdStepper, $rootScope) {
   
    $scope.Patient = {};
    $scope.Genders = [];
    $scope.IDTypes = [];
    $scope.MaritalStatuses = [];
    $scope.Religions = [];
    $scope.RelationTypes = [];
    $scope.AllergyTypes = [];
    $scope.TelephoneTypes = [];
    $scope.Titles = [];
    $scope.arabicPattern = "^[\u0621-\u064A]+$";
    $scope.englishPattern = "^[a-zA-Z]+$";
    $scope.IDValidationPattern = "";
    $scope.PatientInsurances = [];
    $scope.PatientFamilyInfos = [];
    $scope.PatientSurgicalHistory = [];
    $scope.PatientAllergies = [];
    $scope.PatientChronicDiseases = [];

    init();

    function init()
    {
        var id = getParameterByName("pid");
        if (id != undefined)
        {
            editPatient(id);
        }
    }
    
    $scope.nextStepper = function () {
        var stepper = $mdStepper('stepperPatientRegistration');
        stepper.next();
    }

    $scope.moveToPreviousStep = function () {
        var stepper = $mdStepper('stepperPatientRegistration');
        stepper.back();
    }

    $scope.changeIDPattern = function () {
        $scope.IDValidationPattern = $scope.Patient.IDType.ValidationExpression;
    };

    $scope.changeIDPatternForFamily = function (item) {
        item.IDValidationPattern = item.IDType.ValidationExpression;
    };    

    $scope.loadGenders = function () {
        $http.get('/Administration/Gender/getGenders').success(function (results) {
            $scope.Genders = results;
            for (var i = 0; i < $scope.Genders.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Genders[i].Title = $scope.Genders[i].AR_Name;
                }
                else {
                    $scope.Genders[i].Title = $scope.Genders[i].EN_Name;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.loadIDTypes = function () {
        $http.get('/Administration/IDType/getIDTypes').success(function (results) {
            $scope.IDTypes = results;
            for (var i = 0; i < $scope.IDTypes.length; i++)
            {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.IDTypes[i].Title = $scope.IDTypes[i].AR_Name;
                }
                else {
                    $scope.IDTypes[i].Title = $scope.IDTypes[i].EN_Name;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.loadMaritalStatuses = function () {
        $http.get('/Administration/MaritalStatus/getMaritalStatuses').success(function (results) {
            $scope.MaritalStatuses = results;
            for (var i = 0; i < $scope.MaritalStatuses.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MaritalStatuses[i].Title = $scope.MaritalStatuses[i].AR_Name;
                }
                else {
                    $scope.MaritalStatuses[i].Title = $scope.MaritalStatuses[i].EN_Name;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.loadReligions = function () {
        $http.get('/Administration/Religion/getReligions').success(function (results) {
            $scope.Religions = results;
            for (var i = 0; i < $scope.Religions.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Religions[i].Title = $scope.Religions[i].AR_Name;
                }
                else {
                    $scope.Religions[i].Title = $scope.Religions[i].EN_Name;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.loadTelephoneTypes = function () {
        $http.get('/Administration/TelephoneType/getTelephoneTypes').success(function (results) {
            $scope.TelephoneTypes = results;
            for (var i = 0; i < $scope.TelephoneTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.TelephoneTypes[i].Title = $scope.TelephoneTypes[i].AR_Name;
                }
                else {
                    $scope.TelephoneTypes[i].Title = $scope.TelephoneTypes[i].EN_Name;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.loadTitles = function () {
        $http.get('/Administration/Title/getTitles').success(function (results) {
            $scope.Titles = results;
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.loadRelationTypes = function () {
        $http.get('/Administration/RelationType/getRelationTypes').success(function (results) {
            $scope.RelationTypes = results;
            for (var i = 0; i < $scope.RelationTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.RelationTypes[i].Title = $scope.RelationTypes[i].AR_Name;
                }
                else {
                    $scope.RelationTypes[i].Title = $scope.RelationTypes[i].EN_Name;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.loadAllergyTypes = function () {
        $http.get('/Administration/AllergyType/getAllergyTypes').success(function (results) {
            $scope.AllergyTypes = results;
            for (var i = 0; i < $scope.AllergyTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.AllergyTypes[i].Title = $scope.AllergyTypes[i].AR_Name;
                }
                else {
                    $scope.AllergyTypes[i].Title = $scope.AllergyTypes[i].EN_Name;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.addPatientInsurance = function () {
        $scope.PatientInsurances.push({ PatientInsuranceID: 0 });        
    }

    $scope.removePatientInsurance = function (model) {
        $scope.PatientInsurances.splice($.inArray(model, $scope.PatientInsurances), 1);
    }

    $scope.addFamilyInfo = function () {
        $scope.PatientFamilyInfos.push({ PatientFamilyMemberID: 0 });
    }

    $scope.removeFamilyInfo = function (model) {
        $scope.PatientFamilyInfos.splice($.inArray(model, $scope.PatientFamilyInfos), 1);
    }

    $scope.addPatientSurgicalHistory = function () {
        $scope.PatientSurgicalHistory.push({ PatientSurgicalHistoryID: 0 });
    }

    $scope.removePatientSurgicalHistory = function (model) {
        $scope.PatientSurgicalHistory.splice($.inArray(model, $scope.PatientSurgicalHistory), 1);
    }

    $scope.addPatientAllergy = function () {
        $scope.PatientAllergies.push({ PatientAllergyID: 0 });
    }

    $scope.removePatientAllergy = function (model) {
        $scope.PatientAllergies.splice($.inArray(model, $scope.PatientAllergies), 1);
    }

    $scope.addPatientChronicDisease = function () {
        $scope.PatientChronicDiseases.push({ PatientChronicDiseaseID: 0 });
    }

    $scope.removePatientChronicDisease = function (model) {
        $scope.PatientChronicDiseases.splice($.inArray(model, $scope.PatientChronicDiseases), 1);
    }

    $scope.savePatient = function () {
        $scope.Patient.PatientAllergies = $scope.PatientAllergies;
        $scope.Patient.PatientInsurances = $scope.PatientInsurances;
        $scope.Patient.PatientFamilyMembers =  $scope.PatientFamilyInfos;
        $scope.Patient.PatientSurgicalHistories = $scope.PatientSurgicalHistory;
        $scope.Patient.PatientChronicDiseases = $scope.PatientChronicDiseases;
        $http.post('/Patient/PatientRegistration/savePatient', $scope.Patient).success(function (results) {
            $rootScope.$emit("swAlertSave", {});
            
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function editPatient(PatientID)
    {        
        $http.get('/Patient/PatientRegistration/getPatientByID/' + PatientID).success(function (results) {
            $scope.Patient = results;
            getInsurances($scope.Patient.PatientID);
            getAllergies($scope.Patient.PatientID);
            getChronicDiseases($scope.Patient.PatientID);
            getSurgicalHistory($scope.Patient.PatientID);
            getFamilyMembers($scope.Patient.PatientID);
        }).error(function () {
            swAlertErrorAr();
        });        
    }

    function getInsurances(PatientID) {
        $http.get('/Patient/PatientInsurance/getPatientInsurancesByPatientID/' + PatientID).success(function (results) {
            $scope.PatientInsurances = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function getAllergies(PatientID) {
        $http.get('/Patient/PatientAllergy/getPatientAllergiesByPatientID/' + PatientID).success(function (results) {
            $scope.PatientAllergies = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function getChronicDiseases(PatientID) {
        $http.get('/Patient/PatientChronicDisease/getPatientChronicDiseasesByPatientID/' + PatientID).success(function (results) {
            $scope.PatientChronicDiseases = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function getSurgicalHistory(PatientID) {
        $http.get('/Patient/PatientSurgicalHistory/getPatientSurgicalHistoryByPatientID/' + PatientID).success(function (results) {
            $scope.PatientAllergies = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function getFamilyMembers(PatientID) {
        $http.get('/Patient/PatientFamilyMember/getPatientFamilyMembersByPatientID/' + PatientID).success(function (results) {
            $scope.PatientAllergies = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
});