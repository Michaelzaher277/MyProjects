﻿angular.module('globalApp')
.controller('BanksController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $element) {
    // scope variables
    $scope.Banks = [];
    $scope.Bank = {};

    // functions to run on start
    getBanks();

    // md-table variables
    $scope.selected = [];
    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };

    // Bank functions
    function getBanks() {
        $http.get('/Accounting/Banks/getBanks').success(function (results) {
            $scope.Banks = results;
            for (var i = 0; i < $scope.Banks.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Banks[i].Name = $scope.Banks[i].NameAr;
                }
                else {
                    $scope.Banks[i].Name = $scope.Banks[i].NameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.edit = function (selectedModel) {
        $scope.Bank = selectedModel;
        $scope.showEditDialog();
    };
    $scope.showEditDialog = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Banks.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })
    };
    $scope.showAddDialog = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Banks.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.AddButton',
            closeTo: '.AddButton'
        })
    };
    $scope.save = function () {
        $http.post('/Accounting/Banks/save', $scope.Bank).success(function () {
            $scope.cancel();
            $rootScope.$emit("swAlertSave", {});
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.delete = function () {
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Accounting/Banks/delete', JSON.stringify($scope.selected)).success(function () {
                       getBanks();
                       $scope.selected = [];
                   });
               }
           });
    }
    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.selected = [];
        $scope.Bank = {};
        getBanks();
    };
});