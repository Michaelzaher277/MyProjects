﻿angular.module('globalApp')
.controller('CustomerSalesWithProductReportController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter, $element) {
    
    $scope.model = {};

    //$scope.Products = [];

    $scope.showProductsAdd = function (ev) {
        $scope.getAllProductsModal();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/Inventory/templates/LoadProducts.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.adddProduct',
            closeTo: '.adProduct'
        })

    };

    $scope.cancelProduct = function () {
        $mdDialog.cancel();
        $scope.selectedProduct = [];
    };

    $scope.getAllProductsModal = function () {
        $http.get('/Inventory/ProductDetails/GetProducts').success(function (results) {
            $scope.Products = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    }

    $scope.getProductModal = function (modal) {
        //for (i = 0; i < modal.length; i++) {
        if (modal[0].ProductID != null) {
            //var item = {};
            //item.ProductID = modal[i].ProductID;
            //item.ProductName = modal[i].NameAr;
            //item.ProductCode = modal[i].Code;
            //item.MeasureUnits = modal[i].MeasureUnits;

            //$scope.Purchase_OrderDetails.push(item);

            $scope.Product = modal[0];

            $scope.model.ProductID = $scope.Product.ProductID;

            if ($cookies.get('ERP_lang') == 'ar-EG') {
                $scope.model.ProductName = $scope.Product.NameAr;
            }
            else {
                $scope.model.ProductName = $scope.Product.NameEn;
            }

        }
        //}

        $scope.cancelProduct();

        // $('#DivParts').modal('toggle');
    };

    $scope.checkReport = function (model) {

        if ($scope.model.ProductID != undefined) {


        }
        else {
            $scope.model.ProductID = 0;
            $scope.model.ProductName = '';
        }

        var 
            reportParams = {
                "Parms": { "DateFrom": $filter('date')(model.DateFrom, "yyyy-MM-dd"), "DateTo": $filter('date')(model.DateTo, "yyyy-MM-dd")
                    , "ProductName": $scope.model.ProductName, "ProductID": $scope.model.ProductID},
                "ReportName": "SalesReport/CustomerSalesWithProductReport.trdx"
        };

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();
        })
    }

    $scope.clearFields = function () {
        $scope.model = {};        
    }

});