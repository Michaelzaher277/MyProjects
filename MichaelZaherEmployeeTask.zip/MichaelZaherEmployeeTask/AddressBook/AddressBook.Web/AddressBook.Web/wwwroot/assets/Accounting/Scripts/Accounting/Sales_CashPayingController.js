﻿angular.module('globalApp')
.controller('Sales_CashPayingController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $element) {

    $scope.Sales_CashPaying = {};
    $scope.Sales_Invoices = [];
    $scope.Sales_InvoicesSelected = [];

    $scope.Customers = [];
    $scope.searchTerm = "";
    $scope.SelectedCustomerID = 0;

    $scope.clearSearchTerm = function () {
        $scope.searchTerm = "";
        getAvailableSales_Invoices();
    };

   // getAvailableSales_Invoices();

    $element.find('input#searchCustomers').on('keydown', function (ev) {
        ev.stopPropagation();
    });

    $scope.SearchCustomers = function ($event) {
        
        $http.get('/Administration/Customer/GetCustomers/').success(function (results) {
            $scope.Customers = results;
            for (var i = 0; i < $scope.Customers.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Customers[i].Title = $scope.Customers[i].NameAr;
                }
                else {
                    $scope.Customers[i].Title = $scope.Customers[i].NameEng;
                }
            }
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function clearFields() {
        $scope.Sales_CashPaying = {};
        $scope.Sales_InvoicesSelected = [];
    };

    $scope.getAvailableSales_Invoices = function () {
        $http.get('/Sales_Invoice/getUnPaidInvoicesByCustomerID/' + $scope.SelectedCustomerID).success(function (results) {
            $scope.Sales_Invoices = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    getInvoicePayments();
    $scope.PaymentTypes = [];
    function getInvoicePayments() {
        $http.get('/Sales_Invoice/getPaymentTypes').success(function (results) {
            $scope.PaymentTypes = results;
            for (var i = 0; i < $scope.PaymentTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameAr;
                }
                else {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.save = function () {
        if ($cookies.get('ERP_lang') == 'ar-EG') {
            $rootScope.$emit("swConfirmAction", {
                text: "هل تريد الدفع للفواتير المختارة", function () {
                    $.each($scope.Sales_Invoices, function (i, item) {
                        if (item.IsSelected) {
                            $scope.Sales_InvoicesSelected.push(item);
                        }
                    });
                    var parms = {
                        salesInvoices: $scope.Sales_InvoicesSelected,
                        cashPaying: $scope.Sales_CashPaying
                    }
                    $.ajax({
                        type: 'POST',
                        contentType: 'application/json; charset=utf-8',
                        data: JSON.stringify(parms),
                        url: '/Sales_CashPaying/PaySalesInvoices',
                        success: function (result) {
                            $scope.Sales_CashPaying = result;
                            recordPaymentAutoTransaction($scope.Sales_CashPaying);
                        },
                        error: function () {
                            $rootScope.$emit("swAlertError", {});
                        }
                    });
                }
            });
        }
        else {
            $rootScope.$emit("swConfirmAction", {
                text: "Are you need to pay selected invoices ?", function () {
                    $.each($scope.Sales_Invoices, function (i, item) {
                        if (item.IsSelected) {
                            $scope.Sales_InvoicesSelected.push(item);
                        }
                    });
                    var parms = {
                        salesInvoices: $scope.Sales_InvoicesSelected,
                        cashPaying: $scope.Sales_CashPaying
                    }
                    $.ajax({
                        type: 'POST',
                        contentType: 'application/json; charset=utf-8',
                        data: JSON.stringify(parms),
                        url: '/Sales_CashPaying/PaySalesInvoices',
                        success: function (result) {
                            $scope.Sales_CashPaying = result;
                            recordPaymentAutoTransaction($scope.Sales_CashPaying);
                        },
                        error: function () {
                            $rootScope.$emit("swAlertError", {});
                        }
                    });

                }
            });
        }
    };

    $scope.cancel = function()
    {
        clearFields();
        getAvailableSales_Invoices();
    }

    $scope.select = function (model) {
        model.IsSelected = true;
    }

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';
        $scope.SelectedCustomerID = 0;
        $scope.searchTerm = "";
        $scope.Customers = [];
        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
        getAvailableSales_Invoices();

    };

    function swPaymentDoneAr(remainingAmount) {
        if (remainingAmount == undefined) {
            remainingAmount = 0;
        }
        swal({
            title: 'تم الحفظ بنجاح!',
            text: 'باقى القيمة : ' + remainingAmount,
            type: 'success',
            showCancelButton: false,
            confirmButtonColor: '#BFBFBF',
            confirmButtonText: '<i class="fa fa-check"></i> تم',
        }).then(function () {
            clearFields();
            getAvailableSales_Invoices();
        })
    }

    function swPaymentDoneEn(remainingAmount) {
        if (remainingAmount == undefined) {
            remainingAmount = 0;
        }
        swal({
            title: 'Saved successfully!',
            text: 'Remaining Amount: ' + remainingAmount,
            type: 'success',
            showCancelButton: false,
            confirmButtonColor: '#BFBFBF',
            confirmButtonText: '<i class="fa fa-check"></i> Ok',
        }).then(function () {
            clearFields();
            getAvailableSales_Invoices();
        })
    }

    function recordPaymentAutoTransaction(CashPaying) {
        var Note;
        $http.post("/accounting/Sales_CashPaying/getCurrentNoteByCashPaying", CashPaying).success(function (result) {
            Note = result;
            recordAutoTransaction(CashPaying);
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });

        function recordAutoTransaction(CashPaying) {
            // get Customer Chart Of Account [not implemented yet]
            var data = {
                Amount: CashPaying.Amount,
                AutoTransactionOperationID: 2,
                CurrencyID: 1, // should be set dynamically based on the default currency for the account
                //FromID: $scope.Sales_Invoice.CurrencyID.CustomerID,
                PaymentTypeID: 1, // 1 for cash payments in PaymentType Table in DB
                currentDate: CashPaying.PaymentDate,
                Note: Note
            };

            $http.post("/accounting/DailyTransaction/saveAutoDailyTransaction", data).success(function () {
                swPaymentDoneAr($scope.Sales_CashPaying.RemainingAmount);
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    }
});