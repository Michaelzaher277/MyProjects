﻿angular.module('globalApp')
.controller('SearchController', function ($scope, $http, $cookies, $rootScope) {

    $scope.Patient = {};
    $scope.Patients = [];
    $scope.Genders = [];

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };

    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };

    $scope.loadGenders = function () {
        $http.get('/Administration/Gender/getGenders').success(function (results) {
            $scope.Genders = results;
            for (var i = 0; i < $scope.Genders.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Genders[i].Title = $scope.Genders[i].AR_Name;
                }
                else {
                    $scope.Genders[i].Title = $scope.Genders[i].EN_Name;
                }
            }
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.searchPatients = function () {
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({ query: $scope.PatientSearch, gender: $scope.PatientGender }),
            url: '/Patient/Search/searchPatients',
            success: function (data) {
                $scope.Patients = data;
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    }

    $scope.editPatient = function (PatientID) {
        window.location.href = "../../../Patient/patientRegistration?pid=" + PatientID;
    }

    function getPatientHistory(PatientID) {

    };
});