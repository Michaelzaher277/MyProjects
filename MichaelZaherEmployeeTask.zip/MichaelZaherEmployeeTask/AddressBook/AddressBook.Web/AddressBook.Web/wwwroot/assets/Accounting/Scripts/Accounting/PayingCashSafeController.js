﻿
angular.module('globalApp')
    .controller('PayingCashSafeController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter) {
        // Daily Transaction Variables
        $scope.PayingCashSafes = [];
        $scope.PayingCashSafe = {};

        $scope.PayingCashSafeDetails = [];
        $scope.PayingCashSafeDetail = {};

        $scope.TotalDepit = 0;
        $scope.TotalCredit = 0;
        $scope.PayingCashSafeSearch = "";
        $scope.Receipt = {};
        $scope.SelectedCustomer = {};

        $scope.AddNew = false;
        $scope.ShowPrint = false;
        $scope.SelectedSupplier = {};

        // ddl variables
        $scope.Currencies = [];
        $scope.Currency = {};
        $scope.ChartOfAccounts = [];
        $scope.TransactionTypes = [];
        //$scope.ChartOfAccount = { IsGroup: true };
        $scope.ChartOfAccountsFilter = "";

        $scope.Safe = {};
        //$scope.PayingCashSafes = [];
        $scope.selected = [];

        // run at startup
        loadCurrencies();
        $scope.getChartOfAccountTree();
        getReceiptLogs();

        function getReceiptLogs() {
            $http.get('/PayingCashSafe/getReceiptLogs').success(function (results) {
                $scope.PayingCashSafes = results;

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };
        // ---------------------------------- this fuctions transfer to app.js ------------------------------------
        //function getChartOfAccountTree() {
        //    $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
        //        $scope.ChartOfAccounts = results.treeObj;
        //    }).error(function () {
        //        $rootScope.$emit("swAlertError", {});
        //    });
        //};

        $scope.AddNewAutoTransactionSetting = function () {
            if ($scope.ChartOfAccounts.length <= 0) {
                $scope.getChartOfAccountTree();
            }
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
                onRemoving: function () {
                    $scope.cancelChartOfAccountsDialog();
                },
                clickOutsideToClose: true,
                openFrom: '.addButton',
                closeTo: '.addButton'
            });
        }

        function getChartOfAccountTreeDetail() {
            $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
                $scope.ChartOfAccountsDetails = results.treeObj;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };

        $scope.selectNode = function (node) {
            $scope.ChartOfAccount = node.$modelValue;
        }

        $scope.findNodes = function (item) {
            $scope.ChartOfAccountsFilter = item.ChartOfAccountsFilter;
        };

        $scope.chooseChartOfAccount = function () {
            $scope.PayingCashSafe.ChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
            $scope.PayingCashSafe.ChartOfAccount_CashNameAr = ($cookies.get('ERP_lang') == 'ar-EG') ? $scope.ChartOfAccount.AccountArabicName : $scope.ChartOfAccount.AccountEnglishName;
            $scope.PayingCashSafe.AccountCode = $scope.ChartOfAccount.AccountCode;
            $scope.cancelChartOfAccountsDialog();
        };

        $scope.FilterChartOfAccounts = function (item) {
            return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
        };

        $scope.cancelChartOfAccountsDialog = function () {
            $mdDialog.cancel();
            $scope.ChartOfAccount = { IsGroup: true };
            $scope.ChartOfAccountsFilter = "";
        };

        $scope.cancel = function () {
            //   $mdDialog.cancel();

            //$scope.AddNew = false;

            HideMasterShowDetails('#DivSave', '#DivShow');

            $scope.PayingCashSafe = {};
            $scope.selected = [];

            $scope.PayingCashSafeDetails = [];
            $scope.PayingCashSafeDetail = {};
        };

        $scope.showAdvancedAdd = function (ev) {
            //  $("DivShow)

            //$scope.AddNew = true;

            HideMasterShowDetails('#DivShow', '#DivSave');
            $scope.getChartOfAccountTree();

            // $scope.getShipping_Ways();
            //$scope.getAllProductsModal();

        };
        $scope.removeFilter = function () {
            $scope.filter.show = false;
            $scope.query.filter = '';

            if ($scope.filter.form.$dirty) {
                $scope.filter.form.$setPristine();
            }
        };

        $scope.limitOptions = [5, 10, 15];
        $scope.options = {
            pageSelect: true
        };
        $scope.query = {
            Invoice: 'name',
            filter: '',
            limit: 5,
            page: 1
        };

        $scope.getCurrency = function (CurrencyID) {
            $http.get('/Currency/getCurrencyByID?id=' + CurrencyID).success(function (data) {
                $scope.PayingCashSafe.Currency_Convert = data.ConvertValue;
            });
        };

        // Daily Transaction Functions
        $scope.save = function () {

            if ($scope.PayingCashSafe.group1 == 1) {
                $scope.PayingCashSafe.DepitAccountID = $scope.SelectedCustomer.ChartOfAccountID;
                $scope.Receipt.CustomerID = $scope.SelectedCustomer.CustID;
                $scope.PayingCashSafe.Note = " تم صرف مبلغ " + $scope.PayingCashSafe.Amount + " من العميل " + $scope.SelectedCustomer.NameAr;
            }
            else if ($scope.PayingCashSafe.group1 == 2) {
                $scope.PayingCashSafe.DepitAccountID = $scope.SelectedSupplier.ChartOfAccountID;
                $scope.Receipt.SupplierID = $scope.SelectedSupplier.supplierID;
                $scope.PayingCashSafe.Note = " تم صرف مبلغ " + $scope.PayingCashSafe.Amount + " من المورد " + $scope.SelectedSupplier.NameAr;
            }
            else if ($scope.PayingCashSafe.group1 == 3) {
                $scope.PayingCashSafe.DepitAccountID = $scope.PayingCashSafe.ChartOfAccountID;
                $scope.Receipt.ChartOfAccountID = $scope.PayingCashSafe.ChartOfAccountID;
                $scope.PayingCashSafe.Note = " تم صرف مبلغ " + $scope.PayingCashSafe.Amount + "  من حساب رقم " + $scope.PayingCashSafe.AccountCode;
            }

            $scope.PayingCashSafe.CreditAccountID = $scope.Safe.ChartOfAccount_Cash;
            $scope.Receipt.SafeID = $scope.Safe.SafeID;
            $scope.Receipt.Amount = $scope.PayingCashSafe.Amount;
            $scope.Receipt.CurrencyID = $scope.PayingCashSafe.CurrencyID;
            $scope.Receipt.Currency_Convert = $scope.PayingCashSafe.Currency_Convert;
            $scope.Receipt.ReceiptTypeID = 1;
            $scope.Receipt.ReceiptNumber = $scope.PayingCashSafe.ReceiptNumber;
            $scope.Receipt.ReceiptDate = $scope.PayingCashSafe.ReceiptDate;

            var params = {
                CustomDailyTransaction: $scope.PayingCashSafe,
                ReceiptLog: $scope.Receipt
            }

            $http.post("/Accounting/PayingCashSafe/saveTransaction", params).success(function (result) {
                //$http.post("/Accounting/PayingCashSafe/saveReceipt", $scope.Receipt).success(function () {

                $scope.checkReport(result);

                //$scope.PayingCashSafe = {};
                //$scope.Receipt = {};
                //$scope.SelectedSupplier = {};
                //$scope.SelectedCustomer = {};
                //$scope.ChartOfAccount = {};
                //$scope.PayingCashSafe.group1 = 0;
                //getReceiptLogs();
                $rootScope.$emit("swAlertSave", {});
                //$scope.AddNew = false;

                //});
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            })
        }

        // ddl Functions
        $scope.getSafes = function () {
            $http.get('Accounting/Transfer/GetALLSafes').success(function (results) {
                $scope.Safes = results;
                for (var i = 0; i < $scope.Safes.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Safes[i].Title = $scope.Safes[i].SafeNameAr;
                    }
                    else {
                        $scope.Safes[i].Title = $scope.Safes[i].SafeNameEn;
                    }
                }
            }).error(function (data, status, headers, config) {
                $rootScope.$emit("swAlertError", {});
            });
        };
        function loadCurrencies() {
            if ($scope.Currencies.length <= 0) {
                $http.get('/Accounting/Currency/GetCurrencies').success(function (results) {
                    $scope.Currencies = results;
                    for (var i = 0; i < $scope.Currencies.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                        }
                        else {
                            $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                        }
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        }

        $scope.getSuppliers = function (viewValue) {
            $http.get('/Administration/Supplier/GetSuppliers').success(function (results) {
                $scope.Suppliers = results;
                for (var i = 0; i < $scope.Suppliers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Suppliers[i].Title = $scope.Suppliers[i].NameAr;
                    }
                    else {
                        $scope.Suppliers[i].Title = $scope.Suppliers[i].NameEng;
                    }
                }
            }).error(function (data, status, headers, config) {
                $rootScope.$emit("swAlertError", {});
            });
        };

        $scope.searchTerm = '';
        $scope.clearSearchTerm = function () {
            $scope.searchTerm = '';
        };

        $scope.edit = function (ReceiptID) {
            loadCurrencies();
            $scope.getSafes();
            $http.get('/PayingCashSafe/getReceiptLogByID?id=' + ReceiptID).success(function (data) {

                $scope.PayingCashSafe = data;
                $scope.Receipt = data;

                $scope.Safe.SafeNameAr = $scope.PayingCashSafe.safeName;

                if ($scope.PayingCashSafe.CustomerID != null) {
                    $scope.loadCustomers();
                    $scope.SelectedCustomer.NameAr = $scope.PayingCashSafe.CustomerName;
                    $scope.PayingCashSafe.group1 = 1

                }
                else if ($scope.PayingCashSafe.SupplierID != null) {
                    $scope.getSuppliers();
                    $scope.SelectedSupplier.NameAr = $scope.PayingCashSafe.SupplierName;

                    $scope.PayingCashSafe.group1 = 2
                }
                else if ($scope.PayingCashSafe.ChartOfAccountID != null) {
                    $scope.getChartOfAccountTree();
                    $scope.PayingCashSafe.ChartOfAccount_CashNameAr = $scope.PayingCashSafe.AccountNameAr;
                    $scope.PayingCashSafe.group1 = 3
                }

                //$scope.AddNew = true;
                $scope.ShowPrint = true;

                HideMasterShowDetails('#DivShow', '#DivSave');

            });
        };

        $scope.loadCustomers = function () {
            $http.get('/Administration/Customer/GetCustomers').success(function (results) {
                $scope.Customers = results;
                for (var i = 0; i < $scope.Customers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Customers[i].Title = $scope.Customers[i].NameAr;
                    }
                    else {
                        $scope.Customers[i].Title = $scope.Customers[i].NameEng;
                    }
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });

        };

        $scope.checkReport = function (ReceiptLogID) {

            if (ReceiptLogID != undefined || $scope.Receipt.ReceiptLogID != undefined) {

                if ($scope.Receipt.ReceiptLogID != undefined)
                    ReceiptLogID = $scope.Receipt.ReceiptLogID;

                $http.get('/Currency/getCurrencyByID/' + $scope.PayingCashSafe.CurrencyID).success(function (data) {
                    $scope.Currency = data;

                    var AccountName = "";

                    if ($scope.PayingCashSafe.group1 == 1) {
                        AccountName = "(العميل)" + $scope.SelectedCustomer.NameAr;

                        $scope.PayingCashSafe.Note = " تم صرف مبلغ " + $scope.PayingCashSafe.Amount + " الى العميل " + $scope.SelectedCustomer.NameAr;
                    }
                    else if ($scope.PayingCashSafe.group1 == 2) {
                        AccountName = "(المورد)" + $scope.SelectedSupplier.NameAr;

                        $scope.PayingCashSafe.Note = " تم صرف مبلغ " + $scope.PayingCashSafe.Amount + " الى المورد " + $scope.SelectedSupplier.NameAr;
                    }
                    else if ($scope.PayingCashSafe.group1 == 3) {
                        AccountName = $scope.PayingCashSafe.ChartOfAccount_CashNameAr;
                        $scope.PayingCashSafe.Note = " تم صرف مبلغ " + $scope.PayingCashSafe.Amount + "  الى حساب رقم " + $scope.PayingCashSafe.AccountCode;
                    }

                    var reportParams = {
                        //"Parms": { "Title": "ايصال صرف نقدية من الخزنة","ReceiptDate": $scope.PayingCashSafe.ReceiptDate, "SafeName": $scope.Safe.SafeNameAr, "AccountName": AccountName, "Amount": $scope.PayingCashSafe.Amount, "Currency": $scope.Currency.NameAr, "Note": $scope.PayingCashSafe.Note },
                        "Parms": { "Title": "ايصال صرف نقدية من الخزنة", "ReceiptLogID": ReceiptLogID, "SafeName": $scope.Safe.SafeNameAr, "AccountName": AccountName, "Amount": $scope.PayingCashSafe.Amount, "Currency": $scope.Currency.NameAr, "Note": $scope.PayingCashSafe.Note },
                        "ReportName": "CashSafeReceipt.trdx"
                    };

                    //$("#reportTest").load('/report', JSON.stringify(reportParams));

                    $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

                        var x = window.open();
                        x.document.open();
                        x.document.write(results);
                        x.document.close();

                        //$('#reportTest').html(results);
                    })

                    //$scope.AddNew = false;
                    $scope.ShowPrint = false;

                    HideMasterShowDetails('#DivSave', '#DivShow');

                    $scope.PayingCashSafe = {};
                    $scope.Receipt = {};
                    $scope.SelectedSupplier = {};
                    $scope.SelectedCustomer = {};
                    $scope.ChartOfAccount = {};
                    $scope.PayingCashSafe.group1 = 0;
                    getReceiptLogs();
                    //$rootScope.$emit("swAlertSave", {});
                    $scope.AddNew = false;

                });

            }
        }


    });