﻿angular.module('globalApp')
.controller('AutoTransactionSettingController', function ($scope, $mdDialog, $http, $rootScope, $cookies) {

    // AutoTransactionSettings Variables
    $scope.AutoTransactionSettings = [];
    $scope.AutoTransactionSetting = {};

    $scope.AutoTransactionSettingDetails = [];
    $scope.AutoTransactionSettingDetail = {}; 

    // Setting selection variables
    $scope.selected = [];
    $scope.MasterSelected = [];     ////// setting master

    $scope.MasterLimitOptions = [5, 10, 15];

    $scope.MasterOptions = {
        pageSelect: true
    };

    $scope.MasterQuery = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1,
    };



    // Setting Detail selection variables
    $scope.DetailSelected = [];

    $scope.DetailLimitOptions = [5, 10, 15];
    $scope.DetailOptions = {
        pageSelect: true
    };

    $scope.DetailQuery = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1,
    };

    // ddl variables
    $scope.AutoTransactionOperations = [];
    $scope.AutoTransactionOperation = {};

    $scope.InvoiceTypes = [];

    // Account Setting
    $scope.ChartOfAccounts = [];
    
    //$scope.ChartOfAccount = { IsGroup: true };
    $scope.ChartOfAccountsFilter = "";

    // Account Setting Detail
    $scope.ChartOfAccountsDetails = [];

    //$scope.ChartOfAccountDetail = { IsGroup: true };
    $scope.ChartOfAccountsFilterDetail = "";


    // run at startup
    //loadInvoiceTypes();
    loadAutoTransactionOperations();

    function loadAutoTransactionOperations() {
        $http.get("/Accounting/AutoTransactionSetting/LoadAutoTransactionSettings")
            .success(function (result) {                
                $scope.AutoTransactionOperations = result;

                for (var i = 0; i < $scope.AutoTransactionOperations.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.AutoTransactionOperations[i].Name = $scope.AutoTransactionOperations[i].NameAr;
                        $scope.AutoTransactionOperations[i].DefaultNote = $scope.AutoTransactionOperations[i].DefaultNoteAr;
                    }
                    else {
                        $scope.AutoTransactionOperations[i].Name = $scope.AutoTransactionOperations[i].NameEn;
                        $scope.AutoTransactionOperations[i].DefaultNote = $scope.AutoTransactionOperations[i].DefaultNoteEn;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            })
    }

    // Chart Of Account Dialog Functions
    // -------------------------------- this function tranfer to app.js ---------------------------------------
    //function getChartOfAccountTree() {
    //    $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
    //        $scope.ChartOfAccounts = results.treeObj;
    //    }).error(function () {
    //        $rootScope.$emit("swAlertError", {});
    //    });
    //};    

    $scope.AddNewAutoTransactionSetting = function () {
        if ($scope.ChartOfAccounts.length <= 0) {
            $scope.getChartOfAccountTree();
        }
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        });
    }
   
    //function getChartOfAccountTreeDetail() {
    //    $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
    //        $scope.ChartOfAccountsDetails = results.treeObj;
    //    }).error(function () {
    //        $rootScope.$emit("swAlertError", {});
    //    });
    //};

    $scope.AddNewAutoTransactionSettingDetail = function () {

        $scope.getChartOfAccountTree('Detail');

        //if ($scope.ChartOfAccountsDetails.length <= 0) {
        //    $scope.getChartOfAccountTree('Detail');
        //}

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount2.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '.addButtonDetail',
            closeTo: '.addButtonDetail'
        });
    }


    $scope.selectNode = function (node) {
        $scope.ChartOfAccount = node.$modelValue;
    }

    $scope.selectNodeDetail = function (node) {
        $scope.ChartOfAccountDetail = node.$modelValue;
    }

    $scope.findNodes = function (item) {
        $scope.ChartOfAccountsFilter = item.ChartOfAccountsFilter;
    };

    $scope.findNodesDetail = function (item) {
        $scope.ChartOfAccountsFilterDetail = item.ChartOfAccountsFilterDetail;
    };

    $scope.chooseChartOfAccount = function () {
        if ($scope.AutoTransactionSetting.AutoTransactionSettingID == undefined) {
            $scope.AutoTransactionSettings.push({
                ChartOfAccountName: $scope.ChartOfAccount.Name,                
                FromChartOfAccountID: $scope.ChartOfAccount.ChartOfAccountID,
                ChartOfAccountCode: $scope.ChartOfAccount.AccountCode,
                AutoTransactionOperationID: $scope.AutoTransactionOperation.AutoTransactionOperationID,
                //InvoiceTypeID: $scope.AutoTransactionSetting.InvoiceTypeID,
                AutoTransactionSettingID: 0
            });
        }
        else {
            $scope.AutoTransactionSetting.ChartOfAccountName = $scope.ChartOfAccount.Name;
            $scope.AutoTransactionSetting.FromChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
            $scope.AutoTransactionSetting.ChartOfAccountCode = $scope.ChartOfAccount.AccountCode;
            AutoTransactionOperationID: $scope.AutoTransactionOperation.AutoTransactionOperationID;
            //InvoiceTypeID: $scope.AutoTransactionSetting.InvoiceTypeID
        }

        //$scope.AutoTransactionSetting = {};
        $scope.cancelChartOfAccountsDialog();
    };

    $scope.chooseChartOfAccountDetail = function () {

        if ($scope.MasterSelected[0].AutoTransactionSettingDetails == undefined) {
            $scope.MasterSelected[0].AutoTransactionSettingDetails = [];
        }

        //if ($scope.AutoTransactionSettingDetail.AutoTransactionSettingDetailID == undefined || 
        //    $scope.AutoTransactionSettingDetail.AutoTransactionSettingDetailID == 0) {
        if ($scope.AutoTransactionSettingDetail.AutoTransactionSettingDetailID == undefined) {
            $scope.MasterSelected[0].AutoTransactionSettingDetails.push({
                ChartOfAccountName: $scope.ChartOfAccountDetail.Name,                
                ToChartOfAccountID: $scope.ChartOfAccountDetail.ChartOfAccountID,
                ChartOfAccountCode: $scope.ChartOfAccountDetail.AccountCode,                
                AutoTransactionSettingDetailID: 0
            });
        }
        else {
            $scope.AutoTransactionSettingDetail.ChartOfAccountName = $scope.ChartOfAccountDetail.Name;
            $scope.AutoTransactionSettingDetail.ToChartOfAccountID = $scope.ChartOfAccountDetail.ChartOfAccountID;
            $scope.AutoTransactionSettingDetail.ChartOfAccountCode = $scope.ChartOfAccountDetail.AccountCode;
        }

        //$scope.AutoTransactionSettingDetail = {};
        $scope.cancelChartOfAccountsDialogDetail();
    };

    $scope.FilterChartOfAccounts = function (item) {
        return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
    };

    $scope.FilterChartOfAccountsDetail = function (item) {
        return (item.Name.indexOf($scope.ChartOfAccountsFilterDetail) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilterDetail) != -1);
    };

    $scope.cancelChartOfAccountsDialog = function () {
        $mdDialog.cancel();
        //$scope.ChartOfAccount = { IsGroup: true };
        $scope.ChartOfAccountsFilter = "";
    };
  
    $scope.cancelChartOfAccountsDialogDetail = function () {
        $mdDialog.cancel();
        //$scope.ChartOfAccountDetail = { IsGroup: true };
        $scope.ChartOfAccountsFilterDetail = "";
    };
   

    $scope.edit = function (item) {

        //$scope.AutoTransactionSettings = [];
        //$scope.filtered = [];

        //$scope.loadAutoTransactionOperations();

        $scope.loadInvoiceTypes();

        $scope.AutoTransactionOperation = item;

        getTransactionSetting(item.AutoTransactionOperationID);                
        

        //$scope.AutoTransactionSettings[0] = item;

        //$scope.AutoTransactionSetting.AutoTransactionOperationID = $scope.AutoTransactionSettings[0].AutoTransactionOperationID;
        

        HideMasterShowDetails('#divTransactionSearch', '#divTransactionData');
    }

    function getTransactionSetting(id) {
        $http.get("/Accounting/AutoTransactionSetting/getTransactionSetting/" + id)
            .success(function (results) {
                
                $scope.AutoTransactionSettings = results;

                for (var i = 0; i < $scope.AutoTransactionSettings.length; i++) {

                    if ($scope.AutoTransactionSettings[i].Sales_InvoiceTypeID > 0)
                    {
                        $scope.AutoTransactionSettings[i].InvoiceTypeID = $scope.AutoTransactionSettings[i].Sales_InvoiceTypeID;
                    }
                    else
                    {
                        $scope.AutoTransactionSettings[i].InvoiceTypeID = $scope.AutoTransactionSettings[i].Purchase_InvoiceTypeID;
                    }

                    if ($cookies.get('ERP_lang') == 'ar-EG')
                    {
                        $scope.AutoTransactionSettings[i].ChartOfAccountName = $scope.AutoTransactionSettings[i].ChartOfAccountNameAR;
                    }
                    else
                    {
                        $scope.AutoTransactionSettings[i].ChartOfAccountName = $scope.AutoTransactionSettings[i].ChartOfAccountNameEN;
                    }
                }

                //getTransactionSettingDetails();

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
    }

    function getTransactionSettingDetails() {
        
        for (var i = 0; i < $scope.AutoTransactionSettings.length; i++) {

            $http.get("/Accounting/AutoTransactionSetting/getTransactionSettingDetails/" + $scope.AutoTransactionSettings[i].AutoTransactionSettingID)
            .success(function (results) {

                $scope.AutoTransactionSettings[i].AutoTransactionSettingDetails = results;

                for (var j = 0; j < $scope.AutoTransactionSettings[i].AutoTransactionSettingDetails.length; j++) {

                    if ($cookies.get('ERP_lang') == 'ar-EG')
                    {
                        $scope.AutoTransactionSettings[i].AutoTransactionSettingDetails[j].ChartOfAccountName = $scope.AutoTransactionSettings[i].AutoTransactionSettingDetails[j].ChartOfAccountNameAR;
                    }
                    else
                    {
                        $scope.AutoTransactionSettings[i].AutoTransactionSettingDetails[j].ChartOfAccountName = $scope.AutoTransactionSettings[i].AutoTransactionSettingDetails[j].ChartOfAccountNameEN;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });

        }

    }

   
    $scope.back = function () {
        HideMasterShowDetails('#divTransactionData', '#divTransactionSearch');    

        $scope.DetailSelected = [];

        $scope.AutoTransactionSettingDetails = [];
        $scope.AutoTransactionSettingDetail = {};

        $scope.AutoTransactionSetting = {};

        $scope.MasterSelected = [];
       
        $scope.selected = [];

        //LoadAutoTransactionSettings();
    }

    $scope.AddNew = function () {       

        HideMasterShowDetails('#divTransactionSearch', '#divTransactionData')

        $scope.selected = [];
        $scope.MasterSelected = [];
        $scope.DetailSelected = [];

        $scope.AutoTransactionSettings = [];
        $scope.AutoTransactionSetting = {};

        $scope.AutoTransactionSettingDetails = [];
        $scope.AutoTransactionSettingDetail = {};                      
    }

    $scope.save = function () {
        //$scope.AutoTransactionSetting.AutoTransactionSettingDetails = $scope.AutoTransactionSettingDetails;

        for (var i = 0; i < $scope.AutoTransactionSettings.length; i++) {

            //$scope.AutoTransactionSettings[i].AutoTransactionOperationID = $scope.AutoTransactionSettings[i].AutoTransactionOperationID;

            if ($scope.AutoTransactionOperation.OperationType == 1)
            {
                $scope.AutoTransactionSettings[i].Sales_InvoiceTypeID = $scope.AutoTransactionSettings[i].InvoiceTypeID;
            }
            else if ($scope.AutoTransactionOperation.OperationType == 2)
            {
                $scope.AutoTransactionSettings[i].Purchase_InvoiceTypeID = $scope.AutoTransactionSettings[i].InvoiceTypeID;
            }
            else if ($scope.AutoTransactionOperation.OperationType == 3)
            {
                $scope.AutoTransactionSettings[i].PaymentTypeID = $scope.AutoTransactionSettings[i].InvoiceTypeID;
            }
            else
            {
                $scope.AutoTransactionSettings[i].Sales_InvoiceTypeID = $scope.AutoTransactionSettings[i].InvoiceTypeID;
            }
        }        

        $http.post("/Accounting/AutoTransactionSetting/saveTransactionSetting", $scope.AutoTransactionSettings).success(function () {
            $rootScope.$emit("swAlertSave", {});
            $scope.back();
            //LoadAutoTransactionSettings();
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        })
    } 


    /// Account Edit

    $scope.editDailyTransCode = function (item) {
        $scope.AutoTransactionSetting = item;
        if ($scope.ChartOfAccounts.length <= 0) {
            $scope.getChartOfAccountTree();
        }
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '#btnEditCode',
            closeTo: '#btnEditCode'
        });
    }

    $scope.editDailyTransCodeDetail = function (item) {

        $scope.AutoTransactionSettingDetail = item;

        if ($scope.ChartOfAccountsDetails.length <= 0) {
             $scope.getChartOfAccountTree('Detail');
        }

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount2.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialogDetail();
            },
            clickOutsideToClose: true,
            openFrom: '#btnEditDetailCode',
            closeTo: '#btnEditDetailCode'
        });

    }


    $scope.editDailyTransName = function (item) {

        $scope.AutoTransactionSetting = item;

        if ($scope.ChartOfAccounts.length <= 0) {
            $scope.getChartOfAccountTree();
        }

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '#btnEditName',
            closeTo: '#btnEditName'
        });

    }         

    $scope.editDailyTransNameDetail = function (item) {

        $scope.AutoTransactionSettingDetail = item;

        //$scope.getChartOfAccountTree('Detail');

        if ($scope.ChartOfAccountsDetails.length <= 0) {
             $scope.getChartOfAccountTree('Detail');
        }

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount2.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialogDetail();
            },
            clickOutsideToClose: true,
            openFrom: '#btnEditDetailName',
            closeTo: '#btnEditDetailName'
        });
    }

    // ddl Functions
    $scope.loadInvoiceTypes = function () {
        if ($scope.AutoTransactionOperation.OperationType == 1)
        {
            $http.get('/Accounting/Sales_InvoiceType/getSales_InvoiceTypes').success(function (results) {
                $scope.InvoiceTypes = results;
                for (var i = 0; i < $scope.InvoiceTypes.length; i++) {
                    //if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameAr;
                    //}
                    //else {
                    //    $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameEn;
                    //}
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
        else if ($scope.AutoTransactionOperation.OperationType == 2)
        {
            $http.get('/Accounting/Purchase_InvoiceType/getPurchases_InvoiceTypes').success(function (results) {
                $scope.InvoiceTypes = results;
                for (var i = 0; i < $scope.InvoiceTypes.length; i++) {
                    //if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameAr;
                    //}
                    //else {
                    //    $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameEn;
                    //}
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
        else if ($scope.AutoTransactionOperation.OperationType == 3)
        {
            $http.get('/Accounting/Sales_InvoiceType/getPaymentTypes').success(function (results) {
                $scope.InvoiceTypes = results;
                for (var i = 0; i < $scope.InvoiceTypes.length; i++) {
                    //if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameAr;
                    //}
                    //else {
                    //    $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameEn;
                    //}
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
        else
        {
            $http.get('/Accounting/Sales_InvoiceType/getSales_InvoiceTypes').success(function (results) {
                $scope.InvoiceTypes = results;
                for (var i = 0; i < $scope.InvoiceTypes.length; i++) {
                    //if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameAr;
                    //}
                    //else {
                    //    $scope.InvoiceTypes[i].Title = $scope.InvoiceTypes[i].NameEn;
                    //}
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    }

    //$scope.loadAutoTransactionOperations = function () {
    //    if ($scope.AutoTransactionOperations.length <= 0) {
    //        $http.get('/Accounting/AutoTransactionSetting/getAutoTransactionOperations').success(function (results) {
    //            $scope.AutoTransactionOperations = results;
    //            for (var i = 0; i < $scope.AutoTransactionOperations.length; i++) {
    //                if ($cookies.get('ERP_lang') == 'ar-EG') {
    //                    $scope.AutoTransactionOperations[i].Title = $scope.AutoTransactionOperations[i].NameAr;
    //                }
    //                else {
    //                    $scope.AutoTransactionOperations[i].Title = $scope.AutoTransactionOperations[i].NameEn;
    //                }
    //            }
    //        }).error(function () {
    //            $rootScope.$emit("swAlertError", {});
    //        });
    //    }
    //}


});