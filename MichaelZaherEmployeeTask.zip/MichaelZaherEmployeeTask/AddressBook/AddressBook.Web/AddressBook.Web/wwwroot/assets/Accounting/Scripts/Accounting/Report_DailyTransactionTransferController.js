﻿angular.module('globalApp')
.controller('Report_DailyTransactionTransferController', function ($scope, $mdDialog, $http, $rootScope, $cookies) {
    $scope.ChartOfAccounts = [];
    
    //$scope.ChartOfAccount = { IsGroup: true };
    $scope.ChartOfAccountsFilter = "";
    $scope.DailyTransactions = [];
    $scope.Selected = [];
    $scope.model = {};
    $scope.TransactionTypes = [];
    $scope.DailyTransaction = {};

    $scope.DailyTransactionDetails = [];   

    if ($scope.model.DateFrom == undefined) {
        //$scope.model.DateFrom = new Date('01/01/1999');
        $scope.model.DateFrom = new Date();
    };

    if ($scope.model.DateTo == undefined) {
        //$scope.model.DateTo = new Date('01/01/2020');
        $scope.model.DateTo = new Date();
    };

    $scope.getChartOfAccountTree();


    $scope.AddNewDailyTransactionDetail = function () {
        if ($scope.ChartOfAccounts.length <= 0) {
            $scope.getChartOfAccountTree();
        }
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        });
    }
    // Chart Of Account Dialog Functions
    //function getChartOfAccountTree() {
    //    $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
    //        $scope.ChartOfAccounts = results.treeObj;
    //    }).error(function () {
    //        $rootScope.$emit("swAlertError", {});
    //    });
    //};
    $scope.selectNode = function (node) {
        $scope.ChartOfAccount = node.$modelValue;
    }
    $scope.findNodes = function (item) {
        $scope.ChartOfAccountsFilter = item.ChartOfAccountsFilter;
    };
    $scope.chooseChartOfAccount = function () {
        $scope.model.ChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
        $scope.model.Name = $scope.ChartOfAccount.Name;
        $scope.cancelChartOfAccountsDialog();
    };
    $scope.FilterChartOfAccounts = function (item) {
        return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
    };

    $scope.cancelChartOfAccountsDialog = function () {
        $mdDialog.cancel();
        //$scope.ChartOfAccount = { IsGroup: true };
        $scope.ChartOfAccountsFilter = "";
    };

    $scope.checkReport = function (model) {
        var reportParams = {
            "Parms": { "DateFrom": model.DateFrom, "DateTo": model.DateTo, "CharOfAccountID": model.ChartOfAccountID, "IsTransefered": true, "AccountName": model.Name },
            "ReportName": "DailyTransactionReport.trdx"
        };
        //$("#reportTest").load('/report', JSON.stringify(reportParams));
        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    };

    $scope.clearFields = function () {
        $scope.model = {};
        cancelChartOfAccountsDialog();
    };

    $scope.loadTransactionTypes = function () {
        if ($scope.TransactionTypes.length <= 0) {
            $http.get('/Accounting/TransactionType/getTransactionTypes').success(function (results) {
                $scope.TransactionTypes = results;
                for (var i = 0; i < $scope.TransactionTypes.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.TransactionTypes[i].Title = $scope.TransactionTypes[i].NameAr;
                    }
                    else {
                        $scope.TransactionTypes[i].Title = $scope.TransactionTypes[i].NameEn;
                    }
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.AddReverseTransaction = function (code) {
        $scope.edit(code);
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/ReverseTransaction.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'
        });
    };

    $scope.getDailyTransaction = function (model) {

        var quer = {
            IsTransfer: true,
            charOfAccountID: model.ChartOfAccountID,
            DateFrom: model.DateFrom,
            DateTo: model.DateTo
        }

        //$http.get('/Accounting/DailyTransaction/getTransactionDetails/' + model.ChartOfAccountID).success(function (results) {
        $http.post('/Accounting/DailyTransaction/getDailyTransactionReport', quer).success(function (results) {
            $scope.DailyTransactions = results;

            //for (var i = 0; i < $scope.DailyTransactions.length; i++) {
            //    $scope.DailyTransactions[i].Balance = $scope.DailyTransactions[i].CurrentBalance + $scope.DailyTransactions[i].DepitAmount - $scope.DailyTransactions[i].CreditAmount;
            //}

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };


    $scope.edit = function (code) {
        $http.get("/Accounting/DailyTransaction/getTransactionByCode/" + code)
           .success(function (results) {
               $scope.DailyTransaction = results;
               $scope.DailyTransaction.Notes = "قيد عكسى من القيد رقم " + code;
               getTransactionDetails($scope.DailyTransaction.DailyTransactionID);
           }).error(function () {
               $rootScope.$emit("swAlertError", {});
           });
    } 

    function getTransactionDetails(id) {
        $http.get("/Accounting/DailyTransaction/getTransactionDetails/" + id)
            .success(function (results) {
                $scope.DailyTransactionDetails = results;
                for (var i = 0; i < $scope.DailyTransactionDetails.length; i++)
                {
                        var credit= $scope.DailyTransactionDetails[i].DepitAmount;
                        var debit= $scope.DailyTransactionDetails[i].CreditAmount;
                        $scope.DailyTransactionDetails[i].DepitAmount = debit;
                        $scope.DailyTransactionDetails[i].CreditAmount = credit;
                   
                        $scope.DailyTransactionDetails[i].DailyTransactionDetailID = 0;
                }
                
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
    }

    $scope.saveReverseTransaction = function () {
        $scope.DailyTransaction.DailyTransactionID = 0;
        $scope.DailyTransaction.DailyTransactionDetails = $scope.DailyTransactionDetails;
        $http.post("/Accounting/DailyTransaction/saveTransaction", $scope.DailyTransaction).success(function () {
            $rootScope.$emit("swAlertSave", {});
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        })
    }

    $scope.cancel = function () {
        $mdDialog.cancel();
    };

});