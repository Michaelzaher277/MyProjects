﻿
angular.module('globalApp')
.controller('AccountingSubPeriodController', function ($scope, $http, $cookies, $mdDialog, $rootScope) {

    $scope.AccountingSubPeriods = [];
    $scope.AccountingSubPeriod = {};
    $scope.AccountingPeriods = [];
    $scope.AccountingPeriodID = 0;
    getAccountingPeriods();
    $scope.selected = [];

    $scope.AllAccountingSubPeriods = [];

    function clear() {
        $scope.AccountingPeriod = {};
    };

    $scope.getAllAccountingSubPeriod = function () {
        $http.get('/Accounting/AccountingSubPeriod/GetAccountingSubPeriods').success(function (results) {
            $scope.AllAccountingSubPeriods = results;

            for (var i = 0; i < $scope.AllAccountingSubPeriods.length; i++) {
                if ($scope.AllAccountingSubPeriods[i].AccountingSubPeriodID == $scope.AccountingSubPeriod.AccountingSubPeriodID) {
                    $scope.AllAccountingSubPeriods.splice(i, 1);
                }
            }

        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });

    };

    function getAccountingPeriods() {
        $http.get('/Accounting/AccountingSubPeriod/GetAccountingPeriods').success(function (results) {
            $scope.AccountingPeriods = results;
            //for (var i = 0; i < $scope.AccountingPeriods.length; i++) {
            //    if ($cookies.get('ERP_lang') == 'ar-EG') {
            //        $scope.Roles[i].Title = $scope.Roles[i].NameAr;
            //    }
            //    else {
            //        $scope.Roles[i].Title = $scope.Roles[i].NameEn;
            //    }
            //}
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });

    };

    $scope.getAccountingSubPeriod = function () {
        $http.get('/Accounting/AccountingSubPeriod/getAccountingSubPeriodByAccountingPeriodID?AccountingPeriodID=' + $scope.AccountingPeriodID).success(function (results) {
            $scope.AccountingSubPeriods = results;
            //for (var i = 0; i < $scope.RolePermissions.length; i++) {
            //    if ($cookies.get('ERP_lang') == 'ar-EG') {
            //        $scope.RolePermissions[i].Title = $scope.RolePermissions[i].NameAr;
            //    }
            //    else {
            //        $scope.RolePermissions[i].Title = $scope.RolePermissions[i].NameEn;
            //    }
            //}
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });

    };

    $scope.save = function () {
        $scope.AccountingSubPeriod.AccountingPeriodID = $scope.AccountingPeriodID;
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.AccountingSubPeriod),
            url: '/Accounting/AccountingSubPeriod/saveAccountingSubPeriod',
            success: function () {
                $rootScope.$emit("swAlertSave", {});
                $scope.getAccountingSubPeriod();
                $scope.cancel();
                $scope.selected = [];
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }

        });
    };

    $scope.savediag = function () {
        $scope.save();
       
       
    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.AccountingSubPeriod = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.AccountingSubPeriod = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/AccountingSubPeriod.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };

    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Accounting/AccountingSubPeriod/deleteAccountingPeriod', JSON.stringify($scope.selected)).success(function () {
                       $scope.getAccountingSubPeriod();
                       $scope.selected = [];
                   });
               }
           });
    }

     $scope.edit = function (AccountingSubPeriodID) {
         $http.get('/Accounting/AccountingSubPeriod/getAccountingSubPeriodByID/' + AccountingSubPeriodID).success(function (data) {
            $scope.AccountingSubPeriod = data;
            $scope.showAdvancedEdit();
        });
     };

     $scope.showAdvancedEdit = function (ev) {
         $mdDialog.show({
             scope: $scope.$new(),
             templateUrl: '../../Areas/accounting/templates/AccountingSubPeriod.tmpl.html',
             onRemoving: function () {
                 $scope.cancel();
             },
             clickOutsideToClose: true,
             openFrom: '.editButton',
             closeTo: '.editButton'
         })

    };

    $scope.showCloseDialog = function (obj) {
        $scope.AccountingSubPeriod = obj;
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/EditSubPeriodCloseStatus.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })
    };

    $scope.saveSubPeriodStatus = function () {
        $scope.AccountingSubPeriodTemp = $scope.AccountingSubPeriod;
        $mdDialog.cancel();
        $rootScope.$emit("swConfirmCloseSubPeriod",
            {                
                function() {                    
                    $.ajax({
                        type: 'POST',
                        contentType: 'application/json; charset=utf-8',
                        data: JSON.stringify($scope.AccountingSubPeriodTemp),
                        url: '/Accounting/AccountingSubPeriod/saveSubPeriodCloseStatus',
                        success: function (result) {
                            $rootScope.$emit("swAlertSave", {});
                            $scope.hide();
                            $scope.getAccountingSubPeriod();
                        },
                        error: function () {
                            $rootScope.$emit("swAlertError", {});
                        }
                    });
                }

            });
    }

    //$scope.saveSubPeriodStatus = function () {

    //    $.ajax({
    //        type: 'POST',
    //        contentType: 'application/json; charset=utf-8',
    //        data: JSON.stringify($scope.AccountingSubPeriod),
    //        url: '/Accounting/AccountingSubPeriod/saveSubPeriodCloseStatus',
    //        success: function (result) {
    //            $rootScope.$emit("swAlertSave", {});
    //            $scope.hide();
    //            $scope.getAccountingSubPeriod();
    //        },
    //        error: function () {
    //            $rootScope.$emit("swAlertError", {});
    //        }
    //    });
    //};


})