﻿angular.module('globalApp')
.controller('BankBranchesController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $element) {
    // scope variables
    $scope.Banks = [];
    $scope.BankBranch = {};
    $scope.BankBranches = [];

    // functions to run on start
    getBanks();

    // md-table variables
    $scope.selected = [];
    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };
    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };

    // Bank Branches Functions
    function getBanks() {
        $http.get('/Accounting/Banks/getBanks').success(function (results) {
            $scope.Banks = results;
            for (var i = 0; i < $scope.Banks.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Banks[i].Name = $scope.Banks[i].NameAr;
                }
                else {
                    $scope.Banks[i].Name = $scope.Banks[i].NameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.getBankBranches = function() {
        $http.get('/Accounting/BankBranches/getBankBranchesByBankID/' + $scope.BankID).success(function (results) {
            $scope.BankBranches = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.edit = function (selectedModel) {
        $scope.BankBranch = selectedModel;
        $scope.showEditDialog();
    };

    $scope.showEditDialog = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/BankBranch.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })
    };
    $scope.showAddDialog = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/BankBranch.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.AddButton',
            closeTo: '.AddButton'
        })
    };
    $scope.save = function () {
        $scope.BankBranch.BankID = $scope.BankID;
        $http.post('/Accounting/BankBranches/save', $scope.BankBranch).success(function () {
            $scope.cancel();
            $rootScope.$emit("swAlertSave", {});
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.delete = function () {
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Accounting/BankBranches/delete', JSON.stringify($scope.selected)).success(function () {
                       $scope.getBankBranches();
                       $scope.selected = [];
                   });
               }
           });
    }
    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.selected = [];
        $scope.BankBranch = {};
        $scope.getBankBranches();
    };
});