﻿
angular.module('globalApp')
.controller('RolePermissionController', function ($scope, $http, $cookies , $mdDialog, $rootScope) {

    $scope.RolePermissions = [];
    $scope.RolePermission = {};
    $scope.Roles = [];    
    $scope.RoleID = 0;
    getRoles();


    function clear() {
        $scope.Role = {};
    };

    function getRoles() {
        $http.get('/Administration/Security/GetRoles').success(function (results) {
            $scope.Roles = results;
            for (var i = 0; i < $scope.Roles.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Roles[i].Title = $scope.Roles[i].NameAr;
                }
                else {
                    $scope.Roles[i].Title = $scope.Roles[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });

    };

    $scope.getPermission = function () {
        $http.get('/Administration/Security/getRolePermissionByRoleID?roleID=' + $scope.RoleID).success(function (results) {
            $scope.RolePermissions = results;
            for (var i = 0; i < $scope.RolePermissions.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.RolePermissions[i].Title = $scope.RolePermissions[i].NameAr;
                }
                else {
                    $scope.RolePermissions[i].Title = $scope.RolePermissions[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });

    };

    $scope.save = function () {
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.RolePermissions),
            url: '/Administration/Security/saveRolePermissions',
            success: function () {
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

})