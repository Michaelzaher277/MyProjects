﻿
angular.module('globalApp')
.controller('Purchase_InvoiceTypeController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.Purchase_InvoiceTypes = [];
    $scope.Purchase_InvoiceType = {};

    $scope.selected = [];

    getPurchase_InvoiceTypes();

    //function success(desserts) {
    //    $scope.desserts = ['christian', 'Non-christian'];
    //}

    //$scope.getDesserts = function () {
    //  $scope.promise = $nutrition.desserts.get($scope.query, success).$promise;
    //};

    function getPurchase_InvoiceTypes() {
        $http.get('/Purchase_InvoiceType/getPurchases_InvoiceTypes').success(function (results) {
            $scope.Purchase_InvoiceTypes = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Purchase_InvoiceType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom : '.addButton',
            closeTo: '.addButton'
        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Purchase_InvoiceType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Purchase_InvoiceType = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Purchase_InvoiceType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Purchase_InvoiceType),
            url: '/Purchase_InvoiceType/savePurchases_InvoiceType',
            success: function () {
                getPurchase_InvoiceTypes();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {
        
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Purchase_InvoiceType/deletePurchase_InvoiceType', JSON.stringify($scope.selected)).success(function () {
                       getPurchase_InvoiceTypes();
                       $scope.selected = [];
                   });
               }
           });
    }
    $scope.edit = function (Purchase_InvoiceTypeID) {
        $http.get('/Purchase_InvoiceType/getPurchase_InvoiceTypeByID/' + Purchase_InvoiceTypeID).success(function (data) {
            $scope.Purchase_InvoiceType = data;
            $scope.showAdvancedEdit();
        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});