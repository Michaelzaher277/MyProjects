﻿angular.module('globalApp')
.controller('Sales_SupplyOrderController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $element, $filter) {

    $scope.Sales_SupplyOrder = {};
    $scope.Sales_SupplyOrders = [];
    $scope.Sales_SupplyOrderDetails = [];

    $scope.selected = [];
    $scope.Sales_SupplyOrderDetailsSelected = [];           
    $scope.PaymentTypes = [];
    $scope.selectedProduct = [];
    $scope.selectedDetails = [];
    $scope.Customers = [];
    $scope.searchTerm = "";
    $scope.SelectedCustomerID = 0;
    $scope.Sum = {};

    $scope.Sum.TotalQuantity = 0;
    $scope.Sum.Amount = 0;
    $scope.Sum.Discount = 0;
    $scope.Sum.TotalPrice = 0;
    $scope.Sum.Taxes = 0;
    $scope.Sum.TaxesDiscount = 0;
    $scope.Sum.TotalCost = 0;
    $scope.Sum.TotalInvoice = 0;
    $scope.Sum.NetTotalPrice = 0;
    $scope.Setting = {};

    $scope.PriceOffers = [];    
    $scope.PriceOffer = {};

    $scope.PriceOfferDetails = [];
    $scope.selectedPriceOffer = [];

    $scope.clearSearchTerm = function () {
        $scope.searchTerm = "";
        getSupplyOrders();
    };

    getSupplyOrders();
    getInvoicePayments();
    //HideMasterShowDetails("#DivSave", "#DivShow");

    $scope.getSetting = function () {
        $http.get('/AccountingSettings/getAccountingSettings').success(function (results) {
            $scope.Setting = results;
        })
    };

    $scope.getSetting();
    function getInvoicePayments() {
        $http.get('/Sales_Invoice/getPaymentTypes').success(function (results) {
            $scope.PaymentTypes = results;
            for (var i = 0; i < $scope.PaymentTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameAr;
                }
                else {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $element.find('input#searchCustomers').on('keydown', function (ev) {
        ev.stopPropagation();
    });

    $scope.loadCustomers = function () {
        if ($scope.Customers.length <= 0) {
            $http.get('/Administration/Customer/GetCustomers').success(function (results) {
                $scope.Customers = results;

                for (var i = 0; i < $scope.Customers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Customers[i].Title = $scope.Customers[i].NameAr;
                    }
                    else {
                        $scope.Customers[i].Title = $scope.Customers[i].NameEng;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.loadCustomers();
    function getLastCodeInvoices() {
        $http.get('/Sales_SupplyOrders/GetLastCodeInvoices').success(function (results) {
            $scope.Sales_SupplyOrder.SupplyOrderCode = results;
            //var today = $filter('date')(new Date(), 'yyyy-MM-dd');
            $scope.Sales_SupplyOrder.SupplyOrderDate = new Date();;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

   
    function clearFields() {
        $scope.Sales_SupplyOrder = {};       
        $scope.Sales_SupplyOrderDetails = [];
        $scope.Selected = [];
        $scope.selectedDetails = [];
        $scope.Sum = {};

        $scope.Sum.TotalQuantity = 0;
        $scope.Sum.Amount = 0;
        $scope.Sum.Discount = 0;
        $scope.Sum.TotalPrice = 0;
        $scope.Sum.Taxes = 0;
        $scope.Sum.TaxesDiscount = 0;
        $scope.Sum.TotalCost = 0;
        $scope.Sum.TotalInvoice = 0;
        $scope.Sum.NetTotalPrice = 0;

    };

    function getSupplyOrders() {
        $http.get('/Sales_SupplyOrders/getAllSupplyOrders').success(function (results) {
            $scope.Sales_SupplyOrders = results;            
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function getSupplyOrderDetailsBySupplyOrderID(SupplyOrderID) {
        $http.get('/Sales_SupplyOrders/getSupplyOrderDetailsBySupplyOrderID/' + SupplyOrderID).success(function (results) {
            $scope.Sales_SupplyOrderDetails = results;
            for (var i = 0; i < $scope.Sales_SupplyOrderDetails.length; i++) {
                $scope.getMeasureUnit($scope.Sales_SupplyOrderDetails[i].PartID);
                $scope.Sales_SupplyOrderDetails[i].MeasureUnits = $scope.MeasureUnits;
                $scope.getRowPrices($scope.Sales_SupplyOrderDetails[i]);

            }
       //     $scope.getInvoiceTypes();
            $scope.getTotalQuantity();
            $scope.getPrice();
            $scope.getTaxes();
            $scope.getDiscount();
            $scope.getTaxesDiscount();
        //    $scope.Sales_SupplyOrderDetails = results;

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.edit = function (model) {        
        $scope.loadCustomers();
        $scope.Sales_SupplyOrder = model;
        getSupplyOrderDetailsBySupplyOrderID(model.SupplyOrderID);
        HideMasterShowDetails('#AllSupplyOrder', '#EditSupplyOrder');
        $scope.selected = [];
        $scope.getTotalQuantity();
        $scope.getPrice();
        $scope.getTaxes();
        $scope.getDiscount();
        $scope.getTaxesDiscount();
    };

    $scope.save = function () {
        $scope.Sales_SupplyOrder.Sales_SupplyOrderDetail = $scope.Sales_SupplyOrderDetails;

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Sales_SupplyOrder),
            url: '/Sales_SupplyOrders/saveSupplyOrder',
            success: function () {
                getSupplyOrders();                
                clearFields();
                HideMasterShowDetails('#EditSupplyOrder', '#AllSupplyOrder');
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.delete = function () {
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Sales_SupplyOrders/deleteSupplyOrders', JSON.stringify($scope.selected)).success(function (results) {
                       getSupplyOrders();
                       $scope.selected = [];
                   });                   
               }
           });
    }

    $scope.deleteDetail = function (model) {
        swConfirmDeleteAr({
            function () {
                $scope.Sales_SupplyOrderDetails.splice($.inArray(model, $scope.Sales_SupplyOrderDetails), 1);

                $scope.$apply();
                $scope.selectedDetails = [];
                $scope.getTotalQuantity();
                $scope.getPrice();
                $scope.getDiscount();
                $scope.getTaxes();
                $scope.getTaxesDiscount();
                $scope.getNetTotalPrice();
            }
        });
    }

      $scope.getMeasureUnit = function (productID) {
        $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
            $scope.MeasureUnits = results;
            for (var i = 0; i < $scope.MeasureUnits.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
                }
                else {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEn;
                }
            }


            for (var i = 0; i < $scope.Sales_SupplyOrderDetails.length; i++) {
                if ($scope.Sales_SupplyOrderDetails[i].PartID == productID)
                    $scope.Sales_SupplyOrderDetails[i].MeasureUnits = $scope.MeasureUnits;
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    /////////////////////////////////////// Load From Price Offers

      $scope.LoadPriceOffer = function (ev) {         
          $scope.getPriceOffers();
          $mdDialog.show({
              scope: $scope.$new(),
              templateUrl: '../../Areas/accounting/templates/SupplyLoadPriceOffer.tmpl.html',
              onRemoving: function () {
                  $scope.cancelProduct();
              },
              clickOutsideToClose: true,
              openFrom: '.addButton',
              closeTo: '.addButton'
          })

      };

    //load Price Offer
      $scope.getPriceOffers = function () {
          $http.get('/Accounting/Sales_PriceOffer/getAllPriceOffers').success(function (results) {
              $scope.PriceOffers = results;
          }).error(function () {
              swAlertErrorAr();
          });
      };

      $scope.loadDetailsFrom = function (PriceOfferID) {
          $scope.Sales_SupplyOrder.PriceOfferID = PriceOfferID;
          $http.get('/Sales_PriceOffer/getPriceOfferDetailsByPriceOfferID/' + PriceOfferID).success(function (results) {
              $scope.PriceOfferDetails = results;
              addMasterPriceOfferInSupplyOrder(PriceOfferID);
              addDetailsPriceOfferInSupplyOrder();
              $scope.cancelProduct();
          }).error(function () {
              swAlertErrorAr();
          });
      }

      function addMasterPriceOfferInSupplyOrder (PriceOfferID) {
          $http.get('/Sales_PriceOffer/getPriceOfferByPriceOfferID/' + PriceOfferID).success(function (results) {
              $scope.PriceOffer = results;
              $scope.Sales_SupplyOrder.CustomerID = $scope.PriceOffer.CustomerID;
              $scope.Sales_SupplyOrder.EndDate = $scope.PriceOffer.EndDate;
              $scope.Sales_SupplyOrder.PaymentTypeID = $scope.PriceOffer.PaymentTypeID;
              $scope.Sales_SupplyOrder.Notes = $scope.PriceOffer.Notes;
          }).error(function () {
              swAlertErrorAr();
          });
      }

      function addDetailsPriceOfferInSupplyOrder() {
          for (i = 0; i < $scope.PriceOfferDetails.length; i++) {
              if ($scope.PriceOfferDetails[i].PartID != null) {
                  $scope.getMeasureUnit($scope.PriceOfferDetails[i].PartID);
                  var item = {};
                  item.PartID = $scope.PriceOfferDetails[i].PartID;
                  item.PartName = $scope.PriceOfferDetails[i].PartName;
                  item.PartCode = $scope.PriceOfferDetails[i].PartCode;
                  item.Quantity = $scope.PriceOfferDetails[i].Quantity;

                  item.StartDate = $scope.PriceOfferDetails[i].StartDate;
                  item.EndDate = $scope.PriceOfferDetails[i].EndDate;
                  item.MeasureUnitID = $scope.PriceOfferDetails[i].MeasureUnitID;
                  item.Price = $scope.PriceOfferDetails[i].Price;
                  item.Discount = $scope.PriceOfferDetails[i].Discount;
                  item.Taxes = $scope.PriceOfferDetails[i].Taxes;
                  item.Notes = $scope.PriceOfferDetails[i].Notes;

                  var foundItem = $filter('filter')($scope.Sales_SupplyOrderDetails, { PartCode: $scope.PriceOfferDetails[i].PartCode }, true)[0];

                  if (foundItem == undefined) {
                      $scope.GetMeasureUnitQuanityOnLoad(item)
                      $scope.Sales_SupplyOrderDetails.push(item);
                      $scope.getRowPrices(item);
                  }

              }
          };
      }

    ///////////////////////////////////////

    $scope.getProductModal = function (modal) {

        for (i = 0; i < modal.length; i++) {
            if (modal[i].ProductID != null) {
                var item = {};
                item.PartID = modal[i].ProductID;
                item.PartName = modal[i].NameAr;
                item.PartCode = modal[i].Code;
                item.MeasureUnits = modal[i].MeasureUnits;

                //$scope.getSetting();
                for (var j = 0; j < item.MeasureUnits.length; j++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                    }
                    else {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                    }
                }

                if ($scope.Setting != undefined) {
                    item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                    item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                }
                else {
                    $scope.getSetting();
                    if ($scope.Setting != undefined) {
                        item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                        item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                    }
                }

                var foundItem = $filter('filter')($scope.Sales_SupplyOrderDetails, { PartCode: modal[i].Code }, true)[0];

                if (foundItem == undefined) {
                    $scope.Sales_SupplyOrderDetails.push(item);
                }
                ///  $scope.Sales_SupplyOrderDetails.push(item);
            }
        }
        //$scope.cancelProduct();

        // $('#DivParts').modal('toggle');
    };

    $scope.showAdvancedAdd = function (ev) {
        HideMasterShowDetails('#AllSupplyOrder', '#EditSupplyOrder');

        getLastCodeInvoices();

        $scope.TotalQuantity = 0;
        $scope.Amount = 0;
        $scope.Discount = 0;
        $scope.Taxes = 0;
        $scope.TaxesDiscount = 0;
    };
    $scope.getAllProductsModal = function () {
        $http.get('/Inventory/ProductDetails/GetProducts').success(function (results) {
            $scope.Products = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    $scope.showProductsAdd = function (ev) {
        //  $("DivShow)
        //   $scope.Sales_SupplyOrderDetails.push({});
        //  $scope.getAllProductsModal();
        $scope.GetTopProducts("");

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadProducts.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addProduct',
            closeTo: '.addProduct'
        })

    };


    $scope.cancelDialog = function () {
        $mdDialog.cancel();
    };

    $scope.cancelProduct = function () {
        //$scope.AddNew = true;

        $mdDialog.cancel();
        $scope.selectedProduct = [];
    };

    $scope.cancel = function()
    {
        clearFields();
        getSupplyOrders();
        HideMasterShowDetails('#EditSupplyOrder', '#AllSupplyOrder');
    }   

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';        
        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
        getSupplyOrders();

    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

    $scope.DetailsOptions = {
        pageSelect: true
    };
    $scope.DetailsQuery = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

    $scope.getTotalQuantity = function () {
        $scope.Sum.TotalQuantity = 0;
        $.each($scope.Sales_SupplyOrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Quantity))) {
                $scope.Sum.TotalQuantity += parseFloat(item.Quantity);
            }
        });

    }

    $scope.getPrice = function () {
        $scope.Sum.Amount = 0;

        $.each($scope.Sales_SupplyOrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Price))) {
                $scope.Sum.Amount += parseFloat(item.Price);
            }
        });
    }

    $scope.getDiscount = function () {
        $scope.Sum.Discount = 0;

        $.each($scope.Sales_SupplyOrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Discount))) {
                $scope.Sum.Discount += parseFloat(item.Discount);
            }
        });
    }


    $scope.getTaxes = function () {
        $scope.Sum.Taxes = 0;

        $.each($scope.Sales_SupplyOrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Taxes))) {
                $scope.Sum.Taxes += parseFloat(item.Taxes);
            }
        });
    }

    $scope.getTaxesDiscount = function () {
        $scope.Sum.TaxesDiscount = 0;
        $.each($scope.Sales_SupplyOrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.TaxesDiscount))) {
                $scope.Sum.TaxesDiscount += parseFloat(item.TaxesDiscount);
            }
        });
    }

  


    $scope.getNetTotalPrice = function () {
        $scope.Sum.NetTotalPrice = 0;
        $.each($scope.Sales_SupplyOrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.TotalPrice))) {
                $scope.Sum.NetTotalPrice += parseFloat(item.TotalPrice);
            }
        });

    }

    $scope.getTotalCost = function () {
        $scope.Sum.TotalCost = $scope.Sum.NetTotalPrice;
        $.each($scope.Sales_SupplyOrderExpenses, function (i, item) {
            if (!isNaN(parseFloat(item.Amount)) && item.IsAddCost) {
                $scope.Sum.TotalCost += parseFloat(item.Amount);
            }
        });

    }

    $scope.getTotalInvoice = function () {
        $scope.Sum.TotalInvoice = $scope.Sum.NetTotalPrice;;
        $.each($scope.Sales_SupplyOrderExpenses, function (i, item) {
            if (!isNaN(parseFloat(item.Amount)) && item.IsInvoice_Expense) {
                $scope.Sum.TotalInvoice += parseFloat(item.Amount);
            }
        });
        //if (!isNaN(parseFloat($scope.Sum.TotalInvoice)) && !isNaN(parseFloat($scope.Sum.TotalCost)))
        //    $scope.Sales_SupplyOrder.Cost_Factor = $scope.Sum.TotalCost / $scope.Sum.TotalInvoice;
    }

    $scope.getRowPrices = function (item) {
        var Quantity = 0;
        var Price = 0;
        var Discount = 0;
        var Taxes = 0;
        var TaxesDiscount = 0;

        var TotalQuantityFromChild = 1;
        if (item.TotalQuantityFromChild != undefined)
            TotalQuantityFromChild = item.TotalQuantityFromChild

        if (item.Quantity != undefined)
            Quantity = item.Quantity * TotalQuantityFromChild;
        else
            Quantity = 0;

        if (item.Price != undefined)
            Price = item.Price;
        else
            Price = 0;

        if (item.Discount != undefined)
            Discount = ((Quantity * Price) * item.Discount) / 100;
        else
            Discount = 0;

        if (item.Taxes != undefined)
            Taxes = ((Quantity * Price) * item.Taxes) / 100;
        else
            Taxes = 0;

        if (item.TaxesDiscount != undefined)
            TaxesDiscount = ((Quantity * Price) * item.TaxesDiscount) / 100;
        else
            TaxesDiscount = 0;

        item.TotalPrice = ((Quantity * Price) + Taxes - TaxesDiscount - Discount).toString();
        $scope.getNetTotalPrice();
    }


    $scope.checkReport = function (SuppyOrderID) {

        if (SuppyOrderID != undefined) {

            var
                reportParams = {
                    "Parms": {
                        "SupplyOrderID": SuppyOrderID

                    },
                    "ReportName": "StockReport/SupplyOrderReport.trdx"
                };

            $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

                var x = window.open();
                x.document.open();
                x.document.write(results);
                x.document.close();
            })
        }
    }


    $scope.GetMeasureUnitQuanity = function (model) {
        $http.get('/Inventory/ProductDetails/GetMeasureUnitQuantity?ProductID=' + model.PartID + '&MeasureID=' + model.MeasureUnitID).success(function (results) {
            model.TotalQuantityFromChild = results;

            $scope.getRowPrices(model);
            $scope.getPrice();
            $scope.getTotalQuantity();

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    $scope.GetMeasureUnitQuanityOnLoad = function (model) {
        $http.get('/Inventory/ProductDetails/GetMeasureUnitQuantity?ProductID=' + model.PartID + '&MeasureID=' + model.MeasureUnitID).success(function (results) {
            model.TotalQuantityFromChild = results;

        

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

});