﻿angular.module('globalApp')
.controller('CostCenter_NotTransfered_ReportController', function ($scope, $mdDialog, $http, $rootScope) {
    $scope.CostCenters = [];
    //$scope.CostCenter = { IsGroup: true };
    $scope.CostCentersFilter = "";

    $scope.model = {};
    if ($scope.model.DateFrom == undefined) {
        $scope.model.DateFrom = '01/01/1900'
    };
    if ($scope.model.DateTo == undefined) {
        $scope.model.DateTo = '01/01/2500'
    };
    $scope.getCostCentersTree();

    // Cost Centers Dialog Functions
    function getCostCentersTree() {
        $http.get('/Accounting/CostCenter/getCostCenterTree').success(function (results) {
            $scope.CostCenters = results.treeObj;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.AddNewDailyTransactionDetailCostCenter = function () {
        if ($scope.CostCenters.length <= 0) {
            $scope.getCostCentersTree();
        }
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/DailyTransactionCostCenters.tmpl.html',
            onRemoving: function () {
                $scope.cancelChartOfAccountsDialog();
            },
            clickOutsideToClose: true,
            openFrom: '.addButtonCostCenter',
            closeTo: '.addButtonCostCenter'
        });
    }
    $scope.selectNodeCostCenter = function (node) {
        $scope.CostCenter = node.$modelValue;
    }
    $scope.findNodesCostCenter = function (item) {
        $scope.CostCentersFilter = item.CostCentersFilter;
    };
    $scope.chooseCostCenter = function () {
        $scope.model.CostCenterID = $scope.CostCenter.CostCenterID;
        $scope.model.Name = $scope.CostCenter.Name;
        $scope.cancelCostCentersDialog();
    };
    $scope.FilterCostCenters = function (item) {
        return (item.Name.indexOf($scope.CostCentersFilter) != -1 || item.AccountCode.indexOf($scope.CostCentersFilter) != -1);
    };
    $scope.cancelCostCentersDialog = function () {
        $mdDialog.cancel();
        //$scope.CostCenter = { IsGroup: true };
        $scope.CostCentersFilter = "";
    };
    $scope.checkReport = function (model) {
        var reportParams = {
            "Parms": { "DateFrom": model.DateFrom, "DateTo": model.DateTo, "CostCenterID": model.CostCenterID },
            "ReportName": "CostCenter_NotTransfered_Report.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }
    $scope.clearFields = function () {
        $scope.model = {};
        cancelCostCentersDialog();
    }
});