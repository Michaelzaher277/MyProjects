﻿

angular.module('globalApp')
    .controller('RecieveCashSafeController', function ($scope, $mdDialog, $http, $rootScope, $cookies) {

        // Daily Transaction Variables
        $scope.RecieveCashSafes = [];
        $scope.RecieveCashSafe = {};

        $scope.RecieveCashSafeDetails = [];
        $scope.RecieveCashSafeDetail = {};

        $scope.TotalDepit = 0;
        $scope.TotalCredit = 0;
        $scope.RecieveCashSafeSearch = "";

        $scope.SelectedCustomer = {};

        $scope.SelectedSupplier = {};
        // ddl variables
        $scope.Currencies = [];
        $scope.Currency = {};
        $scope.ChartOfAccounts = [];
        $scope.TransactionTypes = [];
        //$scope.ChartOfAccount = { IsGroup: true };
        $scope.ChartOfAccountsFilter = "";
        $scope.Safe = {};


        $scope.selected = [];
        $scope.AddNew = false;
        $scope.ShowPrint = false;
        $scope.Receipt = {};

        //$scope.cItem = {};

        // run at startup
        loadCurrencies();
        $scope.getChartOfAccountTree();
        getReceiptLogs();

        function getReceiptLogs() {
            $http.get('/RecieveCashSafe/getReceiptLogs').success(function (results) {
                $scope.RecieveCashSafes = results;

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };

        // Chart Of Account Dialog Functions
        //---------------------------------------------- this function transfer to app.js--------------------------------
        //function getChartOfAccountTree() {
        //    $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
        //        $scope.ChartOfAccounts = results.treeObj;
        //    }).error(function () {
        //        $rootScope.$emit("swAlertError", {});
        //    });
        //};

        $scope.AddNewAutoTransactionSetting = function () {
            if ($scope.ChartOfAccounts.length <= 0) {
                $scope.getChartOfAccountTree();
            }
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '../../Areas/accounting/templates/DailyTransactionChartOfAccount.tmpl.html',
                onRemoving: function () {
                    $scope.cancelChartOfAccountsDialog();
                },
                clickOutsideToClose: true,
                openFrom: '.addButton',
                closeTo: '.addButton'
            });
        }

        function getChartOfAccountTreeDetail() {
            $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
                $scope.ChartOfAccountsDetails = results.treeObj;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };

        $scope.selectNode = function (node) {
            $scope.ChartOfAccount = node.$modelValue;
        }

        $scope.findNodes = function (item) {
            $scope.ChartOfAccountsFilter = item.ChartOfAccountsFilter;
        };

        $scope.chooseChartOfAccount = function () {
            $scope.RecieveCashSafe.ChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
            $scope.RecieveCashSafe.ChartOfAccount_CashNameAr = $scope.ChartOfAccount.Name;
            $scope.RecieveCashSafe.AccountCode = $scope.ChartOfAccount.AccountCode;
            $scope.cancelChartOfAccountsDialog();
        };

        $scope.FilterChartOfAccounts = function (item) {
            return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
        };

        $scope.cancelChartOfAccountsDialog = function () {
            $mdDialog.cancel();
            $scope.ChartOfAccount = { IsGroup: true };
            $scope.ChartOfAccountsFilter = "";
        };

        $scope.cancel = function () {
            //   $mdDialog.cancel();

            //$scope.AddNew = false;

            HideMasterShowDetails('#DivSave', '#DivShow');

            $scope.RecieveCashSafe = {};
            $scope.selected = [];

            $scope.RecieveCashSafeDetails = [];
            $scope.RecieveCashSafeDetail = {};
        };

        // Daily Transaction Functions
        $scope.showAdvancedAdd = function (ev) {
            //  $("DivShow)

            //$scope.AddNew = true;

            HideMasterShowDetails('#DivShow', '#DivSave');
            $scope.getChartOfAccountTree();

            // $scope.getShipping_Ways();
            //$scope.getAllProductsModal();

        };

        $scope.removeFilter = function () {
            $scope.filter.show = false;
            $scope.query.filter = '';

            if ($scope.filter.form.$dirty) {
                $scope.filter.form.$setPristine();
            }
        };

        $scope.limitOptions = [5, 10, 15];
        $scope.options = {
            pageSelect: true
        };
        $scope.query = {
            Invoice: 'name',
            filter: '',
            limit: 5,
            page: 1
        };

        $scope.getCurrency = function (CurrencyID) {
            $http.get('/Currency/getCurrencyByID?id=' + CurrencyID).success(function (data) {
                $scope.RecieveCashSafe.Currency_Convert = data.ConvertValue;
            });
        };

        $scope.save = function () {

            if ($scope.RecieveCashSafe.group1 == 1) {
                $scope.RecieveCashSafe.CreditAccountID = $scope.SelectedCustomer.ChartOfAccountID;
                $scope.Receipt.CustomerID = $scope.SelectedCustomer.CustID;
                $scope.RecieveCashSafe.Note = "تم استلام مبلغ " + $scope.RecieveCashSafe.Amount + "  من العميل  " + $scope.SelectedCustomer.NameAr;
            }
            else if ($scope.RecieveCashSafe.group1 == 2) {
                $scope.RecieveCashSafe.CreditAccountID = $scope.SelectedSupplier.ChartOfAccountID;
                $scope.Receipt.SupplierID = $scope.SelectedSupplier.supplierID;
                $scope.RecieveCashSafe.Note = "تم استلام مبلغ " + $scope.RecieveCashSafe.Amount + "من المورد" + $scope.SelectedSupplier.NameAr;

            }
            else if ($scope.RecieveCashSafe.group1 == 3) {
                $scope.RecieveCashSafe.CreditAccountID = $scope.RecieveCashSafe.ChartOfAccountID;
                $scope.Receipt.ChartOfAccountID = $scope.RecieveCashSafe.ChartOfAccountID;
                $scope.RecieveCashSafe.Note = "تم استلام مبلغ " + $scope.RecieveCashSafe.Amount + "من حساب رقم" + $scope.RecieveCashSafe.AccountCode;

            }

            $scope.RecieveCashSafe.DepitAccountID = $scope.Safe.ChartOfAccount_Cash;
            $scope.Receipt.SafeID = $scope.Safe.SafeID;
            $scope.Receipt.Amount = $scope.RecieveCashSafe.Amount;
            $scope.Receipt.CurrencyID = $scope.RecieveCashSafe.CurrencyID;
            $scope.Receipt.Currency_Convert = $scope.RecieveCashSafe.Currency_Convert;
            $scope.Receipt.ReceiptTypeID = 2;
            $scope.Receipt.ReceiptNumber = $scope.RecieveCashSafe.ReceiptNumber;
            $scope.Receipt.ReceiptDate = $scope.RecieveCashSafe.ReceiptDate;

            var params = {
                CustomDailyTransaction: $scope.RecieveCashSafe,
                ReceiptLog: $scope.Receipt
            }

            $http.post("/Accounting/RecieveCashSafe/saveTransaction", params).success(function (result) {

                $scope.checkReport(result);

                //$scope.RecieveCashSafe = {};
                //$scope.SelectedSupplier = {};
                //$scope.SelectedCustomer = {};
                //$scope.ChartOfAccount = {};
                //$scope.Safe = {};
                //getReceiptLogs();
                //$scope.Receipt = {};

                //$scope.RecieveCashSafe.group1 = 0;
                //$rootScope.$emit("swAlertSave", {});
                //$scope.AddNew = false;

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            })
        }
        ///////edit
        $scope.edit = function (ReceiptID) {
            loadCurrencies();
            $scope.getSafes();
            $http.get('/RecieveCashSafe/getReceiptLogByID?id=' + ReceiptID).success(function (data) {                

                $scope.RecieveCashSafe = data;
                $scope.Receipt = data;

                $scope.Safe.NameAr = $scope.RecieveCashSafe.safeName;
                $scope.Safe.SafeNameAr = $scope.RecieveCashSafe.safeName;

                if ($scope.RecieveCashSafe.CustomerID != null) {
                    $scope.loadCustomers();
                    $scope.SelectedCustomer.NameAr = $scope.RecieveCashSafe.CustomerName;
                    $scope.RecieveCashSafe.group1 = 1

                }
                else if ($scope.RecieveCashSafe.SupplierID != null) {
                    $scope.getSuppliers();
                    $scope.SelectedSupplier.NameAr = $scope.RecieveCashSafe.SupplierName;
                    $scope.RecieveCashSafe.group1 = 2
                }
                else if ($scope.RecieveCashSafe.ChartOfAccountID != null) {
                    $scope.getChartOfAccountTree();
                    $scope.RecieveCashSafe.ChartOfAccount_CashNameAr = $scope.RecieveCashSafe.AccountNameAr;
                    $scope.RecieveCashSafe.group1 = 3
                }

                //$scope.AddNew = true;
                $scope.ShowPrint = true;

                HideMasterShowDetails('#DivShow', '#DivSave');

            });
        };


        // ddl Functions
        $scope.getSafes = function () {
            $http.get('Accounting/Transfer/GetALLSafes').success(function (results) {
                $scope.Safes = results;
                for (var i = 0; i < $scope.Safes.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Safes[i].Title = $scope.Safes[i].SafeNameAr;
                    }
                    else {
                        $scope.Safes[i].Title = $scope.Safes[i].SafeNameEn;
                    }
                }
            }).error(function (data, status, headers, config) {
                $rootScope.$emit("swAlertError", {});
            });
        };

        function loadCurrencies() {
            if ($scope.Currencies.length <= 0) {
                $http.get('/Accounting/Currency/GetCurrencies').success(function (results) {
                    $scope.Currencies = results;
                    for (var i = 0; i < $scope.Currencies.length; i++) {
                        if ($cookies.get('ERP_lang') == 'ar-EG') {
                            $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                        }
                        else {
                            $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                        }
                    }
                }).error(function () {
                    $rootScope.$emit("swAlertError", {});
                });
            }
        }

        $scope.getSuppliers = function (viewValue) {
            $http.get('/Administration/Supplier/GetSuppliers').success(function (results) {
                $scope.Suppliers = results;

                for (var i = 0; i < $scope.Suppliers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Suppliers[i].Title = $scope.Suppliers[i].NameAr;
                    }
                    else {
                        $scope.Suppliers[i].Title = $scope.Suppliers[i].NameEng;
                    }
                }
            }).error(function (data, status, headers, config) {
                $rootScope.$emit("swAlertError", {});
            });
        };

        $scope.searchTerm = '';
        $scope.clearSearchTerm = function () {
            $scope.searchTerm = '';
        };

        $scope.loadCustomers = function () {

            $http.get('/Administration/Customer/GetCustomers').success(function (results) {
                $scope.Customers = results;
                for (var i = 0; i < $scope.Customers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Customers[i].Title = $scope.Customers[i].NameAr;
                    }
                    else {
                        $scope.Customers[i].Title = $scope.Customers[i].NameEng;
                    }
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });

        };

        $scope.checkReport = function (ReceiptLogID) {

            if (ReceiptLogID != undefined || $scope.Receipt.ReceiptLogID != undefined) {

                if ($scope.Receipt.ReceiptLogID != undefined)
                    ReceiptLogID = $scope.Receipt.ReceiptLogID;

                $http.get('/Currency/getCurrencyByID/' + $scope.RecieveCashSafe.CurrencyID).success(function (data) {
                    $scope.Currency = data;

                    var AccountName = "";

                    if ($scope.RecieveCashSafe.group1 == 1) {
                        //if ($scope.ShowPrint = true) {
                        //    AccountName = "(العميل)" + $scope.SelectedCustomer;
                        //    $scope.RecieveCashSafe.Note = " تم استلام مبلغ " + $scope.RecieveCashSafe.Amount + " من العميل " + $scope.SelectedCustomer;
                        //}
                        //else {
                        AccountName = "(العميل)" + $scope.SelectedCustomer.NameAr;
                        $scope.RecieveCashSafe.Note = " تم استلام مبلغ " + $scope.RecieveCashSafe.Amount + " من العميل " + $scope.SelectedCustomer.NameAr;
                        //}

                    }
                    else if ($scope.RecieveCashSafe.group1 == 2) {

                        //if ($scope.ShowPrint = true) {
                        //    AccountName = "(المورد)" + $scope.SelectedSupplier;
                        //    $scope.RecieveCashSafe.Note = " تم استلام مبلغ " + $scope.RecieveCashSafe.Amount + " من المورد " + $scope.SelectedSupplier;
                        //}
                        //else {
                        AccountName = "(المورد)" + $scope.SelectedSupplier.NameAr;
                        $scope.RecieveCashSafe.Note = " تم استلام مبلغ " + $scope.RecieveCashSafe.Amount + " من المورد " + $scope.SelectedSupplier.NameAr;
                        //}          
                    }
                    else if ($scope.RecieveCashSafe.group1 == 3) {
                        AccountName = $scope.RecieveCashSafe.ChartOfAccount_CashNameAr;
                        $scope.RecieveCashSafe.Note = " تم استلام مبلغ " + $scope.RecieveCashSafe.Amount + "  من حساب رقم " + $scope.RecieveCashSafe.AccountCode;

                    }


                    var reportParams = {
                        "Parms": { "Title": "ايصال استلام نقدية الى الخزنة", "ReceiptLogID": ReceiptLogID, "SafeName": $scope.Safe.SafeNameAr, "AccountName": AccountName, "Amount": $scope.RecieveCashSafe.Amount, "Currency": $scope.Currency.NameAr, "Note": $scope.RecieveCashSafe.Note },
                        "ReportName": "CashSafeReceipt.trdx"
                    };

                    //$("#reportTest").load('/report', JSON.stringify(reportParams));

                    $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

                        var x = window.open();
                        x.document.open();
                        x.document.write(results);
                        x.document.close();

                        //$('#reportTest').html(results);
                    })
                    //$scope.AddNew = false;
                    $scope.ShowPrint = false;

                    //$scope.Receipt = {};
                    //$scope.RecieveCashSafe = {};
                    //$scope.selected = [];

                    HideMasterShowDetails('#DivSave', '#DivShow');

                    $scope.RecieveCashSafe = {};
                    $scope.SelectedSupplier = {};
                    $scope.SelectedCustomer = {};
                    $scope.ChartOfAccount = {};
                    $scope.Safe = {};
                    getReceiptLogs();
                    $scope.Receipt = {};

                    $scope.RecieveCashSafe.group1 = 0;
                    $rootScope.$emit("swAlertSave", {});
                    $scope.AddNew = false;

                });

            }
        }

    });