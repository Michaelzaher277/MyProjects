﻿

angular.module('globalApp')
.controller('TransferController', function ($scope, $mdDialog, $http, $rootScope, $element, $cookies) {

    $scope.Transfer = {};

    $scope.Safes = [];
    $scope.Banks = [];
    $scope.BankBranches = [];
    $scope.BankBranchAccounts = [];

    $scope.SelectedFromSafeCash = {};
    $scope.SelectedFromSafeCheque = {};
    $scope.SelectedFromBank = {};

    $scope.SelectedToSafeCash = {};
    $scope.SelectedToSafeCheque = {};
    $scope.SelectedToBank = {};

    $scope.Currencies = [];

    $scope.ChartOfAccounts = [];
    //$scope.TransactionTypes = [];
    $scope.ChartOfAccount = { IsGroup: true };
    $scope.ChartOfAccountsFilter = "";

    $scope.ChartOfAccountsTo = [];

    $scope.ChartOfAccountTo = { IsGroup: true };
    $scope.ChartOfAccountsFilterTo = "";

    //loadCurrencies();
    //getChartOfAccountTree();

    $scope.getChartOfAccountTree = function () {
        $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
            $scope.ChartOfAccounts = results.treeObj;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.getChartOfAccountTreeTo = function () {
        $http.get('/Accounting/ChartOfAccounts/getChartOfAccountsTree').success(function (results) {
            $scope.ChartOfAccountsTo = results.treeObj;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.selectNode = function (node) {
        $scope.ChartOfAccount = node.$modelValue;
    }

    $scope.selectNodeTo = function (node) {
        $scope.ChartOfAccountTo = node.$modelValue;
    }

    $scope.findNodes = function (item) {
        $scope.ChartOfAccountsFilter = item.ChartOfAccountsFilter;
    };

    $scope.findNodesTo = function (item) {
        $scope.ChartOfAccountsFilterTo = item.ChartOfAccountsFilterTo;
    };

    //$scope.chooseChartOfAccount = function () {
    //    $scope.Transfer.ChartOfAccountName = $scope.ChartOfAccount.Name;
    //    $scope.Transfer.ChartOfAccountID = $scope.ChartOfAccount.ChartOfAccountID;
    //    $scope.Transfer.ChartOfAccountCode = $scope.ChartOfAccount.AccountCode;
    //};

    $scope.FilterChartOfAccounts = function (item) {
        return (item.Name.indexOf($scope.ChartOfAccountsFilter) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilter) != -1);
    };

    $scope.FilterChartOfAccountsTo = function (item) {
        return (item.Name.indexOf($scope.ChartOfAccountsFilterTo) != -1 || item.AccountCode.indexOf($scope.ChartOfAccountsFilterTo) != -1);
    };

    //$scope.cancelChartOfAccountsDialog = function () {
    //    $mdDialog.cancel();
    //    $scope.ChartOfAccount = { IsGroup: true };
    //    $scope.ChartOfAccountsFilter = "";
    //};

    $scope.LoadFromTree = function () {
        $scope.getChartOfAccountTree();
    }

    $scope.LoadToTree = function () {
        $scope.getChartOfAccountTreeTo();
    }

    $scope.loadCurrencies = function () {
        if ($scope.Currencies.length <= 0) {
            $http.get('/Accounting/Currency/GetCurrencies').success(function (results) {
                $scope.Currencies = results;
                for (var i = 0; i < $scope.Currencies.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameAr;
                    }
                    else {
                        $scope.Currencies[i].Title = $scope.Currencies[i].NameEng;
                    }
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    }

    $scope.getSafes = function () {
        $http.get('Accounting/Transfer/GetALLSafes').success(function (results) {
            $scope.Safes = results;
            for (var i = 0; i < $scope.Safes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Safes[i].Title = $scope.Safes[i].SafeNameAr;
                }
                else {
                    $scope.Safes[i].Title = $scope.Safes[i].SafeNameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    // Bank Branches Functions
    $scope.getBanks = function () {
        $http.get('/Accounting/Banks/getBanks').success(function (results) {
            $scope.Banks = results;
            for (var i = 0; i < $scope.Banks.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Banks[i].Title = $scope.Banks[i].NameAr;
                }
                else {
                    $scope.Banks[i].Title = $scope.Banks[i].NameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.getBankBranches = function (id) {
        if (id != undefined) {
            $http.get('/Accounting/BankBranches/getBankBranchesByBankID/' + id).success(function (results) {
                $scope.BankBranches = results;
                for (var i = 0; i < $scope.BankBranches.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.BankBranches[i].Title = $scope.BankBranches[i].NameAr;
                    }
                    else {
                        $scope.BankBranches[i].Title = $scope.BankBranches[i].NameEn;
                    }
                }
                $scope.BranchID = null;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.getBankBranchAccounts = function (id) {
        if (id != undefined) {
            $http.get('/Accounting/BankBranchAccounts/getBankBranchAccountsByBankBranchID/' + id).success(function (results) {
                $scope.BankBranchAccounts = results;
                for (var i = 0; i < $scope.BankBranchAccounts.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameAr;
                    }
                    else {
                        $scope.BankBranchAccounts[i].Title = $scope.BankBranchAccounts[i].NameEn;
                    }
                }
                $scope.BranchID = null;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.savediag = function () {
        $scope.save();
    };

    $scope.save = function () {

        if ($scope.Transfer.TransferFrom == 1){
            if ($scope.Transfer.IsChequeFrom){
                $scope.Transfer.CreditAccountID = $scope.SelectedFromSafeCheque.ChartOfAccount_Cheque;
            }
            else{
                $scope.Transfer.CreditAccountID = $scope.SelectedFromSafeCash.ChartOfAccount_Cash;
            }
        }
        else if ($scope.Transfer.TransferFrom == 2){
            $scope.Transfer.CreditAccountID = $scope.SelectedFromBank.ChartOfAccount_Cash;
        }
        else if ($scope.Transfer.TransferFrom == 3){
            $scope.Transfer.CreditAccountID = $scope.ChartOfAccount.ChartOfAccountID;
        }


        if ($scope.Transfer.TransferTo == 1){
            if ($scope.Transfer.IsChequeTo) {
                $scope.Transfer.DepitAccountID = $scope.SelectedToSafeCheque.ChartOfAccount_Cheque;
            }
            else {
                $scope.Transfer.DepitAccountID = $scope.SelectedToSafeCash.ChartOfAccount_Cash;
            }
        }
        else if ($scope.Transfer.TransferTo == 2) {
            $scope.Transfer.DepitAccountID = $scope.SelectedToBank.ChartOfAccount_Cash;
        }
        else if ($scope.Transfer.TransferTo == 3) {
            $scope.Transfer.DepitAccountID = $scope.ChartOfAccountTo.ChartOfAccountID;
        }


        $http.post("/Accounting/Transfer/saveTransaction", $scope.Transfer).success(function () {
            $scope.Transfer = {};

            $scope.Transfer.Amount = undefined;

            $scope.Transfer.IsChequeFrom = 0;
            $scope.Transfer.IsChequeTo = 0;

            $scope.SelectedFromSafeCheque = {};
            $scope.SelectedToSafeCheque = {};

            $scope.SelectedFromSafeCash = {};
            $scope.SelectedToSafeCash = {};

            $scope.SelectedFromBank = {};
            $scope.SelectedToBank = {};

            $scope.ChartOfAccount = {};
            $scope.ChartOfAccountTo = {};

            $rootScope.$emit("swAlertSave", {});

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        })

    };    

    $scope.ResetSafe = function () {
        if ($scope.Transfer.IsChequeFrom)
        {
            $scope.Transfer.FromChartOfAccount_Cash = undefined;
        }
        else
        {
            $scope.Transfer.FromChartOfAccount_Cheque = undefined;
        }
    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Attendance = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Attendance = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };    

    $scope.limitOptions = [5, 10, 15];

    $scope.options = {
        pageSelect: true
    };

    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

});