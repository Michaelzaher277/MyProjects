﻿angular.module('globalApp')
.controller('Sales_PriceOfferController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $element, $filter) {
    $scope.PriceOffers = [];
    $scope.PriceOffer = {};

    $scope.Sales_PriceOfferDetails = [];
    $scope.Sales_PriceOfferDetail = {};

    $scope.Selected = [];
    $scope.DetailSelected = [];

    $scope.PaymentTypes = [];
    $scope.selectedProduct = [];
    $scope.selectedDetails = [];
    $scope.Sum = {};

    $scope.Sum.TotalQuantity = 0;
    $scope.Sum.Amount = 0;
    $scope.Sum.Discount = 0;
    $scope.Sum.TotalPrice = 0;
    $scope.Sum.Taxes = 0;
    $scope.Sum.TaxesDiscount = 0;
    $scope.Sum.TotalCost = 0;
    $scope.Sum.TotalInvoice = 0;
    $scope.Sum.NetTotalPrice = 0;
    $scope.Setting = {};

    $scope.Customers = [];

    $scope.getSetting = function () {
        $http.get('/AccountingSettings/getAccountingSettings').success(function (results) {
            $scope.Setting = results;
        })
    };

    $scope.getSetting();
    getInvoicePayments();

    function getInvoicePayments() {
        $http.get('/Sales_Invoice/getPaymentTypes').success(function (results) {
            $scope.PaymentTypes = results;
            for (var i = 0; i < $scope.PaymentTypes.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameAr;
                }
                else {
                    $scope.PaymentTypes[i].Title = $scope.PaymentTypes[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };


    $element.find('input#searchCustomers').on('keydown', function (ev) {
        ev.stopPropagation();
    });

    $scope.stopPropSearch = function () {
        $element.find('.searchProducts').on('keydown', function (ev) {
            ev.stopPropagation();
        });
    }

    $scope.CustomerSearchTerm;
    $scope.PartsSearchTerm;

    $scope.loadCustomers = function () {
        if ($scope.Customers.length <= 0) {
            $http.get('/Administration/Customer/GetCustomers').success(function (results) {
                $scope.Customers = results;

                for (var i = 0; i < $scope.Customers.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Customers[i].Title = $scope.Customers[i].NameAr;
                    }
                    else {
                        $scope.Customers[i].Title = $scope.Customers[i].NameEng;
                    }
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.loadCustomers();

    $scope.showAdvancedAdd = function (ev) {
        HideMasterShowDetails('#divMasterData', '#divDetailsData');

        getLastCodeInvoices();

        $scope.TotalQuantity = 0;
        $scope.Amount = 0;
        $scope.Discount = 0;
        $scope.Taxes = 0;
        $scope.TaxesDiscount = 0;
    };
    function getLastCodeInvoices() {
        $http.get('/Sales_PriceOffer/GetLastCodeInvoices').success(function (results) {
            $scope.PriceOffer.PriceOfferCode = results;
            $scope.PriceOffer.PriceOfferDate = new Date();;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    getPriceOffers();
    function clearFields() {
        $scope.PriceOffer = {};
        $scope.Sales_PriceOfferDetails = [];
        $scope.Sales_PriceOfferDetail = {};
        $scope.Selected = [];
        $scope.selectedDetails = [];
        $scope.Sum = {};

        $scope.Sum.TotalQuantity = 0;
        $scope.Sum.Amount = 0;
        $scope.Sum.Discount = 0;
        $scope.Sum.TotalPrice = 0;
        $scope.Sum.Taxes = 0;
        $scope.Sum.TaxesDiscount = 0;
        $scope.Sum.TotalCost = 0;
        $scope.Sum.TotalInvoice = 0;
        $scope.Sum.NetTotalPrice = 0;
    };


    // End Select2 drop down lists //

    function getPriceOffers() {
        $http.get('/Sales_PriceOffer/getAllPriceOffers').success(function (results) {
            $scope.PriceOffers = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function getPriceOfferDetailsByPriceOfferID(PriceOfferID) {
        $http.get('/Sales_PriceOffer/getPriceOfferDetailsByPriceOfferID/' + PriceOfferID).success(function (results) {
            $scope.Sales_PriceOfferDetails = results;
            for (var i = 0; i < $scope.Sales_PriceOfferDetails.length; i++) {
                $scope.getMeasureUnit($scope.Sales_PriceOfferDetails[i].PartID);
                $scope.Sales_PriceOfferDetails[i].MeasureUnits = $scope.MeasureUnits;
                $scope.getRowPrices($scope.Sales_PriceOfferDetails[i]);

            }
            //     $scope.getInvoiceTypes();
            $scope.getTotalQuantity();
            $scope.getPrice();
            $scope.getTaxes();
            $scope.getDiscount();
            $scope.getTaxesDiscount();
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.save = function () {
        $scope.PriceOffer.Sales_PriceOfferDetails = $scope.Sales_PriceOfferDetails;

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.PriceOffer),
            url: '/Sales_PriceOffer/savePriceOffer',
            success: function () {
                getPriceOffers();
                HideMasterShowDetails("#divDetailsData", "#divMasterData");
                clearFields();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.edit = function (model) {
        $scope.loadCustomers();
        $scope.PriceOffer = model
        getPriceOfferDetailsByPriceOfferID(model.PriceOfferID);
        HideMasterShowDetails('#divMasterData', '#divDetailsData');
        $scope.getTotalQuantity();
        $scope.getPrice();
        $scope.getTaxes();
        $scope.getDiscount();
        $scope.getTaxesDiscount();
    };

    $scope.delete = function () {
        $rootScope.$emit("swConfirmDelete",
    {
        function () {
            var fromDB = [];
            for (var i = 0; i < $scope.Selected.length; i++) {
                if ($scope.Selected[i].PriceOfferID != undefined && $scope.Selected[i].PriceOfferID != 0)
                    fromDB.push($scope.Selected[i]);
                $scope.PriceOffers.splice($.inArray($scope.Selected[i], $scope.PriceOffers), 1);
            }
            if (fromDB.length > 0) {
                $http.post('/Sales_PriceOffer/deletePriceOffer', JSON.stringify(fromDB)).success(function (results) {
                });
            }
            $scope.Selected = [];
        }
    });
    }
    $scope.deleteDetail = function (model) {
        swConfirmDeleteAr({
            function () {
                $scope.Sales_PriceOfferDetails.splice($.inArray(model, $scope.Sales_PriceOfferDetails), 1);

                $scope.$apply();
                $scope.selectedDetails = [];
                $scope.getTotalQuantity();
                $scope.getPrice();
                $scope.getDiscount();
                $scope.getTaxes();
                $scope.getTaxesDiscount();
                $scope.getNetTotalPrice();
            }
        });
    }

    $scope.getMeasureUnit = function (productID) {
        $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
            $scope.MeasureUnits = results;
            for (var i = 0; i < $scope.MeasureUnits.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
                }
                else {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEn;
                }
            }


            for (var i = 0; i < $scope.Sales_PriceOfferDetails.length; i++) {
                if ($scope.Sales_PriceOfferDetails[i].PartID == productID)
                    $scope.Sales_PriceOfferDetails[i].MeasureUnits = $scope.MeasureUnits;
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.getProductModal = function (modal) {

        for (i = 0; i < modal.length; i++) {
            if (modal[i].ProductID != null) {
                var item = {};
                item.PartID = modal[i].ProductID;
                item.PartName = modal[i].NameAr;
                item.PartCode = modal[i].Code;
                item.MeasureUnits = modal[i].MeasureUnits;

                //$scope.getSetting();
                for (var j = 0; j < item.MeasureUnits.length; j++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                    }
                    else {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                    }
                }

                if ($scope.Setting != undefined) {
                    item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                    item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                }
                else {
                    $scope.getSetting();
                    if ($scope.Setting != undefined) {
                        item.Taxes = $scope.Setting.PurchaseInvoiceAmount;
                        item.TaxesDiscount = $scope.Setting.PurchaseDiscountInvoiceAmount;
                    }
                }

                var foundItem = $filter('filter')($scope.Sales_PriceOfferDetails, { PartCode: modal[i].Code }, true)[0];

                if (foundItem == undefined) {
                    $scope.Sales_PriceOfferDetails.push(item);
                }
                ///  $scope.Sales_PriceOfferDetails.push(item);
            }
        }
        //$scope.cancelProduct();

        // $('#DivParts').modal('toggle');
    };

    $scope.getAllProductsModal = function () {
        $http.get('/Inventory/ProductDetails/GetProducts').success(function (results) {
            $scope.Products = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    $scope.showProductsAdd = function (ev) {
        //  $("DivShow)
        //   $scope.Sales_PriceOfferDetails.push({});
        //  $scope.getAllProductsModal();
        $scope.GetTopProducts("");

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadProducts.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addProduct',
            closeTo: '.addProduct'
        })

    };


    $scope.cancelDialog = function () {

        $mdDialog.cancel();
    };

    $scope.cancelProduct = function () {
        //$scope.AddNew = true;

        $mdDialog.cancel();
        $scope.selectedProduct = [];
    };
    $scope.cancel = function () {
        clearFields();
        getPriceOffers();
        HideMasterShowDetails('#divDetailsData', '#divMasterData');

    }

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';
        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
        getSupplyOrders();

    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

    $scope.DetailsOptions = {
        pageSelect: true
    };
    $scope.DetailsQuery = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

    $scope.getTotalQuantity = function () {       
        $scope.Sum.TotalQuantity = 0;
        $.each($scope.Sales_PriceOfferDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Quantity))) {
                if (item.TotalQuantityFromChild != undefined)
                    $scope.Sum.TotalQuantity += parseFloat(item.Quantity) * parseFloat(item.TotalQuantityFromChild);
                else
                    $scope.Sum.TotalQuantity += parseFloat(item.Quantity);
            }
        });

    }

    $scope.checkQuantity = function (model) {
        $http.get('/Inventory/ProductDetails/CheckQuantityByBranchID2?productID=' + model.PartID).success(function (results) {
            model.AvailableQuantity = results;            
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.GetLastProductPriceByBranch = function (model) {
        $http.get('/Inventory/ProductDetails/GetLastProductPriceByBranchID?&productID=' + model.PartID).success(function (results) {
            model.LastPrice = results;
        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.getPrice = function () {
        $scope.Sum.Amount = 0;

        $.each($scope.Sales_PriceOfferDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Price))) {
                $scope.Sum.Amount += parseFloat(item.Price);
            }
        });
    }

    $scope.getDiscount = function () {
        $scope.Sum.Discount = 0;

        $.each($scope.Sales_PriceOfferDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Discount))) {
                $scope.Sum.Discount += parseFloat(item.Discount);
            }
        });
    }


    $scope.getTaxes = function () {
        $scope.Sum.Taxes = 0;

        $.each($scope.Sales_PriceOfferDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Taxes))) {
                $scope.Sum.Taxes += parseFloat(item.Taxes);
            }
        });
    }

    $scope.getTaxesDiscount = function () {
        $scope.Sum.TaxesDiscount = 0;
        $.each($scope.Sales_PriceOfferDetails, function (i, item) {
            if (!isNaN(parseFloat(item.TaxesDiscount))) {
                $scope.Sum.TaxesDiscount += parseFloat(item.TaxesDiscount);
            }
        });
    }




    $scope.getNetTotalPrice = function () {
        $scope.Sum.NetTotalPrice = 0;
        $.each($scope.Sales_PriceOfferDetails, function (i, item) {
            if (!isNaN(parseFloat(item.TotalPrice))) {
                $scope.Sum.NetTotalPrice += parseFloat(item.TotalPrice);
            }
        });

    }

    $scope.getTotalCost = function () {
        $scope.Sum.TotalCost = $scope.Sum.NetTotalPrice;
        $.each($scope.Sales_PriceOfferExpenses, function (i, item) {
            if (!isNaN(parseFloat(item.Amount)) && item.IsAddCost) {
                $scope.Sum.TotalCost += parseFloat(item.Amount);
            }
        });

    }

    $scope.getTotalInvoice = function () {
        $scope.Sum.TotalInvoice = $scope.Sum.NetTotalPrice;;
        $.each($scope.Sales_PriceOfferExpenses, function (i, item) {
            if (!isNaN(parseFloat(item.Amount)) && item.IsInvoice_Expense) {
                $scope.Sum.TotalInvoice += parseFloat(item.Amount);
            }
        });
        //if (!isNaN(parseFloat($scope.Sum.TotalInvoice)) && !isNaN(parseFloat($scope.Sum.TotalCost)))
        //    $scope.Sales_PriceOffer.Cost_Factor = $scope.Sum.TotalCost / $scope.Sum.TotalInvoice;
    }

    $scope.getRowPrices = function (item) {
        var Quantity = 0;
        var Price = 0;
        var Discount = 0;
        var Taxes = 0;
        var TaxesDiscount = 0;
        var TotalQuantityFromChild=1;
        if(item.TotalQuantityFromChild != undefined)
            TotalQuantityFromChild=item.TotalQuantityFromChild 
        if (item.Quantity != undefined)
            Quantity = item.Quantity * TotalQuantityFromChild;
        else
            Quantity = 0;

        if (item.Price != undefined)
            Price = item.Price;
        else
            Price = 0;

        if (item.Discount != undefined)
            Discount = ((Quantity * Price) * item.Discount) / 100;
        else
            Discount = 0;

        if (item.Taxes != undefined)
            Taxes = ((Quantity * Price) * item.Taxes) / 100;
        else
            Taxes = 0;

        //if (item.TaxesDiscount != undefined)
        //    TaxesDiscount = ((Quantity * Price) * item.TaxesDiscount) / 100;
        //else
        //    TaxesDiscount = 0;

        if (item.TaxCommercialIndustrialProfits != undefined)
            TaxesDiscount = ((Quantity * Price) * item.TaxCommercialIndustrialProfits) / 100;
        else
            TaxesDiscount = 0;

        item.TotalPrice = ((Quantity * Price) + Taxes - TaxesDiscount - Discount).toString();
        $scope.getNetTotalPrice();
    }

    $scope.checkReport = function (PriceOfferID) {

        if (PriceOfferID != undefined) {

            var
                reportParams = {
                    "Parms": {
                        "PriceOfferID": PriceOfferID

                    },
                    "ReportName": "StockReport/PriceOfferReport.trdx"
                };

            $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

                var x = window.open();
                x.document.open();
                x.document.write(results);
                x.document.close();
            })
        }
    }

    $scope.GetMeasureUnitQuanity = function (model) {
        $http.get('/Inventory/ProductDetails/GetMeasureUnitQuantity?ProductID=' + model.PartID + '&MeasureID=' + model.MeasureUnitID).success(function (results) {
            model.TotalQuantityFromChild = results;

            $scope.getRowPrices(model);
            $scope.getPrice();
            $scope.getTotalQuantity();

        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };
});