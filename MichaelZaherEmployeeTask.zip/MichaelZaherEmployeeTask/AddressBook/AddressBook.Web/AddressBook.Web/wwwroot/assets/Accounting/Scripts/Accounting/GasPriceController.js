﻿
angular.module('globalApp')
.controller('GasPriceController', function ($scope, $mdDialog, $http, $rootScope,$cookies) {

    $scope.GasPrices = [];
    $scope.GasPrice = {};

    $scope.selected = [];

    $scope.Cities = [];

    getGasPrices();


    function getGasPrices() {
        $http.get('/Accounting/GasPrice/GetGasPrices').success(function (results) {
            $scope.GasPrices = results;

            for (var i = 0; i < $scope.GasPrices.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.GasPrices[i].CityName = $scope.GasPrices[i].CityNameAr;
                }
                else {
                    $scope.GasPrices[i].CityName = $scope.GasPrices[i].CityNameEn;
                }
            }

        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.loadCities = function () {
        if ($scope.Cities.length <= 0) {
            $http.get('/JobOrder/BatteryType/getCities/').success(function (results) {
                $scope.Cities = results;
                for (var i = 0; i < $scope.Cities.length; i++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Cities[i].Title = $scope.Cities[i].CityNameAr;
                    }
                    else {
                        $scope.Cities[i].Title = $scope.Cities[i].CityNameEn;
                    }
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }
    };

    $scope.loadCities();

    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/Accounting/templates/GasPrice.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom : '.addButton',
            closeTo: '.addButton'
        })

    };

    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/Accounting/templates/GasPrice.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.GasPrice = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.GasPrice = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };

    $scope.save = function () {
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.GasPrice),
            url: '/Accounting/GasPrice/save',
            success: function () {
                getGasPrices();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.delete = function (GasPriceID) {
        
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.get('/Accounting/GasPrice/delete/' + GasPriceID).success(function (data) {
                       if (parseInt(data) == -1) {
                           swSorryMessageAr();
                       }
                       getGasPrices();
                       $scope.selected = [];
                   });
               }
           });
    }

    $scope.edit = function (GasPriceID) {
        $http.get('/Accounting/GasPrice/GetByID/' + GasPriceID).success(function (data) {
            $scope.GasPrice = data;
            $scope.showAdvancedEdit();
        });
    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };

    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});