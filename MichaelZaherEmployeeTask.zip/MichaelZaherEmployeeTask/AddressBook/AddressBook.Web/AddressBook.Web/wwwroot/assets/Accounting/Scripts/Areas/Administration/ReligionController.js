﻿
angular.module('globalApp')
.controller('ReligionController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.Religions = [];
    $scope.Religion = {};

    $scope.selected = [];


    $scope.query = {
        order: 'name',
        limit: 5,
        page: 1
    };

    getReligions();

    //function success(desserts) {
    //    $scope.desserts = ['christian', 'Non-christian'];
    //}

    //$scope.getDesserts = function () {
    //  $scope.promise = $nutrition.desserts.get($scope.query, success).$promise;
    //};

    function getReligions() {
        $http.get('/Religion/getReligions').success(function (results) {
            $scope.Religions = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/Religion.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };



    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../templates/Religion.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Religion = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Religion = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Religion),
            url: '/Religion/saveReligion',
            success: function () {
                getReligions();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {
        swConfirmDeleteEn(function () {
            $http.post('/Religion/deleteReligion', JSON.stringify($scope.selected)).success(function () {
                getReligions();
                $scope.selected = [];
            });
        });
    }
    $scope.edit = function (ReligionID) {
        $http.get('/Religion/getReligionByID/' + ReligionID).success(function (data) {
            $scope.Religion = data;
            $scope.showAdvancedEdit();
        });
    };
    $scope.deleteRowCallback = function (rows) {
        swConfirmDeleteWithActions(function () {
            for (var i = 0; i < rows.length; i++) {
                $scope.selected.push({ ReligionID: rows[i], IsDeleted: false });
            }
            //= rows;
            $http.post('/Administration/Religion/deleteReligion', JSON.stringify($scope.selected)).success(function () {

                getReligions();
                $scope.selected = [];
            });
        }, function () {
            $http.get('/Administration/Religion/getReligions').success(function (results) {
                $scope.Religions = results;
            }).error(function () {
                swAlertErrorAr();
            });
        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});