﻿
angular.module('globalApp')
.controller('ExpenseTypeController', function ($scope, $mdDialog, $http, $rootScope) {

    $scope.ExpenseTypes = [];
    $scope.ExpenseType = {};

    $scope.selected = [];

    getExpenseTypes();

    //function success(desserts) {
    //    $scope.desserts = ['christian', 'Non-christian'];
    //}

    //$scope.getDesserts = function () {
    //  $scope.promise = $nutrition.desserts.get($scope.query, success).$promise;
    //};

    function getExpenseTypes() {
        $http.get('/ExpenseType/getExpenseTypes').success(function (results) {
            $scope.ExpenseTypes = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/ExpenseType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom : '.addButton',
            closeTo: '.addButton'
        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/ExpenseType.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.ExpenseType = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.ExpenseType = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {

        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.ExpenseType),
            url: '/ExpenseType/saveExpenseType',
            success: function () {
                getExpenseTypes();
                $scope.cancel();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };
    $scope.delete = function () {
        
        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/ExpenseType/deleteExpenseType', JSON.stringify($scope.selected)).success(function () {
                       getExpenseTypes();
                       $scope.selected = [];
                   });
               }
           });
    }
    $scope.edit = function (ExpenseTypeID) {
        $http.get('/ExpenseType/getExpenseTypeByID/' + ExpenseTypeID).success(function (data) {
            $scope.ExpenseType = data;
            $scope.showAdvancedEdit();
        });
    };
    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };
});