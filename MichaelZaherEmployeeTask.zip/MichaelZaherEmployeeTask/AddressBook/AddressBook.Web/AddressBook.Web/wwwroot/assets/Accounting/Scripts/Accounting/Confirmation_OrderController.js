﻿
angular.module('globalApp')
.controller('Confirmation_OrderController', function ($scope, $mdDialog, $http, $rootScope, $cookies, $filter) {

    $scope.Confirmation_Orders = [];
    $scope.Confirmation_Order = {};
    $scope.Purchase_Orders = [];
  
    $scope.Shipping_Ways=[];
    $scope.OrderTypes = [];

    $scope.selected = [];
    $scope.selectedProduct = [];
    $scope.selectedPurchaseOrder = [];
    $scope.selectedDetails = [];

    $scope.AddNew = false;

    getConfirmation_Orders();
    $scope.Confirmation_OrderDetail = {};
    $scope.Confirmation_OrderDetails = [];

    //  $scope.Products = [];

    $scope.Product = {};

    //function success(desserts) {
    //    $scope.desserts = ['christian', 'Non-christian'];
    //}

    //$scope.getDesserts = function () {
    //  $scope.promise = $nutrition.desserts.get($scope.query, success).$promise;
    //};
   
  

    
    $scope.getShipping_Ways = function () {
        $http.get('/Confirmation_Order/BindShipping_Ways').success(function (results) {
            $scope.Shipping_Ways = results;
            for (var i = 0; i < $scope.Shipping_Ways.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.Shipping_Ways[i].Title = $scope.Shipping_Ways[i].NameAr;
                }
                else {
                    $scope.Shipping_Ways[i].Title = $scope.Shipping_Ways[i].NameEn;
                }
            }
        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    function getLastCodeOrders() {
        $http.get('/Confirmation_Order/GetLastCodeOrders').success(function (results) {
            $scope.Confirmation_Order.OrderCode = results;
            //var today = $filter('date')(new Date(), 'yyyy-MM-dd');
            $scope.Confirmation_Order.OrderDate = new Date();;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    };

    function getConfirmation_Orders() {
        $http.get('/Confirmation_Order/GetALLOrders').success(function (results) {
            $scope.Confirmation_Orders = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
    $scope.showAdvancedAdd = function (ev) {
        //  $("DivShow)

        //$scope.AddNew = true;

        HideMasterShowDetails('#DivShow', '#DivSave');
        getLastCodeOrders();

        //   $scope.getOrderTypes();

        $scope.getShipping_Ways();

        $scope.TotalQuantity = 0;
        $scope.TotalWeightTotal = 0;
        $scope.TotalWeightNet = 0;
        $scope.TotalPrice = 0;

        //$scope.getAllProductsModal();

    };

    // function getMeasureUnit(productID) {
    //    $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
    //        $scope.MeasureUnits = results;
    //        for (var i = 0; i < $scope.MeasureUnits.length; i++) {
    //            if ($cookies.get('ERP_lang') == 'ar-EG') {
    //                $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
    //            }
    //            else {
    //                $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEn;
    //            }
    //        }
    //    }).error(function (data, status, headers, config) {
    //        $rootScope.$emit("swAlertError", {});
    //    });
    //};


    $scope.getProductModal = function (modal) {

        for (i = 0; i < modal.length; i++) {

            if (modal[i].ProductID != null) {
                var item = {};
                item.ProductID = modal[i].ProductID;
                item.ProductName = modal[i].NameAr;
                item.ProductCode = modal[i].Code;
                item.MeasureUnits = modal[i].MeasureUnits;

                for (var j = 0; j < item.MeasureUnits.length; j++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitName;
                    }
                    else {
                        item.MeasureUnits[j].Title = item.MeasureUnits[j].MeasureUnitNameEn;
                    }
                }

                var foundItem = $filter('filter')($scope.Confirmation_OrderDetails, { ProductCode: modal[i].Code }, true)[0];

                if (foundItem == undefined) {
                    $scope.Confirmation_OrderDetails.push(item);
                }

                //$scope.Confirmation_OrderDetails.push(item);
            }
        }


        $scope.selectedProduct = [];
        $scope.selectedPurchaseOrder = [];

        //$scope.cancelProduct();

        // $('#DivParts').modal('toggle');
    };


    $scope.getAllProductsModal = function () {
        $http.get('/Inventory/ProductDetails/GetProducts').success(function (results) {
            $scope.Products = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
    }

    $scope.showProductsAdd = function (ev) {
        //  $("DivShow)
        //   $scope.Confirmation_OrderDetails.push({});
     //   $scope.getAllProductsModal();
        $scope.GetTopProducts("");

        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Demand_LoadProducts.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.addProduct',
            closeTo: '.addProduct'
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Confirmation_Order = {};
    };


    $scope.cancelDialog = function () {

        $mdDialog.cancel();
    };

    $scope.cancelProduct = function () {
        //$scope.AddNew = true;

        $mdDialog.cancel();
        $scope.selectedProduct = [];
        $scope.selectedPurchaseOrder = [];

        //   $scope.Confirmation_Order = {};
    };

    $scope.cancelConfirmation_Order = function () {
        //   $mdDialog.cancel();

        //$scope.AddNew = false;

        HideMasterShowDetails('#DivSave', '#DivShow');

        $scope.selected = [];
        $scope.selectedProduct = [];
        $scope.selectedPurchaseOrder = [];
        $scope.selectedDetails = [];

        $scope.Confirmation_Order = {};
        $scope.Confirmation_OrderDetails = [];

    };


    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };

    $scope.savediag = function () {
        $scope.save();
    };


    $scope.save = function () {
        $scope.Confirmation_Order.Confirmation_OrderDetail = $scope.Confirmation_OrderDetails;
        $.ajax({
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify($scope.Confirmation_Order),
            url: '/Confirmation_Order/save',
            success: function () {
                getConfirmation_Orders();
                $scope.cancelConfirmation_Order();
                $rootScope.$emit("swAlertSave", {});
            },
            error: function () {
                $rootScope.$emit("swAlertError", {});
            }
        });
    };

    $scope.delete = function () {

        $rootScope.$emit("swConfirmDelete",
           {
               function () {
                   $http.post('/Confirmation_Order/deletePurchaseOrder', JSON.stringify($scope.selected)).success(function () {
                       getConfirmation_Orders();
                       $scope.selected = [];
                   });
               }
           });
    }

    function getDetails(OrderID) {
        $http.get('/Confirmation_Order/GetDetailsByOrderID?id=' + OrderID).success(function (results) {
            $scope.Confirmation_OrderDetails = results;

            for (var i = 0; i < $scope.Confirmation_OrderDetails.length; i++) {
                $scope.getMeasureUnits($scope.Confirmation_OrderDetails[i].ProductID);
                $scope.Confirmation_OrderDetails[i].MeasureUnits = $scope.MeasureUnits;
            }

            $scope.TotalQuantity = 0;
            $scope.TotalWeightTotal = 0;
            $scope.TotalWeightNet = 0;
            $scope.TotalPrice = 0;

            $.each($scope.Confirmation_OrderDetails, function (i, item) {

                if (!isNaN(parseFloat(item.Quantity))) {
                    $scope.TotalQuantity += parseFloat(item.Quantity);
                }

                if (!isNaN(parseFloat(item.GrossWeight))) {
                    $scope.TotalWeightTotal += parseFloat(item.GrossWeight);
                }

                if (!isNaN(parseFloat(item.NetWeight))) {
                    $scope.TotalWeightNet += parseFloat(item.NetWeight);
                }

                if (!isNaN(parseFloat(item.Price))) {
                    $scope.TotalPrice += parseFloat(item.Price);
                }

            });

        }).error(function () {
            swAlertErrorAr();
        });
    };

    $scope.getTotalQuantity = function () {

        $scope.TotalQuantity = 0;
        $.each($scope.Confirmation_OrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Quantity))) {
                $scope.TotalQuantity += parseFloat(item.Quantity);
            }
        });
    }

    $scope.getTotalWeightTotal = function () {

        $scope.TotalWeightTotal = 0;
        $.each($scope.Confirmation_OrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.GrossWeight))) {
                $scope.TotalWeightTotal += parseFloat(item.GrossWeight);
            }
        });
    }

    $scope.getTotalWeightNet = function () {

        $scope.TotalWeightNet = 0;
        $.each($scope.Confirmation_OrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.NetWeight))) {
                $scope.TotalWeightNet += parseFloat(item.NetWeight);
            }
        });
    }

    $scope.getTotalPrice = function () {

        $scope.TotalPrice = 0;
        $.each($scope.Confirmation_OrderDetails, function (i, item) {
            if (!isNaN(parseFloat(item.Price))) {
                $scope.TotalPrice += parseFloat(item.Price);
            }
        });
    }

    $scope.getMeasureUnits = function (productID) {
        $http.get('/Purchase_Demand/GetMeasureUnitByProductID?ProductID=' + productID).success(function (results) {
            $scope.MeasureUnits = results;

            for (var i = 0; i < $scope.MeasureUnits.length; i++) {
                if ($cookies.get('ERP_lang') == 'ar-EG') {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameAr;
                }
                else {
                    $scope.MeasureUnits[i].Title = $scope.MeasureUnits[i].NameEn;
                }
            }

            for (var i = 0; i < $scope.Confirmation_OrderDetails.length; i++) {
                if ($scope.Confirmation_OrderDetails[i].ProductID == productID)
                    $scope.Confirmation_OrderDetails[i].MeasureUnits = $scope.MeasureUnits;
            }

        }).error(function (data, status, headers, config) {
            $rootScope.$emit("swAlertError", {});
        });
    };

    $scope.edit = function (Confirmation_OrderID) {
        $http.get('/Confirmation_Order/GetOrderByID/' + Confirmation_OrderID).success(function (data) {
          
          $scope.Confirmation_Order = data;
          getDetails(Confirmation_OrderID);

            // $scope.showAdvancedEdit();
            //   $scope.getOrderTypes();

          $scope.getShipping_Ways();

            //$scope.AddNew = true;
          HideMasterShowDetails('#DivShow', '#DivSave');

        });
    };

    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.removeFilterDetails = function () {
        $scope.filterDetail.show = false;
        $scope.query.filterDetails = '';

        if ($scope.filterDetail.form.$dirty) {
            $scope.filterDetail.form.$setPristine();
        }
    };

    $scope.removeFilterProduct = function () {
        $scope.filtered.show = false;
        $scope.query.filtered = '';

        if ($scope.filtered.form.$dirty) {
            $scope.filtered.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 5,
        page: 1
    };

 

    $scope.LoadPurchaseOrder = function (ev) {

        $scope.getOrders();
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '../../Areas/accounting/templates/Confirmation_LoadPurchaseOrder.tmpl.html',
            onRemoving: function () {
                $scope.cancelProduct();
            },
            clickOutsideToClose: true,
            openFrom: '.LoadOrder',
            closeTo: '.LoadOrder'
        })

    };
  
    //load Order
     $scope.getOrders = function () {
        $http.get('/Purchase_Order/GetALLImportOrders').success(function (results) {
            $scope.Purchase_Orders = results;
        }).error(function (data, status, headers, config) {
            swAlertErrorAr();
        });
     };

    $scope.getOrder = function (OrderID) {
        $http.get('/Purchase_Order/GetDetailsByOrderID/' + OrderID).success(function (results) {
            //$scope.Confirmation_OrderDetails = results;
            //$scope.Confirmation_Order.OrderID = results[0].OrderID;

            addMasterPurchaseOrderInConfirmationOrder(OrderID);
            $scope.Purchase_OrderDetails = results;
            $scope.Confirmation_Order.Purchase_OrderID = results[0].OrderID;

            for (i = 0; i < $scope.Purchase_OrderDetails.length; i++) {

                for (var j = 0; j < $scope.Purchase_OrderDetails[i].MeasureUnits.length; j++) {
                    if ($cookies.get('ERP_lang') == 'ar-EG') {
                        $scope.Purchase_OrderDetails[i].MeasureUnits[j].Title = $scope.Purchase_OrderDetails[i].MeasureUnits[j].MeasureUnitName;
                    }
                    else {
                        $scope.Purchase_OrderDetails[i].MeasureUnits[j].Title = $scope.Purchase_OrderDetails[i].MeasureUnits[j].MeasureUnitNameEn;
                    }
                }

                //var foundItem = $filter('filter')($scope.Purchase_OrderDetails, { ProductCode: modal[i].Code }, true)[0];

                //if (foundItem == undefined) {
                //    $scope.Purchase_OrderDetails.push(item);
                //}

                $scope.Confirmation_OrderDetails.push($scope.Purchase_OrderDetails[i]);
            }

            $scope.getTotalQuantity();
            $scope.getTotalWeightTotal();
            $scope.getTotalWeightNet();
            $scope.getTotalPrice();

            $scope.cancelProduct();
        }).error(function () {
            swAlertErrorAr();
        });
    };
  
    function addMasterPurchaseOrderInConfirmationOrder(OrderID) {
        $http.get('/Purchase_Order/GetOrderByID/' + OrderID).success(function (results) {
            $scope.PurchaseOrder = results;
            $scope.Confirmation_Order.Shipping_WayID = $scope.PurchaseOrder.Shipping_WayID;
            $scope.Confirmation_Order.Weight = $scope.PurchaseOrder.Weight;
            $scope.Confirmation_Order.Price = $scope.PurchaseOrder.Price;
            $scope.Confirmation_Order.Isbacklog = $scope.PurchaseOrder.Isbacklog;
            $scope.Confirmation_Order.Notes = $scope.PurchaseOrder.Notes;
        }).error(function () {
            swAlertErrorAr();
        });
    }

    $scope.deleteDetails = function (model) {
        swConfirmDeleteAr(
            {
                function () {

                    if (model.OrderDetailID == undefined) {
                        $scope.Confirmation_OrderDetails.splice($.inArray(model, $scope.Confirmation_OrderDetails), 1);
                        $scope.$apply();
                        $scope.selectedDetails = [];
                    }

                }
            }
        );
    }

    $scope.checkReport = function (InvoiceID) {
        var reportParams = {
            "Parms": { "InvoiceID": InvoiceID },
            "ReportName": "PurchaseReport/ConfirmationOrderReport.trdx"
        };

        //$("#reportTest").load('/report', JSON.stringify(reportParams));

        $http.post('/report', JSON.stringify(reportParams)).success(function (results) {

            var x = window.open();
            x.document.open();
            x.document.write(results);
            x.document.close();

            //$('#reportTest').html(results);
        })
    }

});