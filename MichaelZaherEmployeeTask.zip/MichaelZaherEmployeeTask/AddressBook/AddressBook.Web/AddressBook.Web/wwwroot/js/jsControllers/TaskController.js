﻿
angular.module('globalApp')
    .controller('TaskController', function ($scope, $mdToast, $mdDialog, $http, $rootScope, $filter) {

    $scope.Tasks = [];
    $scope.Task = {};
    $scope.selected = [];
    $scope.EmployeeTaskStatus = {}

    $scope.query = {
        order: 'name',
        limit: 10,
        page: 1
    };

        getTasks();

    // get All Departments

        function getTasks() {
            $http.get('/api/Task/geAllTasks').success(function (results) {
                $scope.Tasks = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
        };


        $scope.GetEmployeeTaskBtTaskID = function (id) {
            $http.get('/api/Task/getEmployeeTaskByID/' + id).success(function (data) {
                $scope.ListEmployeeTask = data;
                for (var i = 0; i < $scope.ListEmployeeTask.length; i++) {
                    $scope.ListEmployeeTask[i].EmployeeName = $scope.ListEmployeeTask[i].Employee.FirstName + " " + $scope.ListEmployeeTask[i].Employee.LastName;
                    $scope.ListEmployeeTask[i].StatusName = $scope.ListEmployeeTask[i].Status.TitleAr;
                }
      
            });
        };

        // get all employee for current manager
        $scope.Employees = [];
        $scope.getAllEMployee = function () {
            $http.get('/api/Employee/GetAllEmployeesCurrentManager').success(function (results) {
                $scope.Employees = results;
                for (i = 0; i < $scope.Employees.length; i++) {
                    $scope.Employees[i].FullName = $scope.Employees[i].FirstName + " " + $scope.Employees[i].LastName;

                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }

        $scope.Status = [];
        $scope.getALLStatus = function() {
            $http.get('/api/Task/geAllStatus').success(function (results) {
                $scope.Status = results;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };

        // save New Department
        $scope.save = function () {

            $.ajax({
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify($scope.Task),
                url: '/api/Task/saveTask',
                success: function () {
                    getTasks();
                    $scope.cancel();
                    $rootScope.$emit("swAlertSave", {});
                },
                error: function () {
                    $rootScope.$emit("swAlertError", {});
                }
            });
        };
        $scope.ListEmployeeTask = [];
        $scope.AddTaskEmployee = function (obj) {

            angular.forEach(obj.SelectedEmployees, function (EmpSelect, key) {
                var newobj = {};
                newobj.TaskID = $scope.EmployeeTaskStatus.TaskID;
                newobj.StatusID = obj.status.StatusID;
                newobj.StatusName = obj.status.TitleAr;
                newobj.EmployeeID = EmpSelect.EmployeeID;
                newobj.EmployeeName = EmpSelect.FirstName + ' ' + EmpSelect.LastName;
                var foundItem = $filter('filter')($scope.ListEmployeeTask, { TaskID: newobj.TaskID }
                    && { EmployeeID: newobj.EmployeeID }, true)[0];

                if (foundItem != null ) {
                    var index = $scope.ListEmployeeTask.indexOf(foundItem);

                    $scope.ListEmployeeTask[index] = newobj;
                }
                else {
                    $scope.ListEmployeeTask.push(newobj);
                }
            });
            $scope.EmployeeTaskStatus = {};
        };

        $scope.deleteEmployeeTask = function (item) {
         
                 
                        if (item.EmployeeTaskID == undefined) {
                            $scope.ListEmployeeTask.splice($.inArray(item, $scope.ListEmployeeTask), 1);
                            $scope.$apply();
                        }
                        else {
                            $http.post('/api/Task/deleteTEmployeeTask', JSON.stringify(item)).success(function (results) {
                                $scope.ListEmployeeTask.splice($.inArray(item, $scope.ListEmployeeTask), 1);
                                $scope.$apply();

                            }).error(function (data, status, headers, config) {
                                swAlertErrorAr();
                            });
                        }

                  
              
        }



        $scope.saveAssignEmployeeTask = function ()
        {
            $.ajax({
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify($scope.ListEmployeeTask),
                url: '/api/Task/saveAssignEmployeeTask',
                success: function () {
                    getTasks();
                    $scope.cancel();
                    $rootScope.$emit("swAlertSave", {});
                },
                error: function () {
                    $rootScope.$emit("swAlertError", {});
                }
            });
        }

    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '/Templates/Task.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };

        $scope.AssignTaskEmployee = function (id) {
            $scope.EmployeeTaskStatus.TaskID = id;

            $scope.GetEmployeeTaskBtTaskID(id);
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '/Templates/AssignEmployeeTask.tmpl.html',
                onRemoving: function () {
                    $scope.cancel();
                },
                clickOutsideToClose: true,
                openFrom: '.addButton',
                closeTo: '.addButton'

            })

        };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '/Templates/Task.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Task = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Task = {};
        $scope.EmployeeTaskStatus = {};
        $scope.EmployeeTaskStatus.SelectedEmployees = [];
        $scope.Employees = [];
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };
   
    

    $scope.edit = function (id) {
        $http.get('/api/Task/getTaskByID/' + id).success(function (data) {
            $scope.Task = data;
            $scope.showAdvancedEdit();
        });
    };




    $scope.delete = function(item){
    $rootScope.$emit("swConfirmDelete",
     {
         function () {
             $http.post('/api/Task/deleteTask', JSON.stringify(item)).success(function (results) {
                 getTasks();
             });
         }
     });
    };
    


    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 10,
        page: 1
    };
});