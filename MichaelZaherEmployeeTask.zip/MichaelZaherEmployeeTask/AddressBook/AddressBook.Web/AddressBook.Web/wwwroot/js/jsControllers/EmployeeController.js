﻿angular.module('globalApp')
    .controller('EmployeeController', function ($scope, $mdToast, $mdDialog, $http, $rootScope, $filter) {

        $scope.Employees = [];
        $scope.Employee = {};
        $scope.SearchEmployees = '';
        
         // get All Employees
        $scope.getEmployees = function () {
            $http.get('/api/Employee/GetAllEmployees?SearchTerm='+ $scope.SearchEmployees).success(function (results) {
                $scope.Employees = results;
                for (i = 0; i < $scope.Employees.length; i++) {
                    $scope.Employees[i].FullName = $scope.Employees[i].FirstName + " " + $scope.Employees[i].LastName;
                }
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        }

        init();
        function init() {
            HideMasterShowDetails("#DivSave", "#DivShow");
            $scope.getEmployees();
            getManagers();
            getDepartments();
        }


        // get all jobs 
        $scope.ManagersEmployess = [];
        function getManagers() {
            $http.post('/api/Employee/GetAllManagers').success(function (results) {
                $scope.ManagersEmployess = results;
                for (i = 0; i < $scope.ManagersEmployess.length; i++) {
                    $scope.ManagersEmployess[i].FullName = $scope.ManagersEmployess[i].FirstName + " " + $scope.ManagersEmployess[i].LastName;
                }

            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };
        // get all Departments 
        $scope.Departments = [];
        function getDepartments() {
            $http.get('/api/Department/geAllDepartment').success(function (results) {
                $scope.Departments = results;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };
        
        $scope.saveEdit = function () {
            if ($scope.Employee.Type == 1) {
                $scope.Employee.ManagerID = null;
            }
            $http.post('/api/Employee/UpdateEmployee', JSON.stringify($scope.Employee)).success(function (data) {
              
                $rootScope.$emit("swAlertSave", {});
                $scope.getEmployees();
                $scope.cancel();
                $scope.Employee = {};
            });
        };
        $scope.edit = function (id) {
            $http.get('/api/Employee/getEmployeeByID/' + id).success(function (data) {
                $scope.Employee = data;

                //$scope.showAdvancedEdit();
                HideMasterShowDetails("#DivShow", "#DivSave");
            });
        };
        $scope.showAdvancedEdit = function (ev) {
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '/Templates/BookAddressEdit.tmpl.html',
                onRemoving: function () {
                    $scope.cancel();
                },
                clickOutsideToClose: true,
                openFrom: '.editButton',
                closeTo: '.editButton'
            })

        };
        //uploading profile pic 
        $scope.SaveAndUploadFile = function () {
            var formData = new FormData();
            angular.forEach($scope.Attachfiles, function (value, key) {
                formData.append(value.lfFileName, value.lfFile);
            });
            $http.post('/api/CommonUpload/UploadEmployeeImage', formData, {
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }).then(function (result) {
                if ($scope.Employee.Image === undefined) {
                    $scope.Employee.Image = '';
                }
                if (result.data.length != 0)
                    $scope.Employee.Image = result.data[0];
                $scope.save();


            }, function (err) {
                $rootScope.$emit("swAlertError", {});
            });
        };


        $scope.showAdvancedAdd = function (ev) {
            $scope.Attachfiles = [];

            HideMasterShowDetails("#DivShow", "#DivSave");

        };

        $scope.editPassword = function (EmployeeID) {

            $http.get('/api/Employee/getEmployeeByID/' + EmployeeID).success(function (data) {
                $scope.Employee = data;
                $scope.showAdvancedEditPassword();
            });


        };

        $scope.savePassword = function () {

            $.ajax({
                type: 'get',
                contentType: 'application/json; charset=utf-8',
                //data: JSON.stringify($scope.member),
                url: '/api/Employee/editPassword?userId=' + $scope.Employee.UserID + "&newPassword=" + $scope.Employee.Password,
                success: function () {

                    $scope.cancel();

                    $rootScope.$emit("swAlertSave", {});

                },
                error: function () {
                    $rootScope.$emit("swAlertError", {});
                }
            });
        };

        $scope.delete = function (EmployeeID) {
            $rootScope.$emit("swConfirmDelete",
                {
                    function() {
                        $http.get('/api/Employee/deleteEmplioyeeByid/' + EmployeeID).success(function () {
                            $scope.getEmployees();
                            $scope.selected = [];
                        });
                    }

                });

        };


        $scope.showAdvancedEditPassword = function (ev) {
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '/Templates/editMemberPassword.tmpl.html',
                onRemoving: function () {
                    $scope.cancel();
                },
                clickOutsideToClose: true,
                openFrom: '.editButton',
                closeTo: '.editButton'
            })

        };

        $scope.hide = function () {
            $mdDialog.hide();
            $scope.AddressBook = {};
        };

        $scope.cancel = function () {
            HideMasterShowDetails("#DivSave", "#DivShow");
            $mdDialog.cancel();
            $scope.Employee = {};
        };

        $scope.savediag = function () {
            $scope.save();
        };


        $scope.save = function () {
            $.ajax({
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify($scope.Employee),
                url: '/api/Employee/saveEmployee',
                success: function () {
                    $scope.getEmployees();
                    $scope.cancel();
                    $rootScope.$emit("swAlertSave", {});
                    
                },
                error: function () {
                    $rootScope.$emit("swAlertError", {});
                }   
            });
        };




        $scope.removeFilter = function () {
            $scope.filter.show = false;
            $scope.query.filter = '';

            if ($scope.filter.form.$dirty) {
                $scope.filter.form.$setPristine();
            }
        };

        $scope.limitOptions = [5, 10, 15];
        $scope.options = {
            pageSelect: true
        };
        $scope.query = {
            order: 'name',
            filter: '',
            limit: 10,
            page: 1
        };

    });
