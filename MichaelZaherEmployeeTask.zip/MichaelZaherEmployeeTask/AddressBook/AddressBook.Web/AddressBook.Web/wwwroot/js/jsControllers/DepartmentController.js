﻿
angular.module('globalApp')
    .controller('DepartmentController', function ($scope, $mdToast, $mdDialog, $http, $rootScope) {

    $scope.Departments = [];
    $scope.Department = {};
    $scope.selected = [];

    $scope.query = {
        order: 'name',
        limit: 10,
        page: 1
    };

        getDepartments();

    // get All Departments

        function getDepartments() {
            $http.get('/api/Department/geAllDepartment').success(function (results) {
                $scope.Departments = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
    };
        // save New Department
        $scope.save = function () {

            $.ajax({
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify($scope.Department),
                url: '/api/Department/saveDepartment',
                success: function () {
                    getDepartments();
                    $scope.cancel();
                    $rootScope.$emit("swAlertSave", {});
                },
                error: function () {
                    $rootScope.$emit("swAlertError", {});
                }
            });
        };

    $scope.showAdvancedAdd = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '/Templates/Department.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.addButton',
            closeTo: '.addButton'

        })

    };


    $scope.showAdvancedEdit = function (ev) {
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '/Templates/Department.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };

        $scope.showAdvancedSearch = function (ev) {
            $mdDialog.show({
                scope: $scope.$new(),
                templateUrl: '/Templates/EmployeeCount.tmpl.html',
                onRemoving: function () {
                    $scope.cancel();
                },
                clickOutsideToClose: true,
                openFrom: '.editButton',
                closeTo: '.editButton'
            })

        };

    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Department = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Department = {};
        $scope.selected = [];
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };
   
    

    $scope.edit = function (id) {
        $http.get('/api/Department/getDepartmentByID/' + id).success(function (data) {
            $scope.Department = data;
            $scope.showAdvancedEdit();
        });
    };


        $scope.GetCountAndSalaryOfEmployees = function (id) {
            $http.get('/api/Department/getDepartmentEmployeeCountByID/' + id).success(function (data) {
                $scope.Department = data;
                $scope.showAdvancedSearch();
            });

        }


    $scope.delete = function(item){
    $rootScope.$emit("swConfirmDelete",
     {
         function () {
             $http.post('/api/Department/deleteDepartment', JSON.stringify(item)).success(function (results) {
                 if (results == false) {
                     $rootScope.$emit("ErrorCount", {});
                 }
                 getDepartments();
             });
         }
     });
    };
    


    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 10,
        page: 1
    };
});