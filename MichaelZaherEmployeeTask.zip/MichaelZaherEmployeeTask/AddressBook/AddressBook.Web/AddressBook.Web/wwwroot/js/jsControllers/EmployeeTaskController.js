﻿
angular.module('globalApp')
    .controller('EmployeeTaskController', function ($scope, $mdToast, $mdDialog, $http, $rootScope, $filter) {

    $scope.Tasks = [];
    $scope.Task = {};
    $scope.selected = [];
    $scope.EmployeeTaskStatus = {}

    $scope.query = {
        order: 'name',
        limit: 10,
        page: 1
    };

        GetAllEmployeeTask();

    // get All Departments

        function GetAllEmployeeTask() {
            $http.get('/api/EmployeeTask/geAllTasks').success(function (results) {
                $scope.Tasks = results;
        }).error(function () {
            $rootScope.$emit("swAlertError", {});
        });
        };


        $scope.Status = [];
        $scope.getALLStatus = function() {
            $http.get('/api/Task/geAllStatus').success(function (results) {
                $scope.Status = results;
            }).error(function () {
                $rootScope.$emit("swAlertError", {});
            });
        };
        $scope.getALLStatus();
        // save New Department
        $scope.save = function () {

            $.ajax({
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify($scope.Task),
                url: '/api/EmployeeTask/saveEmployeeTask',
                success: function () {
                    GetAllEmployeeTask();
                    $scope.cancel();
                    $rootScope.$emit("swAlertSave", {});
                },
                error: function () {
                    $rootScope.$emit("swAlertError", {});
                }
            });
        };


        $scope.showAdvancedEdit = function (item) {
            $scope.Task = item;
        $mdDialog.show({
            scope: $scope.$new(),
            templateUrl: '/Templates/EmployeeTask.tmpl.html',
            onRemoving: function () {
                $scope.cancel();
            },
            clickOutsideToClose: true,
            openFrom: '.editButton',
            closeTo: '.editButton'
        })

    };


    $scope.hide = function () {
        $mdDialog.hide();
        $scope.Task = {};
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
        $scope.Task = {};
    };

    $scope.answer = function (answer) {
        $mdDialog.hide(answer);
    };
   
    


    $scope.removeFilter = function () {
        $scope.filter.show = false;
        $scope.query.filter = '';

        if ($scope.filter.form.$dirty) {
            $scope.filter.form.$setPristine();
        }
    };

    $scope.limitOptions = [5, 10, 15];
    $scope.options = {
        pageSelect: true
    };
    $scope.query = {
        order: 'name',
        filter: '',
        limit: 10,
        page: 1
    };
});