﻿using AddressBook.Core.Entites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AddressBook.Web.Models
{
    public class EmployeesTaskModel
    {
        public int? TaskID { get; set; }
        public Status status { get; set; }

        public List<Employee> SelectedEmployees { get; set; }
    }
}
