﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AddressBook.Core.Identity;
using AddressBook.Web.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AddressBook.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signinManager;
        public AuthController( IHttpContextAccessor httpContextAccessor ,
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signinManager)
        {
            _userManager = userManager;
            _signinManager = signinManager;
        }
        // Register
        [Route("register")]
        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult> InsertUser(RegisterUserRequest model)

        {
            var user = new ApplicationUser
            {
                Email = model.Email,
                UserName = model.Username,
                PhoneNumber = model.Telephone,
                SecurityStamp = Guid.NewGuid().ToString()
            };
            var result = await _userManager.CreateAsync(user, model.Password);
            if (result.Succeeded)

            {
                await _signinManager.SignInAsync(user, isPersistent: true);
                return Ok(user);
            }
            else
            {
                return Ok(new { Username = user.UserName });
            }
        }

        // Login
        [HttpPost]
        [Route("WebLogin")]
        [AllowAnonymous]
        public async Task<ActionResult<ApplicationUser>> WebLogin(LoginRequest request)
        {
            try
            {
                if (!string.IsNullOrEmpty(request.UserName) && string.IsNullOrEmpty(request.Password))
                {
                    return null;
                }
                else
                {

                    ApplicationUser user = await _userManager.FindByNameAsync(request.UserName);
                    // Member member = _memberContext.GetMemberByUserId(user.Id);

                    if (user != null && user.LockoutEnabled == true)
                    {
                       
                      
                            bool result = await _userManager.CheckPasswordAsync(user, request.Password);
                            if (result == true)
                            {
                                await _signinManager.SignInAsync(user, isPersistent: true);
                                return user;
                            }
                            else
                            {
                                return null;
                            }
                       

                    }
                    else
                    {
                        return null;
                    }
                }


            }
            catch (Exception ex)
            {
                return null;
            }
        }
        // LogOut
        [HttpPost]
        [Route("LogoutWeb")]
        [AllowAnonymous]
        public async Task<int> Logout(RegisterUserRequest model)
        {
            try
            {
                await HttpContext.SignOutAsync();
                return 1;
            }
            catch (Exception ex)
            {
                return 0;
            }

        }
    }
}