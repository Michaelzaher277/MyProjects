﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace AddressBook.Web.Controllers
{
    public class CommonController : Controller
    {
        
        public static string getJSON(object data)
        {
            return JsonConvert.SerializeObject(data,
                Formatting.None,
                new JsonSerializerSettings() { ReferenceLoopHandling = ReferenceLoopHandling.Ignore, Converters = { new IsoDateTimeConverter() } });
        }
    
    }
}