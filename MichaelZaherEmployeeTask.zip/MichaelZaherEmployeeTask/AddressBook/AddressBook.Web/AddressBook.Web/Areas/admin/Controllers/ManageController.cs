﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace AddressBook.Web.Areas.Controllers
{
    [Area("Admin")]
    public class ManageController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Department()
        {
            return View();
        }
        
        public IActionResult Employee()
        {
            return View();
        }
        public IActionResult Task()
        {
            return View();
        }

        public IActionResult EmployeeTask()
        {
            return View();
        }

        public IActionResult AddressBook()
        {
            return View();
        }
    }
}