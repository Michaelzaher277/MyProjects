﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using AddressBook.Web.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.ChangeTracking.Internal;

namespace AddressBook.Web.Areas.admin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly IDeparmentRepository _context;
        private readonly IEmployeeRepository _contextEmployee;

        public DepartmentController(IDeparmentRepository context , IEmployeeRepository contextEmployee)
        {
            _context = context;
            _contextEmployee = contextEmployee;
        }
        [HttpGet]
        [Route("geAllDepartment")]
        public IActionResult geAllDepartment()
        {
            var result = CommonController.getJSON(_context.List());
            return Ok((result));
        }
        //for Add And Update
        [HttpPost]
        [Route("saveDepartment")]
        public bool saveDepartment(Departments Department)
        {
            if (Department.DepartmentsID != 0)
            {
                _context.Update(Department);
                return true;
            }
            else
            {
                try
                {
                    _context.Insert(Department);
                    return true;

                }
                catch
                {
                    return false;
                }

            }


        }

        [HttpGet]
        [Route("getDepartmentByID/{id}")]
        public IActionResult getDepartmentByID(int id)
        {
            string result = CommonController.getJSON(_context.GetById(id));
            return Ok((result));

        }

        [HttpGet]
        [Route("getDepartmentEmployeeCountByID/{id}")]
        public IActionResult getDepartmentEmployeeCountByID(int id)
        {
            string result = CommonController.getJSON(_context.GetDepartmenTotalEmployee(id));
            return Ok((result));

        }



        [HttpPost]
        [Route("deleteDepartment")]
        public IActionResult deletejob(Departments model)
        {
            try
            {
                List<Employee> Emps = _contextEmployee.GetAllEmployeesByDepatID(model.DepartmentsID);
                if (model != null && Emps.Count == 0)
                {

                    model.IsDeleted = true;
                    _context.Update(model);

                    return Ok(true);

                }
                else
                    return Ok(false);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }

        }
    }
}