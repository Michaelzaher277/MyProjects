﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using AddressBook.Core.Entites;
using AddressBook.Core.Identity;
using AddressBook.Core.Interfaces;
using AddressBook.Web.Controllers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AddressBook.Web.Areas.admin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeRepository _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public EmployeeController(IEmployeeRepository context 
            , UserManager<ApplicationUser> userManager
             , IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _userManager = userManager;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [Route("GetAllEmployees")]
        public IActionResult GetAllEmployees(string SearchTerm)
        {
            if(SearchTerm == null)
            {
                SearchTerm = "";
            }
            List<Employee> employees = _context.GetAllEmployees().
                Where(x => x.FullName.Contains(SearchTerm) || SearchTerm == "" ).ToList();
            string result = CommonController.getJSON(employees);
            return Ok((result));
        }


        [HttpGet]
        [Route("GetAllEmployeesCurrentManager")]
        public IActionResult GetAllEmployeesCurrentManager()
        {
            var userId = _httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            Employee employee = _context.List().Where(x => x.IsDeleted != true && x.UserID == userId).FirstOrDefault();
            if (employee != null)
            {
                List<Employee> employees = _context.List().
                    Where(x => x.IsDeleted != true && x.ManagerID == employee.EmployeeID).ToList();
                string result = CommonController.getJSON(employees);
                return Ok((result));
            }
            else
                return Ok((false));
        }


        [HttpPost]
        [Route("GetAllManagers")]
        public IActionResult GetAllManagers()
        {

            List<Employee> Managers = _context.getAllEmployeeManager();
            string result = CommonController.getJSON(Managers);
            return Ok((result));
        }

        [HttpPost]
        [Route("UpdateEmployee")]
        public bool UpdateEmployee(Employee employee)
        {

            _context.Update(employee);

            return true;

        }

        [HttpGet]
        [Route("getEmployeeByID/{id}")]
        public IActionResult getEmployeeByID(int id)
        {
            string result = CommonController.getJSON(_context.getEmployeeByID(id));
            return Ok((result));

        }

        [HttpGet]
        [AllowAnonymous]
        [Route("editPassword")]
        public async Task<ActionResult> editPassword(string userId, string newPassword)
        {
            try
            {
                var user = await _userManager.FindByIdAsync(userId);
                user.PasswordHash = _userManager.PasswordHasher.HashPassword(user, newPassword);
                await _userManager.UpdateAsync(user);
                return Ok();

            }
            catch (Exception ex)
            {
                string Error = ex.InnerException.ToString();
                return Ok(Error + "_Message_ " + ex.Message);
            }


        }

        [HttpGet]
        [Route("deleteEmplioyeeByid/{id}")]
        public async Task<IActionResult> deleteEmplioyeeByid(int id)
        {
            var Employee = _context.GetById(id);
            var user = await _userManager.FindByIdAsync(Employee.UserID);
            if (user != null)
            {
                user.LockoutEnabled = false;

                await _userManager.UpdateAsync(user);
            }
            Employee.IsDeleted = true;
            _context.Update(Employee);
            return Ok();

        }



        [HttpPost]
        [Route("saveEmployee")]
        public async Task<ActionResult> saveEmployee(Employee employee)
        {
            if (employee.EmployeeID == 0)
            {

                var user = new ApplicationUser
                {
                    Email = employee.Email,
                    UserName = employee.Email,
                    SecurityStamp = Guid.NewGuid().ToString()
                };
                var result = await _userManager.CreateAsync(user, employee.Password);
                if (result.Succeeded)
                {
                    employee.UserID = user.Id;

                    _context.Insert(employee);
                    if (employee.Type == 1)
                    {
                        await _userManager.AddToRoleAsync(user, "Manager");
                    }
                    else
                    {
                        await _userManager.AddToRoleAsync(user, "Employee");
                    }
                    return Ok(true);

                }
                else
                {
                    string error = "";
                    foreach (var item in result.Errors)
                    {
                        error += "_" + item.Description;
                    }
                    return Ok(error);
                }
            }
            else
            {
                _context.Update(employee);

                return Ok(true);
            }
           

        }

    }
}