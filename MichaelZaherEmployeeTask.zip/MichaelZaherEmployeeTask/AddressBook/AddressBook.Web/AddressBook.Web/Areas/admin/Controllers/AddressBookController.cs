﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using AddressBook.Web.Controllers;
using AddressBook.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AddressBook.Web.Areas.admin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressBookController : ControllerBase
    {
        //private readonly IAddressBook _context;
        //private readonly INewEntryAddress _NewEntryAddressContex;
        //private readonly INewEntryPhones _NewEntryPhonesContex;

        //public AddressBookController(IAddressBook context , INewEntryAddress NewEntryAddressContex 
        //    , INewEntryPhones NewEntryPhonesContex)
        //{
        //    _context = context;
        //    _NewEntryAddressContex = NewEntryAddressContex;
        //    _NewEntryPhonesContex = NewEntryPhonesContex;
        //}
        //[HttpPost]
        //[Route("GetAllAddressBook")]
        //public IActionResult GetAllAddressBook(SearchAddressBook _orderSearch)
        //{

        //    List<NewEntry> Entries = _context.getAllAddressBook().
        //        Where(x => (x.DateOfBirth >= _orderSearch.DateFrom || _orderSearch.DateFrom == null)
        //                                           && (x.DateOfBirth <= _orderSearch.DateTo || _orderSearch.DateTo == null)
        //                                           && (x.IsDeleted != true)).ToList();
           
           
        //    string result = CommonController.getJSON(Entries);
        //    return Ok((result));
        //}
        //[HttpGet]
        //[Route("getaddressBooktByID/{id}")]
        //public IActionResult getaddressBooktByID(int id)
        //{
        //    string result = CommonController.getJSON(_context.getAddressBookByID(id));
        //    //return Content(result, "json", System.Text.Encoding.UTF8);
        //    return Ok((result));

        //}
        //[HttpPost]
        //[Route("UpdateBookAddress")]
        //public bool UpdateBookAddress(NewEntry AddressBook)
        //{

        //        _context.Update(AddressBook);
        //    foreach (var item in AddressBook.NewEntryAddressess)
        //    {
            
        //        _NewEntryAddressContex.Update(item);

        //    }
        //    foreach (var item in AddressBook.NewEntryPhoness)
        //    {
               
        //        _NewEntryPhonesContex.Update(item);
        //    }
        //    return true;

        //}

        //[HttpPost]
        //[Route("saveBookAddress")]
        //public bool saveBookAddress(NewEntry AddressBook)
        //{

        //    _context.Insert(AddressBook);
         
        //    return true;

        //}
        //[HttpPost]
        //[Route("deleteAddressBook")]
        //public IActionResult deleteAddressBook(NewEntry model)
        //{
        //    try
        //    {
        //        if (model != null)
        //        {

        //            model.IsDeleted = true;
        //            _context.Update(model);
        //            foreach (var item in model.NewEntryAddressess)
        //            {
        //                item.IsDeleted = true;
        //                _NewEntryAddressContex.Update(item);

        //            }
        //            foreach (var item in model.NewEntryPhoness)
        //            {
        //                item.IsDeleted = true;
        //                _NewEntryPhonesContex.Update(item);
        //            }
        //            return Ok();

        //        }
        //        else
        //            return Ok();
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest();
        //    }

        //}
    }
}