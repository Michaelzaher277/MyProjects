﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using AddressBook.Web.Controllers;
using AddressBook.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AddressBook.Web.Areas.admin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly ITaskRepository _context;
        private readonly IEmployeeRepository _contextEmployee;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IStatusRepository _contextStatus;
        private readonly ITaskEmployeeRepository _contextTaskEmployeeRepository;
        public TaskController(ITaskRepository context, IEmployeeRepository contextEmployee
            , IHttpContextAccessor httpContextAccessor , IStatusRepository contextStatus ,
           ITaskEmployeeRepository contextTaskEmployeeRepository)
        {
            _context = context;
            _contextEmployee = contextEmployee;
            _httpContextAccessor = httpContextAccessor;
            _contextStatus = contextStatus;
            _contextTaskEmployeeRepository = contextTaskEmployeeRepository;
        }
        [HttpGet]
        [Route("geAllTasks")]
        public IActionResult geAllTasks()
        {
            var userId = _httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            List<AddressBook.Core.Entites.Task> tasks = _context.List().Where(x => x.IsDeleted != true && x.CreatedByNameId == userId).ToList();
            var result = CommonController.getJSON(tasks);
            return Ok((result));
        }


        [HttpGet]
        [Route("geAllStatus")]
        public IActionResult geAllStatus()
        {
            List<AddressBook.Core.Entites.Status> status = _contextStatus.List().ToList();
            var result = CommonController.getJSON(status);
            return Ok((result));
        }


        //for Add And Update
        [HttpPost]
        [Route("saveTask")]
        public bool saveTask(AddressBook.Core.Entites.Task task)
        {
            var userId = _httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            task.CreatedByNameId = userId;
            if (task.TaskID != 0)
            {
                _context.Update(task);
                return true;
            }
            else
            {
                try
                {
                    _context.Insert(task);
                    return true;

                }
                catch
                {
                    return false;
                }

            }


        }

        [HttpPost]
        [Route("saveAssignEmployeeTask")]
        public bool saveAssignEmployeeTask(List<EmployeeTask> model)
        {
            foreach (var item in model)
            {
                if(item.EmployeeTaskID ==0)
                _contextTaskEmployeeRepository.Insert(item);
            }
            return true;
        }

        [HttpGet]
        [Route("getTaskByID/{id}")]
        public IActionResult getTaskByID(int id)
        {
            string result = CommonController.getJSON(_context.GetById(id));
            return Ok((result));

        }

        [HttpGet]
        [Route("getEmployeeTaskByID/{id}")]
        public IActionResult getEmployeeTaskByID(int id)
        {
            string result = CommonController.getJSON(_contextTaskEmployeeRepository.GetAllEmployeeTaskByTaskID(id));
            return Ok((result));

        }

        [HttpPost]
        [Route("deleteTask")]
        public IActionResult deleteTask(AddressBook.Core.Entites.Task  model)
        {
            try
            {
                if (model != null)
                {

                    model.IsDeleted = true;
                    _context.Update(model);

                    return Ok(true);

                }
                else
                    return Ok(false);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }

        }


        [HttpPost]
        [Route("deleteTEmployeeTask")]
        public IActionResult deleteTEmployeeTask(AddressBook.Core.Entites.EmployeeTask model)
        {
            try
            {
                if (model != null)
                {

                    model.IsDeleted = true;
                    _contextTaskEmployeeRepository.Update(model);

                    return Ok(true);

                }
                else
                    return Ok(false);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }

        }

    }
}