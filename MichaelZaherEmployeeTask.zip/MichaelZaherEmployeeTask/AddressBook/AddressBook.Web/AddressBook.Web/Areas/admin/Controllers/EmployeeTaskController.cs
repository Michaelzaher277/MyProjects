﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using AddressBook.Core.Entites;
using AddressBook.Core.Interfaces;
using AddressBook.Web.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AddressBook.Web.Areas.admin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeTaskController : ControllerBase
    {
        private readonly ITaskEmployeeRepository _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IEmployeeRepository _contextEmployee;
        private readonly ITaskRepository _contextTask;
        public EmployeeTaskController(IHttpContextAccessor httpContextAccessor ,
            ITaskEmployeeRepository context 
            , IEmployeeRepository contextEmployee ,
            ITaskRepository contextTask)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
            _contextEmployee = contextEmployee;
            _contextTask = contextTask;
        }

        [HttpGet]
        [Route("geAllTasks")]
        public IActionResult geAllTasks()
        {
            var userId = _httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            Employee employee = _contextEmployee.List().Where(x => x.IsDeleted != true && x.UserID == userId).FirstOrDefault();
            List<AddressBook.Core.Entites.EmployeeTask> tasks = _context.GetAllEmployeeTaskByEmployeeID(employee.EmployeeID);
            var result = CommonController.getJSON(tasks);
            return Ok((result));
        }


        [HttpPost]
        [Route("saveEmployeeTask")]
        public bool saveTask(AddressBook.Core.Entites.EmployeeTask task)
        {
            if (task.EmployeeTaskID != 0)
            {
                _context.Update(task);
                if(task.Task != null)
                {

                    _contextTask.Update(task.Task);
                }
               
            }
            return true;
        }

    }
}