﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AddressBook.Web.Areas.admin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommonUploadController : ControllerBase
    {
        private readonly IHostingEnvironment hostingEnvironment;
        public CommonUploadController(IHostingEnvironment environment)
        {
         
            hostingEnvironment = environment;
        }

        [HttpPost]
        [Route("UploadEmployeeImage")]
        public async Task<ActionResult> UploadCompanyImage(IFormCollection files)
        {
            List<string> paths = new List<string>();
            // string finalName = "";
            string PhysicalfilePath = Path.Combine(hostingEnvironment.WebRootPath, "Uploads/AddreesBookPic/");
            string pathURL = "/Uploads/AddreesBookPic/";
            foreach (var formFile in files.Files)
            {
                // folder to upload to + file name without extension + guid + extension 
                //finalName = formFile.FileName.Substring(0, formFile.FileName.LastIndexOf(".")) + Guid.NewGuid().ToString() + "." + formFile.FileName.Substring(formFile.FileName.LastIndexOf(".") + 1);
                //generate url and physical path
                string filePath = PhysicalfilePath + formFile.FileName;
                pathURL = pathURL + formFile.FileName;
                if (formFile.Length > 0)
                {
                    paths.Add(pathURL);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await formFile.CopyToAsync(stream);
                    }
                }
            }

            return Ok(paths);
        }

    }
}